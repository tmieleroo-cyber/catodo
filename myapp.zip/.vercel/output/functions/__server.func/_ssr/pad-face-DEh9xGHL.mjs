import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ChevronLeft, i as ChevronRight, o as ChevronDown, r as ChevronUp } from "../_libs/lucide-react.mjs";
import { c as maskBit, d as previewPathPrefix, r as PAD } from "./router-Koy46LeH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pad-face-DEh9xGHL.js
var import_jsx_runtime = require_jsx_runtime();
/** Preview hosts serve the app under /hds-…/; the phone must use that public path. */
function publicPrefix() {
	if (typeof window === "undefined") return "";
	return previewPathPrefix(window.location.hostname, window.location.pathname) ?? "";
}
function apiUrl(path) {
	return `${publicPrefix()}${path}`;
}
function mandoUrl(code, secret) {
	const url = new URL(window.location.origin);
	url.pathname = `${publicPrefix()}/mando`;
	url.searchParams.set("code", code);
	url.hash = `k=${secret}`;
	return url.toString();
}
function readHashSecret() {
	const raw = window.location.hash.replace(/^#/, "");
	return new URLSearchParams(raw).get("k") ?? "";
}
function PadFace({ mask, onBit }) {
	const hold = (bit, label, className, children, emphasize = false) => {
		const down = maskBit(mask, bit);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": label,
			"aria-pressed": down,
			className: `touch-none grid select-none place-items-center border text-sm font-semibold tracking-wide ${className} ${down ? "border-ember bg-ember text-ember-ink" : emphasize ? "border-ember bg-surface text-ember" : "border-line bg-surface-2 text-fg"}`,
			onContextMenu: (event) => event.preventDefault(),
			onPointerDown: (event) => {
				event.preventDefault();
				event.currentTarget.setPointerCapture(event.pointerId);
				onBit(bit, true);
				navigator.vibrate?.(8);
			},
			onPointerUp: () => onBit(bit, false),
			onPointerCancel: () => onBit(bit, false),
			children
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-between gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pad-grid",
			"aria-label": "Cruceta",
			children: [
				hold(PAD.UP, "Arriba", "col-start-2 row-start-1 size-16 rounded-full", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, {})),
				hold(PAD.LEFT, "Izquierda", "col-start-1 row-start-2 size-16 rounded-full", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "col-start-2 row-start-2 grid place-items-center font-mono text-xs tracking-[0.18em] text-muted",
					children: "DIR"
				}),
				hold(PAD.RIGHT, "Derecha", "col-start-3 row-start-2 size-16 rounded-full", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})),
				hold(PAD.DOWN, "Abajo", "col-start-2 row-start-3 size-16 rounded-full", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {}))
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-end gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [hold(PAD.B, "B", "size-16 rounded-full text-base", "B"), hold(PAD.A, "A", "size-16 rounded-full text-base", "A", true)]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [hold(PAD.SELECT, "Select", "h-12 rounded-md px-4 text-xs", "Select"), hold(PAD.START, "Start", "h-12 rounded-md px-4 text-xs", "Start")]
			})]
		})]
	});
}
//#endregion
export { readHashSecret as i, apiUrl as n, mandoUrl as r, PadFace as t };
