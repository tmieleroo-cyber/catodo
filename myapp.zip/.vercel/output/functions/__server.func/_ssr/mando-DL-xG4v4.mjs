import { o as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as SECRET_RE, l as withBit, n as CODE_RE, o as bitForKey, u as Route$1 } from "./router-Koy46LeH.mjs";
import { i as readHashSecret, n as apiUrl, t as PadFace } from "./pad-face-DEh9xGHL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mando-DL-xG4v4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MandoPage() {
	const { code } = Route$1.useSearch();
	const [secret, setSecret] = (0, import_react.useState)(null);
	const [mask, setMask] = (0, import_react.useState)(0);
	const [link, setLink] = (0, import_react.useState)("leyendo");
	const maskRef = (0, import_react.useRef)(0);
	const sendRef = (0, import_react.useRef)(null);
	maskRef.current = mask;
	(0, import_react.useEffect)(() => {
		setSecret(readHashSecret());
	}, []);
	(0, import_react.useEffect)(() => {
		if (secret === null) return;
		if (!CODE_RE.test(code) || !SECRET_RE.test(secret)) {
			setLink("incompleto");
			return;
		}
		let stop = false;
		const channel = new BroadcastChannel(`catodo-${code}`);
		const send = async () => {
			const buttons = maskRef.current & 255;
			channel.postMessage({ mask: buttons });
			try {
				const response = await fetch(apiUrl("/api/pad"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					cache: "no-store",
					body: JSON.stringify({
						op: "push",
						code,
						secret,
						mask: buttons
					})
				});
				if (stop) return;
				if (response.status === 401) setLink("rechazado");
				else if (response.ok) setLink("conectado");
				else setLink("error");
			} catch {
				if (!stop) setLink("error");
			}
		};
		setLink("enlazando");
		sendRef.current = () => void send();
		send();
		const timer = window.setInterval(() => void send(), 200);
		return () => {
			stop = true;
			sendRef.current = null;
			window.clearInterval(timer);
			channel.close();
		};
	}, [code, secret]);
	(0, import_react.useEffect)(() => {
		sendRef.current?.();
	}, [mask]);
	(0, import_react.useEffect)(() => {
		const down = (event) => {
			const bit = bitForKey(event.code);
			if (bit === null || event.repeat) return;
			event.preventDefault();
			setMask((current) => withBit(current, bit, true));
		};
		const up = (event) => {
			const bit = bitForKey(event.code);
			if (bit === null) return;
			setMask((current) => withBit(current, bit, false));
		};
		window.addEventListener("keydown", down);
		window.addEventListener("keyup", up);
		return () => {
			window.removeEventListener("keydown", down);
			window.removeEventListener("keyup", up);
		};
	}, []);
	const ready = secret !== null && CODE_RE.test(code) && SECRET_RE.test(secret);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "safe-pad mx-auto flex min-h-dvh w-full max-w-lg flex-col gap-6 px-4 py-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-[0.2em] text-ember",
				children: "CÁTODO"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-3xl font-semibold text-fg",
				children: "Mando"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-pretty text-muted",
				children: statusCopy(link, code)
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: ready ? "" : "pointer-events-none opacity-40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadFace, {
				mask,
				onBit: (bit, down) => setMask((current) => withBit(current, bit, down))
			})
		})]
	});
}
function statusCopy(link, code) {
	if (link === "leyendo") return "Leyendo el enlace…";
	if (link === "incompleto") return "Escanea otra vez el QR del televisor. Este enlace no trae la clave y no se escribe a mano.";
	if (link === "enlazando") return `Sala ${code}. Enlazando…`;
	if (link === "conectado") return `Sala ${code}. Enlazado. Lo que pulses llega al televisor.`;
	if (link === "rechazado") return "Esta sala ya no vale. En el televisor, vuelve a mostrar el QR.";
	return "No hay enlace con el televisor. Comprueba que ambos siguen abiertos.";
}
//#endregion
export { MandoPage as component };
