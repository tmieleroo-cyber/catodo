//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cfq2xU-H.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/mando",
			"/api/pad"
		],
		preloads: ["/assets/index-3kBev2fy.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-3kBev2fy.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DYYNO3_u.js", "/assets/pad-face-C8p0EGUL.js"]
	},
	"/mando": {
		filePath: "/workspace/src/routes/mando.tsx",
		children: void 0,
		preloads: ["/assets/mando-B2HnojpU.js", "/assets/pad-face-C8p0EGUL.js"]
	}
} });
//#endregion
export { tsrStartManifest };
