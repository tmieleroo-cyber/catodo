import { r as __exportAll } from "../_runtime.mjs";
//#region node_modules/jsnes/src/utils.js
function copyArrayElements(src, srcPos, dest, destPos, length) {
	for (let i = 0; i < length; ++i) dest[destPos + i] = src[srcPos + i];
}
function fromJSON(obj, state) {
	const props = obj.constructor.JSON_PROPERTIES;
	for (let i = 0; i < props.length; i++) {
		const prop = props[i];
		const current = obj[prop];
		const value = state[prop];
		if (ArrayBuffer.isView(current) && Array.isArray(value)) current.set(value);
		else obj[prop] = value;
	}
}
function toJSON(obj) {
	const state = {};
	const props = obj.constructor.JSON_PROPERTIES;
	for (let i = 0; i < props.length; i++) {
		const prop = props[i];
		const value = obj[prop];
		state[prop] = ArrayBuffer.isView(value) ? Array.from(value) : value;
	}
	return state;
}
//#endregion
//#region node_modules/jsnes/src/cpu.js
var ADDR_ZP = 0;
var ADDR_REL = 1;
var ADDR_IMP = 2;
var ADDR_ABS = 3;
var ADDR_ACC = 4;
var ADDR_IMM = 5;
var ADDR_ZPX = 6;
var ADDR_ZPY = 7;
var ADDR_ABSX = 8;
var ADDR_ABSY = 9;
var ADDR_PREIDXIND = 10;
var ADDR_POSTIDXIND = 11;
var ADDR_INDABS = 12;
var INS_ADC = 0;
var INS_AND = 1;
var INS_ASL = 2;
var INS_BCC = 3;
var INS_BCS = 4;
var INS_BEQ = 5;
var INS_BIT = 6;
var INS_BMI = 7;
var INS_BNE = 8;
var INS_BPL = 9;
var INS_BRK = 10;
var INS_BVC = 11;
var INS_BVS = 12;
var INS_CLC = 13;
var INS_CLD = 14;
var INS_CLI = 15;
var INS_CLV = 16;
var INS_CMP = 17;
var INS_CPX = 18;
var INS_CPY = 19;
var INS_DEC = 20;
var INS_DEX = 21;
var INS_DEY = 22;
var INS_EOR = 23;
var INS_INC = 24;
var INS_INX = 25;
var INS_INY = 26;
var INS_JMP = 27;
var INS_JSR = 28;
var INS_LDA = 29;
var INS_LDX = 30;
var INS_LDY = 31;
var INS_LSR = 32;
var INS_NOP = 33;
var INS_ORA = 34;
var INS_PHA = 35;
var INS_PHP = 36;
var INS_PLA = 37;
var INS_PLP = 38;
var INS_ROL = 39;
var INS_ROR = 40;
var INS_RTI = 41;
var INS_RTS = 42;
var INS_SBC = 43;
var INS_SEC = 44;
var INS_SED = 45;
var INS_SEI = 46;
var INS_STA = 47;
var INS_STX = 48;
var INS_STY = 49;
var INS_TAX = 50;
var INS_TAY = 51;
var INS_TSX = 52;
var INS_TXA = 53;
var INS_TXS = 54;
var INS_TYA = 55;
var INS_ALR = 56;
var INS_ANC = 57;
var INS_ARR = 58;
var INS_AXS = 59;
var INS_LAX = 60;
var INS_SAX = 61;
var INS_DCP = 62;
var INS_ISC = 63;
var INS_RLA = 64;
var INS_RRA = 65;
var INS_SLO = 66;
var INS_SRE = 67;
var INS_SKB = 68;
var INS_IGN = 69;
var INS_SHA = 71;
var INS_SHS = 72;
var INS_SHY = 73;
var INS_SHX = 74;
var OPCODE_TABLE = {
	105: {
		ins: INS_ADC,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	101: {
		ins: INS_ADC,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	117: {
		ins: INS_ADC,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	109: {
		ins: INS_ADC,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	125: {
		ins: INS_ADC,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	121: {
		ins: INS_ADC,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 4
	},
	97: {
		ins: INS_ADC,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 6
	},
	113: {
		ins: INS_ADC,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 5
	},
	41: {
		ins: INS_AND,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	37: {
		ins: INS_AND,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	53: {
		ins: INS_AND,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	45: {
		ins: INS_AND,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	61: {
		ins: INS_AND,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	57: {
		ins: INS_AND,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 4
	},
	33: {
		ins: INS_AND,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 6
	},
	49: {
		ins: INS_AND,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 5
	},
	10: {
		ins: INS_ASL,
		mode: ADDR_ACC,
		size: 1,
		cycles: 2
	},
	6: {
		ins: INS_ASL,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	22: {
		ins: INS_ASL,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	14: {
		ins: INS_ASL,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	30: {
		ins: INS_ASL,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	144: {
		ins: INS_BCC,
		mode: ADDR_REL,
		size: 2,
		cycles: 2
	},
	176: {
		ins: INS_BCS,
		mode: ADDR_REL,
		size: 2,
		cycles: 2
	},
	240: {
		ins: INS_BEQ,
		mode: ADDR_REL,
		size: 2,
		cycles: 2
	},
	48: {
		ins: INS_BMI,
		mode: ADDR_REL,
		size: 2,
		cycles: 2
	},
	208: {
		ins: INS_BNE,
		mode: ADDR_REL,
		size: 2,
		cycles: 2
	},
	16: {
		ins: INS_BPL,
		mode: ADDR_REL,
		size: 2,
		cycles: 2
	},
	80: {
		ins: INS_BVC,
		mode: ADDR_REL,
		size: 2,
		cycles: 2
	},
	112: {
		ins: INS_BVS,
		mode: ADDR_REL,
		size: 2,
		cycles: 2
	},
	36: {
		ins: INS_BIT,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	44: {
		ins: INS_BIT,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	0: {
		ins: INS_BRK,
		mode: ADDR_IMP,
		size: 1,
		cycles: 7
	},
	24: {
		ins: INS_CLC,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	216: {
		ins: INS_CLD,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	88: {
		ins: INS_CLI,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	184: {
		ins: INS_CLV,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	201: {
		ins: INS_CMP,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	197: {
		ins: INS_CMP,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	213: {
		ins: INS_CMP,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	205: {
		ins: INS_CMP,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	221: {
		ins: INS_CMP,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	217: {
		ins: INS_CMP,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 4
	},
	193: {
		ins: INS_CMP,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 6
	},
	209: {
		ins: INS_CMP,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 5
	},
	224: {
		ins: INS_CPX,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	228: {
		ins: INS_CPX,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	236: {
		ins: INS_CPX,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	192: {
		ins: INS_CPY,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	196: {
		ins: INS_CPY,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	204: {
		ins: INS_CPY,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	198: {
		ins: INS_DEC,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	214: {
		ins: INS_DEC,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	206: {
		ins: INS_DEC,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	222: {
		ins: INS_DEC,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	202: {
		ins: INS_DEX,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	136: {
		ins: INS_DEY,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	73: {
		ins: INS_EOR,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	69: {
		ins: INS_EOR,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	85: {
		ins: INS_EOR,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	77: {
		ins: INS_EOR,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	93: {
		ins: INS_EOR,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	89: {
		ins: INS_EOR,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 4
	},
	65: {
		ins: INS_EOR,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 6
	},
	81: {
		ins: INS_EOR,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 5
	},
	230: {
		ins: INS_INC,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	246: {
		ins: INS_INC,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	238: {
		ins: INS_INC,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	254: {
		ins: INS_INC,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	232: {
		ins: INS_INX,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	200: {
		ins: INS_INY,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	76: {
		ins: INS_JMP,
		mode: ADDR_ABS,
		size: 3,
		cycles: 3
	},
	108: {
		ins: INS_JMP,
		mode: ADDR_INDABS,
		size: 3,
		cycles: 5
	},
	32: {
		ins: INS_JSR,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	169: {
		ins: INS_LDA,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	165: {
		ins: INS_LDA,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	181: {
		ins: INS_LDA,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	173: {
		ins: INS_LDA,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	189: {
		ins: INS_LDA,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	185: {
		ins: INS_LDA,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 4
	},
	161: {
		ins: INS_LDA,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 6
	},
	177: {
		ins: INS_LDA,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 5
	},
	162: {
		ins: INS_LDX,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	166: {
		ins: INS_LDX,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	182: {
		ins: INS_LDX,
		mode: ADDR_ZPY,
		size: 2,
		cycles: 4
	},
	174: {
		ins: INS_LDX,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	190: {
		ins: INS_LDX,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 4
	},
	160: {
		ins: INS_LDY,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	164: {
		ins: INS_LDY,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	180: {
		ins: INS_LDY,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	172: {
		ins: INS_LDY,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	188: {
		ins: INS_LDY,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	74: {
		ins: INS_LSR,
		mode: ADDR_ACC,
		size: 1,
		cycles: 2
	},
	70: {
		ins: INS_LSR,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	86: {
		ins: INS_LSR,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	78: {
		ins: INS_LSR,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	94: {
		ins: INS_LSR,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	26: {
		ins: INS_NOP,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	58: {
		ins: INS_NOP,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	90: {
		ins: INS_NOP,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	122: {
		ins: INS_NOP,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	218: {
		ins: INS_NOP,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	234: {
		ins: INS_NOP,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	250: {
		ins: INS_NOP,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	9: {
		ins: INS_ORA,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	5: {
		ins: INS_ORA,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	21: {
		ins: INS_ORA,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	13: {
		ins: INS_ORA,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	29: {
		ins: INS_ORA,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	25: {
		ins: INS_ORA,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 4
	},
	1: {
		ins: INS_ORA,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 6
	},
	17: {
		ins: INS_ORA,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 5
	},
	72: {
		ins: INS_PHA,
		mode: ADDR_IMP,
		size: 1,
		cycles: 3
	},
	8: {
		ins: INS_PHP,
		mode: ADDR_IMP,
		size: 1,
		cycles: 3
	},
	104: {
		ins: INS_PLA,
		mode: ADDR_IMP,
		size: 1,
		cycles: 4
	},
	40: {
		ins: INS_PLP,
		mode: ADDR_IMP,
		size: 1,
		cycles: 4
	},
	42: {
		ins: INS_ROL,
		mode: ADDR_ACC,
		size: 1,
		cycles: 2
	},
	38: {
		ins: INS_ROL,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	54: {
		ins: INS_ROL,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	46: {
		ins: INS_ROL,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	62: {
		ins: INS_ROL,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	106: {
		ins: INS_ROR,
		mode: ADDR_ACC,
		size: 1,
		cycles: 2
	},
	102: {
		ins: INS_ROR,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	118: {
		ins: INS_ROR,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	110: {
		ins: INS_ROR,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	126: {
		ins: INS_ROR,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	64: {
		ins: INS_RTI,
		mode: ADDR_IMP,
		size: 1,
		cycles: 6
	},
	96: {
		ins: INS_RTS,
		mode: ADDR_IMP,
		size: 1,
		cycles: 6
	},
	233: {
		ins: INS_SBC,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	235: {
		ins: INS_SBC,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	229: {
		ins: INS_SBC,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	245: {
		ins: INS_SBC,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	237: {
		ins: INS_SBC,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	253: {
		ins: INS_SBC,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	249: {
		ins: INS_SBC,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 4
	},
	225: {
		ins: INS_SBC,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 6
	},
	241: {
		ins: INS_SBC,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 5
	},
	56: {
		ins: INS_SEC,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	248: {
		ins: INS_SED,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	120: {
		ins: INS_SEI,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	133: {
		ins: INS_STA,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	149: {
		ins: INS_STA,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	141: {
		ins: INS_STA,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	157: {
		ins: INS_STA,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 5
	},
	153: {
		ins: INS_STA,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 5
	},
	129: {
		ins: INS_STA,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 6
	},
	145: {
		ins: INS_STA,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 6
	},
	134: {
		ins: INS_STX,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	150: {
		ins: INS_STX,
		mode: ADDR_ZPY,
		size: 2,
		cycles: 4
	},
	142: {
		ins: INS_STX,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	132: {
		ins: INS_STY,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	148: {
		ins: INS_STY,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	140: {
		ins: INS_STY,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	170: {
		ins: INS_TAX,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	168: {
		ins: INS_TAY,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	186: {
		ins: INS_TSX,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	138: {
		ins: INS_TXA,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	154: {
		ins: INS_TXS,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	152: {
		ins: INS_TYA,
		mode: ADDR_IMP,
		size: 1,
		cycles: 2
	},
	75: {
		ins: INS_ALR,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	11: {
		ins: INS_ANC,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	43: {
		ins: INS_ANC,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	107: {
		ins: INS_ARR,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	203: {
		ins: INS_AXS,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	163: {
		ins: INS_LAX,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 6
	},
	167: {
		ins: INS_LAX,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	175: {
		ins: INS_LAX,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	179: {
		ins: INS_LAX,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 5
	},
	183: {
		ins: INS_LAX,
		mode: ADDR_ZPY,
		size: 2,
		cycles: 4
	},
	191: {
		ins: INS_LAX,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 4
	},
	131: {
		ins: INS_SAX,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 6
	},
	135: {
		ins: INS_SAX,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	143: {
		ins: INS_SAX,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	151: {
		ins: INS_SAX,
		mode: ADDR_ZPY,
		size: 2,
		cycles: 4
	},
	195: {
		ins: INS_DCP,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 8
	},
	199: {
		ins: INS_DCP,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	207: {
		ins: INS_DCP,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	211: {
		ins: INS_DCP,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 8
	},
	215: {
		ins: INS_DCP,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	219: {
		ins: INS_DCP,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 7
	},
	223: {
		ins: INS_DCP,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	227: {
		ins: INS_ISC,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 8
	},
	231: {
		ins: INS_ISC,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	239: {
		ins: INS_ISC,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	243: {
		ins: INS_ISC,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 8
	},
	247: {
		ins: INS_ISC,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	251: {
		ins: INS_ISC,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 7
	},
	255: {
		ins: INS_ISC,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	35: {
		ins: INS_RLA,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 8
	},
	39: {
		ins: INS_RLA,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	47: {
		ins: INS_RLA,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	51: {
		ins: INS_RLA,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 8
	},
	55: {
		ins: INS_RLA,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	59: {
		ins: INS_RLA,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 7
	},
	63: {
		ins: INS_RLA,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	99: {
		ins: INS_RRA,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 8
	},
	103: {
		ins: INS_RRA,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	111: {
		ins: INS_RRA,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	115: {
		ins: INS_RRA,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 8
	},
	119: {
		ins: INS_RRA,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	123: {
		ins: INS_RRA,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 7
	},
	127: {
		ins: INS_RRA,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	3: {
		ins: INS_SLO,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 8
	},
	7: {
		ins: INS_SLO,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	15: {
		ins: INS_SLO,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	19: {
		ins: INS_SLO,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 8
	},
	23: {
		ins: INS_SLO,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	27: {
		ins: INS_SLO,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 7
	},
	31: {
		ins: INS_SLO,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	67: {
		ins: INS_SRE,
		mode: ADDR_PREIDXIND,
		size: 2,
		cycles: 8
	},
	71: {
		ins: INS_SRE,
		mode: ADDR_ZP,
		size: 2,
		cycles: 5
	},
	79: {
		ins: INS_SRE,
		mode: ADDR_ABS,
		size: 3,
		cycles: 6
	},
	83: {
		ins: INS_SRE,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 8
	},
	87: {
		ins: INS_SRE,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 6
	},
	91: {
		ins: INS_SRE,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 7
	},
	95: {
		ins: INS_SRE,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 7
	},
	128: {
		ins: INS_SKB,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	130: {
		ins: INS_SKB,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	137: {
		ins: INS_SKB,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	194: {
		ins: INS_SKB,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	226: {
		ins: INS_SKB,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	12: {
		ins: INS_IGN,
		mode: ADDR_ABS,
		size: 3,
		cycles: 4
	},
	28: {
		ins: INS_IGN,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	60: {
		ins: INS_IGN,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	92: {
		ins: INS_IGN,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	124: {
		ins: INS_IGN,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	220: {
		ins: INS_IGN,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	252: {
		ins: INS_IGN,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 4
	},
	4: {
		ins: INS_IGN,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	68: {
		ins: INS_IGN,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	100: {
		ins: INS_IGN,
		mode: ADDR_ZP,
		size: 2,
		cycles: 3
	},
	20: {
		ins: INS_IGN,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	52: {
		ins: INS_IGN,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	84: {
		ins: INS_IGN,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	116: {
		ins: INS_IGN,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	212: {
		ins: INS_IGN,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	244: {
		ins: INS_IGN,
		mode: ADDR_ZPX,
		size: 2,
		cycles: 4
	},
	147: {
		ins: INS_SHA,
		mode: ADDR_POSTIDXIND,
		size: 2,
		cycles: 6
	},
	159: {
		ins: INS_SHA,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 5
	},
	155: {
		ins: INS_SHS,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 5
	},
	156: {
		ins: INS_SHY,
		mode: ADDR_ABSX,
		size: 3,
		cycles: 5
	},
	158: {
		ins: INS_SHX,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 5
	},
	187: {
		ins: 75,
		mode: ADDR_ABSY,
		size: 3,
		cycles: 4
	},
	139: {
		ins: 76,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	},
	171: {
		ins: 77,
		mode: ADDR_IMM,
		size: 2,
		cycles: 2
	}
};
var KIND_READ = 0;
var KIND_WRITE = 1;
var KIND_SPECIAL = 2;
var OP_INS = (/* @__PURE__ */ new Uint8Array(256)).fill(255);
var OP_MODE = /* @__PURE__ */ new Uint8Array(256);
var OP_KIND = /* @__PURE__ */ new Uint8Array(256);
for (const key of Object.keys(OPCODE_TABLE)) {
	const op = Number(key);
	const info = OPCODE_TABLE[op];
	OP_INS[op] = info.ins;
	OP_MODE[op] = info.mode;
	let kind = KIND_READ;
	switch (info.ins) {
		case INS_STA:
		case INS_STX:
		case INS_STY:
		case INS_SAX:
		case INS_SHA:
		case INS_SHS:
		case INS_SHX:
		case INS_SHY:
		case INS_ASL:
		case INS_LSR:
		case INS_ROL:
		case INS_ROR:
		case INS_INC:
		case INS_DEC:
		case INS_SLO:
		case INS_SRE:
		case INS_RLA:
		case INS_RRA:
		case INS_DCP:
		case INS_ISC:
			kind = KIND_WRITE;
			break;
		case INS_JSR:
		case INS_BRK:
		case INS_RTI:
		case INS_RTS:
		case INS_PHA:
		case INS_PHP:
		case INS_PLA:
		case INS_PLP: kind = KIND_SPECIAL;
	}
	if (info.mode === ADDR_REL || info.mode === ADDR_IMP || info.mode === ADDR_ACC || info.mode === ADDR_INDABS) kind = KIND_SPECIAL;
	OP_KIND[op] = kind;
}
var VECTOR_NMI = 65530;
var VECTOR_RESET = 65532;
var VECTOR_IRQ = 65534;
var CPU = class {
	IRQ_NORMAL = 0;
	IRQ_NMI = 1;
	IRQ_RESET = 2;
	constructor(nes) {
		this.nes = nes;
		this.mem = /* @__PURE__ */ new Uint8Array(65536);
		this.mem.fill(255, 0, 8192);
		for (let p = 0; p < 4; p++) {
			let j = p * 2048;
			this.mem[j + 8] = 247;
			this.mem[j + 9] = 239;
			this.mem[j + 10] = 223;
			this.mem[j + 15] = 191;
		}
		this.REG_ACC = 0;
		this.REG_X = 0;
		this.REG_Y = 0;
		this.REG_SP = 0;
		this.REG_PC = 32768;
		this.F_CARRY = 0;
		this.F_ZERO = 1;
		this.F_INTERRUPT = 1;
		this.F_DECIMAL = 0;
		this.F_OVERFLOW = 0;
		this.F_SIGN = 0;
		this.F_BRK = 1;
		this.F_NOTUSED = 1;
		this.cycles = 0;
		this.dataBus = 0;
		this.irqFlags = 0;
		this.resetPending = false;
		this.nmiLine = false;
		this.needNmi = false;
		this.prevNeedNmi = false;
		this.runIrq = false;
		this.prevRunIrq = false;
		this.forcedNmi = false;
		this.dmaNeedHalt = false;
		this.dmcDmaRunning = false;
		this.dmcNeedDummy = false;
		this.dmcDmaAbort = false;
		this.oamDmaRunning = false;
		this.oamDmaPage = 0;
		this.lastDmaEndCycle = -1;
		this.abortedDmaCycle = -1;
		this._gameGenieActive = false;
		this.directPrgReads = false;
		this.ppu = nes.ppu;
		this.papu = nes.papu;
	}
	read(addr) {
		if (this.dmaNeedHalt) this._runDma(addr);
		this.cycles++;
		if (this.cycles >= this.papu.nextEventCycle) this.papu.catchUp(this.cycles);
		let value;
		if (addr < 8192) value = this.dataBus = this.mem[addr & 2047];
		else if (addr >= 32768 && this.directPrgReads) value = this.dataBus = this.mem[addr];
		else if (addr === 16405) value = this.nes.mmap.load(addr);
		else {
			if (addr < 32768 && (addr < 16384 || addr >= 16416 || addr === 16407)) this._syncPpu(addr);
			value = this.nes.mmap.load(addr);
			if (this._gameGenieActive && addr >= 32768) value = this.nes.gameGenie.applyCodes(addr, value);
			this.dataBus = value;
		}
		this._endCycle();
		return value;
	}
	_syncPpu(addr) {
		const ppu = this.ppu;
		ppu.catchUp();
		if (addr < 16384) ppu.nextEventDot = 0;
	}
	write(addr, value) {
		if (this.abortedDmaCycle === this.cycles + 1 && this.dmcDmaAbort) {
			this.dmcDmaRunning = false;
			this.dmcDmaAbort = false;
			this.dmaNeedHalt = this.oamDmaRunning;
		}
		this.cycles++;
		if (this.cycles >= this.papu.nextEventCycle) this.papu.catchUp(this.cycles);
		this.dataBus = value;
		if (addr < 8192) this.mem[addr & 2047] = value;
		else {
			if (addr < 16384 || addr >= 16416) this._syncPpu(addr);
			this.nes.mmap.write(addr, value);
		}
		this._endCycle();
	}
	_endCycle() {
		const ppu = this.ppu;
		ppu.dotTarget += 3;
		let nmi;
		if (ppu.dotTarget > ppu.nextEventDot) {
			ppu.runCycleExact();
			nmi = ppu.nmiAtPoll;
		} else nmi = ppu.nmiOutput;
		this.prevNeedNmi = this.needNmi;
		if (nmi && !this.nmiLine) this.needNmi = true;
		this.nmiLine = nmi;
		this.prevRunIrq = this.runIrq;
		this.runIrq = this.irqFlags !== 0 && this.F_INTERRUPT === 0;
	}
	_fetch() {
		const v = this.read(this.REG_PC);
		this.REG_PC = this.REG_PC + 1 & 65535;
		return v;
	}
	push(value) {
		this.write(256 | this.REG_SP, value);
		this.REG_SP = this.REG_SP - 1 & 255;
	}
	pull() {
		this.REG_SP = this.REG_SP + 1 & 255;
		return this.read(256 | this.REG_SP);
	}
	load(addr) {
		return this.read(addr);
	}
	requestIrq(type) {
		if (type === this.IRQ_NORMAL) this.irqFlags |= 1;
		else if (type === this.IRQ_NMI) {
			this.forcedNmi = true;
			this.needNmi = true;
			this.prevNeedNmi = true;
		} else if (type === this.IRQ_RESET) this.resetPending = true;
	}
	clearIrq() {
		this.irqFlags &= -2;
	}
	setIrqSource(source, active) {
		if (active) this.irqFlags |= source;
		else this.irqFlags &= ~source;
	}
	get irqRequested() {
		return this.irqFlags !== 0 || this.resetPending || this.forcedNmi;
	}
	set irqRequested(value) {
		if (!value) {
			this.irqFlags = 0;
			this.resetPending = false;
			this.forcedNmi = false;
		}
	}
	startDmcDma() {
		this.dmcDmaRunning = true;
		this.dmcNeedDummy = true;
		this.dmaNeedHalt = true;
	}
	stopDmcDma() {
		if (!this.dmcDmaRunning) return;
		if (this.dmaNeedHalt && !this.oamDmaRunning) {
			this.dmcDmaRunning = false;
			this.dmcNeedDummy = false;
			this.dmaNeedHalt = false;
		} else this.dmcDmaAbort = true;
	}
	startAbortedDmcDma() {
		if (this.dmcDmaRunning) return;
		this.dmcDmaRunning = true;
		this.dmcDmaAbort = true;
		this.dmaNeedHalt = true;
		this.abortedDmaCycle = this.cycles + 1;
	}
	startOamDma(page) {
		this.oamDmaRunning = true;
		this.oamDmaPage = page;
		this.dmaNeedHalt = true;
	}
	_haltedRead(addr, skipRead) {
		this.cycles++;
		if (this.cycles >= this.papu.nextEventCycle) this.papu.catchUp(this.cycles);
		if (!skipRead) this._dmaBusRead(addr);
		this._endCycle();
	}
	_dmaBusRead(addr) {
		let value;
		if (addr < 8192) value = this.mem[addr & 2047];
		else {
			if (addr < 32768 && (addr < 16384 || addr >= 16416 || addr === 16407)) this._syncPpu(addr);
			value = this.nes.mmap.load(addr);
			if (addr === 16405) return value;
		}
		this.dataBus = value;
		return value;
	}
	_dmaFetch(addr, haltedAddr) {
		this.cycles++;
		if (this.cycles >= this.papu.nextEventCycle) this.papu.catchUp(this.cycles);
		let value;
		if ((haltedAddr & 65504) !== 16384) {
			if (addr >= 16384 && addr <= 16415) value = this.dataBus;
			else value = this._dmaBusRead(addr);
			this._lastDmaReadAddr = addr;
		} else {
			const internal = 16384 | addr & 31;
			if (internal === 16405) {
				const status = this.nes.mmap.load(16405);
				const external = addr === internal ? this.dataBus : this._dmaBusRead(addr);
				value = status & 223 | external & 32;
			} else if (internal === 16406 || internal === 16407) {
				let port;
				if (this._lastDmaReadAddr === internal) port = this.dataBus;
				else port = this.nes.mmap.load(internal);
				const external = addr === internal ? this.dataBus : this._dmaBusRead(addr);
				value = this.dataBus = external & 224 | port & 31;
			} else value = this._dmaBusRead(addr);
			this._lastDmaReadAddr = internal;
		}
		this._endCycle();
		return value;
	}
	_dmaWrite(addr, value) {
		this.cycles++;
		if (this.cycles >= this.papu.nextEventCycle) this.papu.catchUp(this.cycles);
		this.dataBus = value;
		this._syncPpu(addr);
		this.nes.mmap.write(addr, value);
		this._endCycle();
	}
	_runDma(addr) {
		this._runDmaCycles(addr);
		this.lastDmaEndCycle = this.cycles;
	}
	_runDmaCycles(addr) {
		this.dmaNeedHalt = false;
		this._lastDmaReadAddr = addr;
		const isController = addr === 16406 || addr === 16407;
		const skipRepeatReads = isController;
		let skipFirstRead = false;
		if (this.dmcDmaRunning && isController) {
			if ((this.nes.papu.dmc.currentAddress & 31) === (addr & 31)) skipFirstRead = true;
		}
		this._haltedRead(addr, skipFirstRead || this.dmcDmaAbort && isController);
		if (this.dmcDmaAbort) {
			this.dmcDmaRunning = false;
			this.dmcDmaAbort = false;
			this.dmcNeedDummy = false;
			if (!this.oamDmaRunning) return;
		}
		let oamCount = 0;
		let oamAddr = 0;
		let oamValue = 0;
		while (this.dmcDmaRunning || this.oamDmaRunning) {
			const getCycle = (this.cycles + 1 & 1) === 0;
			let dmcReady = this.dmcDmaRunning && !this.dmaNeedHalt && !this.dmcNeedDummy;
			if (this.dmcDmaAbort) {
				this.dmcDmaRunning = false;
				this.dmcDmaAbort = false;
				this.dmcNeedDummy = false;
				this.dmaNeedHalt = false;
				dmcReady = false;
			} else if (this.dmaNeedHalt) this.dmaNeedHalt = false;
			else if (this.dmcNeedDummy) this.dmcNeedDummy = false;
			if (getCycle) {
				if (dmcReady) {
					const dmc = this.nes.papu.dmc;
					const value = this._dmaFetch(dmc.currentAddress, addr);
					this.dmcDmaRunning = false;
					this.dmcDmaAbort = false;
					dmc.dmaComplete(value);
				} else if (this.oamDmaRunning && (oamCount & 1) === 0) {
					oamValue = this._dmaFetch(this.oamDmaPage << 8 | oamAddr, addr);
					oamAddr = oamAddr + 1 & 255;
					oamCount++;
				} else this._haltedRead(addr, skipRepeatReads);
			} else if (this.oamDmaRunning && (oamCount & 1) === 1) {
				this._dmaWrite(8196, oamValue);
				oamCount++;
				if (oamCount === 512) this.oamDmaRunning = false;
			} else this._haltedRead(addr, skipRepeatReads);
		}
	}
	emulate() {
		const startCycles = this.cycles;
		if (this.resetPending) {
			this.resetPending = false;
			this._interruptSequence(VECTOR_RESET);
			return this.cycles - startCycles;
		}
		const opcode = this._fetch();
		const ins = OP_INS[opcode];
		const mode = OP_MODE[opcode];
		let addr = 0;
		let baseHigh = 0;
		let crossed = false;
		if (OP_KIND[opcode] !== KIND_SPECIAL) {
			const write = OP_KIND[opcode] === KIND_WRITE;
			switch (mode) {
				case 5:
					addr = this.REG_PC;
					this.REG_PC = this.REG_PC + 1 & 65535;
					break;
				case 0:
					addr = this._fetch();
					break;
				case 6:
				case 7: {
					const base = this._fetch();
					this.read(base);
					addr = base + (mode === 6 ? this.REG_X : this.REG_Y) & 255;
					break;
				}
				case 3: {
					const lo = this._fetch();
					addr = this._fetch() << 8 | lo;
					break;
				}
				case 8:
				case 9: {
					const lo = this._fetch();
					baseHigh = this._fetch();
					const base = baseHigh << 8 | lo;
					addr = base + (mode === 8 ? this.REG_X : this.REG_Y) & 65535;
					crossed = (addr & 65280) !== (base & 65280);
					if (crossed || write) this.read(base & 65280 | addr & 255);
					break;
				}
				case 10: {
					let ptr = this._fetch();
					this.read(ptr);
					ptr = ptr + this.REG_X & 255;
					const lo = this.read(ptr);
					addr = this.read(ptr + 1 & 255) << 8 | lo;
					break;
				}
				case 11: {
					const ptr = this._fetch();
					const lo = this.read(ptr);
					baseHigh = this.read(ptr + 1 & 255);
					const base = baseHigh << 8 | lo;
					addr = base + this.REG_Y & 65535;
					crossed = (addr & 65280) !== (base & 65280);
					if (crossed || write) this.read(base & 65280 | addr & 255);
					break;
				}
			}
		}
		let temp;
		let value;
		switch (ins) {
			case 0:
				this._adc(this.read(addr));
				break;
			case 1:
				this.REG_ACC &= this.read(addr);
				this.F_SIGN = this.REG_ACC >> 7;
				this.F_ZERO = this.REG_ACC;
				break;
			case 2:
				if (mode === ADDR_ACC) {
					this.read(this.REG_PC);
					this.REG_ACC = this._asl(this.REG_ACC);
				} else {
					value = this.read(addr);
					this.write(addr, value);
					this.write(addr, this._asl(value));
				}
				break;
			case 3:
				this._branch(this.F_CARRY === 0);
				break;
			case 4:
				this._branch(this.F_CARRY !== 0);
				break;
			case 5:
				this._branch(this.F_ZERO === 0);
				break;
			case 6:
				value = this.read(addr);
				this.F_SIGN = value >> 7 & 1;
				this.F_OVERFLOW = value >> 6 & 1;
				this.F_ZERO = value & this.REG_ACC;
				break;
			case 7:
				this._branch(this.F_SIGN !== 0);
				break;
			case 8:
				this._branch(this.F_ZERO !== 0);
				break;
			case 9:
				this._branch(this.F_SIGN === 0);
				break;
			case 10:
				this._fetch();
				this._interruptSequence(VECTOR_IRQ, true);
				break;
			case 11:
				this._branch(this.F_OVERFLOW === 0);
				break;
			case 12:
				this._branch(this.F_OVERFLOW !== 0);
				break;
			case 13:
				this.read(this.REG_PC);
				this.F_CARRY = 0;
				break;
			case 14:
				this.read(this.REG_PC);
				this.F_DECIMAL = 0;
				break;
			case 15:
				this.read(this.REG_PC);
				this.F_INTERRUPT = 0;
				break;
			case 16:
				this.read(this.REG_PC);
				this.F_OVERFLOW = 0;
				break;
			case 17:
				this._compare(this.REG_ACC, this.read(addr));
				break;
			case 18:
				this._compare(this.REG_X, this.read(addr));
				break;
			case 19:
				this._compare(this.REG_Y, this.read(addr));
				break;
			case 20:
				value = this.read(addr);
				this.write(addr, value);
				value = value - 1 & 255;
				this.F_SIGN = value >> 7;
				this.F_ZERO = value;
				this.write(addr, value);
				break;
			case 21:
				this.read(this.REG_PC);
				this.REG_X = this.REG_X - 1 & 255;
				this.F_SIGN = this.REG_X >> 7;
				this.F_ZERO = this.REG_X;
				break;
			case 22:
				this.read(this.REG_PC);
				this.REG_Y = this.REG_Y - 1 & 255;
				this.F_SIGN = this.REG_Y >> 7;
				this.F_ZERO = this.REG_Y;
				break;
			case 23:
				this.REG_ACC ^= this.read(addr);
				this.F_SIGN = this.REG_ACC >> 7;
				this.F_ZERO = this.REG_ACC;
				break;
			case 24:
				value = this.read(addr);
				this.write(addr, value);
				value = value + 1 & 255;
				this.F_SIGN = value >> 7;
				this.F_ZERO = value;
				this.write(addr, value);
				break;
			case 25:
				this.read(this.REG_PC);
				this.REG_X = this.REG_X + 1 & 255;
				this.F_SIGN = this.REG_X >> 7;
				this.F_ZERO = this.REG_X;
				break;
			case 26:
				this.read(this.REG_PC);
				this.REG_Y = this.REG_Y + 1 & 255;
				this.F_SIGN = this.REG_Y >> 7;
				this.F_ZERO = this.REG_Y;
				break;
			case 27:
				if (mode === ADDR_INDABS) {
					const lo = this._fetch();
					const ptr = this._fetch() << 8 | lo;
					const pcl = this.read(ptr);
					const pch = this.read(ptr & 65280 | ptr + 1 & 255);
					this.REG_PC = pch << 8 | pcl;
				} else this.REG_PC = addr;
				break;
			case 28: {
				const lo = this._fetch();
				this.read(256 | this.REG_SP);
				this.push(this.REG_PC >> 8);
				this.push(this.REG_PC & 255);
				const hi = this.read(this.REG_PC);
				this.REG_PC = hi << 8 | lo;
				break;
			}
			case 29:
				this.REG_ACC = this.F_ZERO = this.read(addr);
				this.F_SIGN = this.REG_ACC >> 7;
				break;
			case 30:
				this.REG_X = this.F_ZERO = this.read(addr);
				this.F_SIGN = this.REG_X >> 7;
				break;
			case 31:
				this.REG_Y = this.F_ZERO = this.read(addr);
				this.F_SIGN = this.REG_Y >> 7;
				break;
			case 32:
				if (mode === ADDR_ACC) {
					this.read(this.REG_PC);
					this.REG_ACC = this._lsr(this.REG_ACC);
				} else {
					value = this.read(addr);
					this.write(addr, value);
					this.write(addr, this._lsr(value));
				}
				break;
			case 33:
				this.read(this.REG_PC);
				break;
			case 34:
				this.REG_ACC |= this.read(addr);
				this.F_SIGN = this.REG_ACC >> 7;
				this.F_ZERO = this.REG_ACC;
				break;
			case 35:
				this.read(this.REG_PC);
				this.push(this.REG_ACC);
				break;
			case 36:
				this.read(this.REG_PC);
				this.push(this.getStatus() | 48);
				break;
			case 37:
				this.read(this.REG_PC);
				this.read(256 | this.REG_SP);
				this.REG_ACC = this.F_ZERO = this.pull();
				this.F_SIGN = this.REG_ACC >> 7;
				break;
			case 38:
				this.read(this.REG_PC);
				this.read(256 | this.REG_SP);
				this.setStatusFromStack(this.pull());
				break;
			case 39:
				if (mode === ADDR_ACC) {
					this.read(this.REG_PC);
					this.REG_ACC = this._rol(this.REG_ACC);
				} else {
					value = this.read(addr);
					this.write(addr, value);
					this.write(addr, this._rol(value));
				}
				break;
			case 40:
				if (mode === ADDR_ACC) {
					this.read(this.REG_PC);
					this.REG_ACC = this._ror(this.REG_ACC);
				} else {
					value = this.read(addr);
					this.write(addr, value);
					this.write(addr, this._ror(value));
				}
				break;
			case 41: {
				this.read(this.REG_PC);
				this.read(256 | this.REG_SP);
				this.setStatusFromStack(this.pull());
				const pcl = this.pull();
				const pch = this.pull();
				this.REG_PC = pch << 8 | pcl;
				break;
			}
			case 42: {
				this.read(this.REG_PC);
				this.read(256 | this.REG_SP);
				const pcl = this.pull();
				const pch = this.pull();
				this.REG_PC = pch << 8 | pcl;
				this.read(this.REG_PC);
				this.REG_PC = this.REG_PC + 1 & 65535;
				break;
			}
			case 43:
				this._adc(this.read(addr) ^ 255);
				break;
			case 44:
				this.read(this.REG_PC);
				this.F_CARRY = 1;
				break;
			case 45:
				this.read(this.REG_PC);
				this.F_DECIMAL = 1;
				break;
			case 46:
				this.read(this.REG_PC);
				this.F_INTERRUPT = 1;
				break;
			case 47:
				this.write(addr, this.REG_ACC);
				break;
			case 48:
				this.write(addr, this.REG_X);
				break;
			case 49:
				this.write(addr, this.REG_Y);
				break;
			case 50:
				this.read(this.REG_PC);
				this.REG_X = this.F_ZERO = this.REG_ACC;
				this.F_SIGN = this.REG_ACC >> 7;
				break;
			case 51:
				this.read(this.REG_PC);
				this.REG_Y = this.F_ZERO = this.REG_ACC;
				this.F_SIGN = this.REG_ACC >> 7;
				break;
			case 52:
				this.read(this.REG_PC);
				this.REG_X = this.F_ZERO = this.REG_SP;
				this.F_SIGN = this.REG_SP >> 7;
				break;
			case 53:
				this.read(this.REG_PC);
				this.REG_ACC = this.F_ZERO = this.REG_X;
				this.F_SIGN = this.REG_X >> 7;
				break;
			case 54:
				this.read(this.REG_PC);
				this.REG_SP = this.REG_X;
				break;
			case 55:
				this.read(this.REG_PC);
				this.REG_ACC = this.F_ZERO = this.REG_Y;
				this.F_SIGN = this.REG_Y >> 7;
				break;
			case 56:
				this.REG_ACC = this._lsr(this.REG_ACC & this.read(addr));
				break;
			case 57:
				this.REG_ACC &= this.read(addr);
				this.F_SIGN = this.F_CARRY = this.REG_ACC >> 7;
				this.F_ZERO = this.REG_ACC;
				break;
			case 58:
				temp = this.REG_ACC & this.read(addr);
				this.REG_ACC = (temp >> 1 | this.F_CARRY << 7) & 255;
				this.F_ZERO = this.REG_ACC;
				this.F_SIGN = this.REG_ACC >> 7;
				this.F_CARRY = this.REG_ACC >> 6 & 1;
				this.F_OVERFLOW = (this.REG_ACC >> 6 ^ this.REG_ACC >> 5) & 1;
				break;
			case 59:
				temp = (this.REG_ACC & this.REG_X) - this.read(addr);
				this.F_CARRY = temp >= 0 ? 1 : 0;
				this.REG_X = this.F_ZERO = temp & 255;
				this.F_SIGN = this.REG_X >> 7;
				break;
			case 60:
				this.REG_ACC = this.REG_X = this.F_ZERO = this.read(addr);
				this.F_SIGN = this.REG_ACC >> 7;
				break;
			case 61:
				this.write(addr, this.REG_ACC & this.REG_X);
				break;
			case 62:
				value = this.read(addr);
				this.write(addr, value);
				value = value - 1 & 255;
				this.write(addr, value);
				this._compare(this.REG_ACC, value);
				break;
			case 63:
				value = this.read(addr);
				this.write(addr, value);
				value = value + 1 & 255;
				this.write(addr, value);
				this._adc(value ^ 255);
				break;
			case 64:
				value = this.read(addr);
				this.write(addr, value);
				value = this._rol(value);
				this.write(addr, value);
				this.REG_ACC &= value;
				this.F_SIGN = this.REG_ACC >> 7;
				this.F_ZERO = this.REG_ACC;
				break;
			case 65:
				value = this.read(addr);
				this.write(addr, value);
				value = this._ror(value);
				this.write(addr, value);
				this._adc(value);
				break;
			case 66:
				value = this.read(addr);
				this.write(addr, value);
				value = this._asl(value);
				this.write(addr, value);
				this.REG_ACC |= value;
				this.F_SIGN = this.REG_ACC >> 7;
				this.F_ZERO = this.REG_ACC;
				break;
			case 67:
				value = this.read(addr);
				this.write(addr, value);
				value = this._lsr(value);
				this.write(addr, value);
				this.REG_ACC ^= value;
				this.F_SIGN = this.REG_ACC >> 7;
				this.F_ZERO = this.REG_ACC;
				break;
			case 68:
				this.read(addr);
				break;
			case 69:
				this.read(addr);
				break;
			case 71:
				this._shx(addr, this.REG_ACC & this.REG_X, baseHigh, crossed);
				break;
			case 72:
				this.REG_SP = this.REG_ACC & this.REG_X;
				this._shx(addr, this.REG_SP, baseHigh, crossed);
				break;
			case 73:
				this._shx(addr, this.REG_Y, baseHigh, crossed);
				break;
			case 74:
				this._shx(addr, this.REG_X, baseHigh, crossed);
				break;
			case 75:
				temp = this.read(addr) & this.REG_SP;
				this.REG_ACC = this.REG_X = this.REG_SP = this.F_ZERO = temp;
				this.F_SIGN = temp >> 7;
				break;
			case 76:
				this.REG_ACC = this.F_ZERO = (this.REG_ACC | 255) & this.REG_X & this.read(addr);
				this.F_SIGN = this.REG_ACC >> 7;
				break;
			case 77:
				this.REG_ACC = this.REG_X = this.F_ZERO = (this.REG_ACC | 255) & this.read(addr);
				this.F_SIGN = this.REG_ACC >> 7;
				break;
			default: throw new Error(`Game crashed, invalid opcode at address $${(this.REG_PC - 1 & 65535).toString(16)}`);
		}
		if (this.prevNeedNmi || this.prevRunIrq) this._interruptSequence(VECTOR_IRQ, false);
		return this.cycles - startCycles;
	}
	_interruptSequence(vector, isBrk) {
		const isReset = vector === VECTOR_RESET;
		if (!isBrk) {
			this.read(this.REG_PC);
			this.read(this.REG_PC);
		}
		if (isReset) {
			this.read(256 | this.REG_SP);
			this.REG_SP = this.REG_SP - 1 & 255;
			this.read(256 | this.REG_SP);
			this.REG_SP = this.REG_SP - 1 & 255;
			this.read(256 | this.REG_SP);
			this.REG_SP = this.REG_SP - 1 & 255;
		} else {
			this.push(this.REG_PC >> 8);
			this.push(this.REG_PC & 255);
			if (this.needNmi) {
				this.needNmi = false;
				this.forcedNmi = false;
				vector = VECTOR_NMI;
			} else if (!isBrk) this.irqFlags &= -2;
			this.push(this.getStatus() & 207 | (isBrk ? 48 : 32));
		}
		this.F_INTERRUPT = 1;
		const lo = this.read(vector);
		const hi = this.read(vector + 1);
		this.REG_PC = hi << 8 | lo;
		this.prevNeedNmi = false;
		this.prevRunIrq = false;
	}
	_branch(condition) {
		const offset = this._fetch();
		if (!condition) return;
		if (this.runIrq && !this.prevRunIrq) this.runIrq = false;
		this.read(this.REG_PC);
		const target = this.REG_PC + (offset < 128 ? offset : offset - 256) & 65535;
		if ((target & 65280) !== (this.REG_PC & 65280)) this.read(this.REG_PC & 65280 | target & 255);
		this.REG_PC = target;
	}
	_shx(addr, reg, baseHigh, crossed) {
		let value;
		if (this.lastDmaEndCycle === this.cycles - 1) value = reg;
		else value = reg & (baseHigh + 1 & 255);
		if (crossed) addr = value << 8 | addr & 255;
		this.write(addr, value);
	}
	_adc(value) {
		const result = this.REG_ACC + value + this.F_CARRY;
		this.F_OVERFLOW = ((this.REG_ACC ^ result) & (value ^ result) & 128) !== 0 ? 1 : 0;
		this.F_CARRY = result > 255 ? 1 : 0;
		this.REG_ACC = this.F_ZERO = result & 255;
		this.F_SIGN = this.REG_ACC >> 7;
	}
	_compare(reg, value) {
		const result = reg - value;
		this.F_CARRY = result >= 0 ? 1 : 0;
		this.F_ZERO = result & 255;
		this.F_SIGN = result >> 7 & 1;
	}
	_asl(value) {
		this.F_CARRY = value >> 7;
		value = value << 1 & 255;
		this.F_SIGN = value >> 7;
		this.F_ZERO = value;
		return value;
	}
	_lsr(value) {
		this.F_CARRY = value & 1;
		value >>= 1;
		this.F_SIGN = 0;
		this.F_ZERO = value;
		return value;
	}
	_rol(value) {
		const result = (value << 1 | this.F_CARRY) & 255;
		this.F_CARRY = value >> 7;
		this.F_SIGN = result >> 7;
		this.F_ZERO = result;
		return result;
	}
	_ror(value) {
		const result = value >> 1 | this.F_CARRY << 7;
		this.F_CARRY = value & 1;
		this.F_SIGN = result >> 7;
		this.F_ZERO = result;
		return result;
	}
	getStatus() {
		return this.F_CARRY | (this.F_ZERO === 0 ? 1 : 0) << 1 | this.F_INTERRUPT << 2 | this.F_DECIMAL << 3 | this.F_BRK << 4 | this.F_NOTUSED << 5 | this.F_OVERFLOW << 6 | this.F_SIGN << 7;
	}
	setStatus(st) {
		this.F_CARRY = st & 1;
		this.F_ZERO = (st >> 1 & 1) === 1 ? 0 : 1;
		this.F_INTERRUPT = st >> 2 & 1;
		this.F_DECIMAL = st >> 3 & 1;
		this.F_BRK = st >> 4 & 1;
		this.F_NOTUSED = st >> 5 & 1;
		this.F_OVERFLOW = st >> 6 & 1;
		this.F_SIGN = st >> 7 & 1;
	}
	setStatusFromStack(st) {
		this.F_CARRY = st & 1;
		this.F_ZERO = (st >> 1 & 1) === 1 ? 0 : 1;
		this.F_INTERRUPT = st >> 2 & 1;
		this.F_DECIMAL = st >> 3 & 1;
		this.F_OVERFLOW = st >> 6 & 1;
		this.F_SIGN = st >> 7 & 1;
	}
	_updateCartridgeLoader() {
		this._gameGenieActive = this.nes.gameGenie.enabled && this.nes.gameGenie.patches.length > 0;
		this._updatePrgReadPath();
	}
	_updatePrgReadPath() {
		const mmap = this.nes.mmap;
		this.directPrgReads = !this._gameGenieActive && !!mmap && mmap.readsPrgFromCpuMem();
	}
	static JSON_PROPERTIES = [
		"mem",
		"cycles",
		"dataBus",
		"irqFlags",
		"resetPending",
		"nmiLine",
		"needNmi",
		"prevNeedNmi",
		"runIrq",
		"prevRunIrq",
		"dmaNeedHalt",
		"dmcDmaRunning",
		"dmcNeedDummy",
		"dmcDmaAbort",
		"oamDmaRunning",
		"oamDmaPage",
		"lastDmaEndCycle",
		"abortedDmaCycle",
		"forcedNmi",
		"REG_ACC",
		"REG_X",
		"REG_Y",
		"REG_SP",
		"REG_PC",
		"F_CARRY",
		"F_DECIMAL",
		"F_INTERRUPT",
		"F_OVERFLOW",
		"F_SIGN",
		"F_ZERO",
		"F_NOTUSED",
		"F_BRK"
	];
	toJSON() {
		return toJSON(this);
	}
	fromJSON(s) {
		fromJSON(this, s);
	}
};
//#endregion
//#region node_modules/jsnes/src/controller.js
var Controller = class Controller {
	static BUTTON_A = 0;
	static BUTTON_B = 1;
	static BUTTON_SELECT = 2;
	static BUTTON_START = 3;
	static BUTTON_UP = 4;
	static BUTTON_DOWN = 5;
	static BUTTON_LEFT = 6;
	static BUTTON_RIGHT = 7;
	static BUTTON_TURBO_A = 8;
	static BUTTON_TURBO_B = 9;
	static JSON_PROPERTIES = [
		"state",
		"baseA",
		"baseB",
		"turboA",
		"turboB",
		"turboToggle"
	];
	constructor() {
		this.state = new Array(8);
		for (let i = 0; i < this.state.length; i++) this.state[i] = 64;
		this.baseA = 64;
		this.baseB = 64;
		this.turboA = false;
		this.turboB = false;
		this.turboToggle = false;
	}
	buttonDown(key) {
		if (key === Controller.BUTTON_TURBO_A) this.turboA = true;
		else if (key === Controller.BUTTON_TURBO_B) this.turboB = true;
		else {
			this.state[key] = 65;
			if (key === Controller.BUTTON_A) this.baseA = 65;
			if (key === Controller.BUTTON_B) this.baseB = 65;
		}
	}
	buttonUp(key) {
		if (key === Controller.BUTTON_TURBO_A) {
			this.turboA = false;
			this.state[Controller.BUTTON_A] = this.baseA;
		} else if (key === Controller.BUTTON_TURBO_B) {
			this.turboB = false;
			this.state[Controller.BUTTON_B] = this.baseB;
		} else {
			this.state[key] = 64;
			if (key === Controller.BUTTON_A) this.baseA = 64;
			if (key === Controller.BUTTON_B) this.baseB = 64;
		}
	}
	clock() {
		if (!this.turboA && !this.turboB) return;
		this.turboToggle = !this.turboToggle;
		if (this.turboA) this.state[Controller.BUTTON_A] = this.turboToggle ? 65 : 64;
		if (this.turboB) this.state[Controller.BUTTON_B] = this.turboToggle ? 65 : 64;
	}
	toJSON() {
		return toJSON(this);
	}
	fromJSON(s) {
		fromJSON(this, s);
	}
};
//#endregion
//#region node_modules/jsnes/src/tile.js
var Tile = class {
	constructor() {
		this.pix = /* @__PURE__ */ new Uint8Array(64);
		this.initialized = false;
		this.opaque = /* @__PURE__ */ new Uint8Array(8);
	}
	setBuffer(scanline) {
		for (let y = 0; y < 8; y++) this.setScanline(y, scanline[y], scanline[y + 8]);
	}
	setScanline(sline, b1, b2) {
		this.initialized = true;
		let tIndex = sline << 3;
		for (let x = 0; x < 8; x++) {
			this.pix[tIndex + x] = (b1 >> 7 - x & 1) + ((b2 >> 7 - x & 1) << 1);
			if (this.pix[tIndex + x] === 0) this.opaque[sline] = false;
		}
	}
	render(buffer, srcx1, srcy1, srcx2, srcy2, dx, dy, palAdd, palette, flipHorizontal, flipVertical, pri, priTable) {
		if (dx < -7 || dx >= 256 || dy < -7 || dy >= 240) return;
		if (dx < 0) srcx1 -= dx;
		if (dx + srcx2 >= 256) srcx2 = 256 - dx;
		if (dy < 0) srcy1 -= dy;
		if (dy + srcy2 >= 240) srcy2 = 240 - dy;
		let fbIndex, tIndex, palIndex, tpri;
		if (!flipHorizontal && !flipVertical) {
			fbIndex = (dy << 8) + dx;
			tIndex = 0;
			for (let y = 0; y < 8; y++) {
				for (let x = 0; x < 8; x++) {
					if (x >= srcx1 && x < srcx2 && y >= srcy1 && y < srcy2) {
						palIndex = this.pix[tIndex];
						tpri = priTable[fbIndex];
						if (palIndex !== 0 && pri <= (tpri & 255)) {
							buffer[fbIndex] = palette[palIndex + palAdd];
							tpri = tpri & 3840 | pri;
							priTable[fbIndex] = tpri;
						}
					}
					fbIndex++;
					tIndex++;
				}
				fbIndex -= 8;
				fbIndex += 256;
			}
		} else if (flipHorizontal && !flipVertical) {
			fbIndex = (dy << 8) + dx;
			tIndex = 7;
			for (let y = 0; y < 8; y++) {
				for (let x = 0; x < 8; x++) {
					if (x >= srcx1 && x < srcx2 && y >= srcy1 && y < srcy2) {
						palIndex = this.pix[tIndex];
						tpri = priTable[fbIndex];
						if (palIndex !== 0 && pri <= (tpri & 255)) {
							buffer[fbIndex] = palette[palIndex + palAdd];
							tpri = tpri & 3840 | pri;
							priTable[fbIndex] = tpri;
						}
					}
					fbIndex++;
					tIndex--;
				}
				fbIndex -= 8;
				fbIndex += 256;
				tIndex += 16;
			}
		} else if (flipVertical && !flipHorizontal) {
			fbIndex = (dy << 8) + dx;
			tIndex = 56;
			for (let y = 0; y < 8; y++) {
				for (let x = 0; x < 8; x++) {
					if (x >= srcx1 && x < srcx2 && y >= srcy1 && y < srcy2) {
						palIndex = this.pix[tIndex];
						tpri = priTable[fbIndex];
						if (palIndex !== 0 && pri <= (tpri & 255)) {
							buffer[fbIndex] = palette[palIndex + palAdd];
							tpri = tpri & 3840 | pri;
							priTable[fbIndex] = tpri;
						}
					}
					fbIndex++;
					tIndex++;
				}
				fbIndex -= 8;
				fbIndex += 256;
				tIndex -= 16;
			}
		} else {
			fbIndex = (dy << 8) + dx;
			tIndex = 63;
			for (let y = 0; y < 8; y++) {
				for (let x = 0; x < 8; x++) {
					if (x >= srcx1 && x < srcx2 && y >= srcy1 && y < srcy2) {
						palIndex = this.pix[tIndex];
						tpri = priTable[fbIndex];
						if (palIndex !== 0 && pri <= (tpri & 255)) {
							buffer[fbIndex] = palette[palIndex + palAdd];
							tpri = tpri & 3840 | pri;
							priTable[fbIndex] = tpri;
						}
					}
					fbIndex++;
					tIndex--;
				}
				fbIndex -= 8;
				fbIndex += 256;
			}
		}
	}
	isTransparent(x, y) {
		return this.pix[(y << 3) + x] === 0;
	}
	toJSON() {
		return {
			opaque: Array.from(this.opaque),
			pix: Array.from(this.pix)
		};
	}
	fromJSON(s) {
		this.opaque.set(s.opaque);
		this.pix.set(s.pix);
	}
};
//#endregion
//#region node_modules/jsnes/src/ppu/nametable.js
var NameTable = class {
	constructor(width, height, name) {
		this.width = width;
		this.height = height;
		this.name = name;
		this.tile = new Uint8Array(width * height);
		this.attrib = new Uint8Array(width * height);
	}
	getTileIndex(x, y) {
		return this.tile[y * this.width + x];
	}
	getAttrib(x, y) {
		return this.attrib[y * this.width + x];
	}
	writeAttrib(index, value) {
		let basex = index % 8 * 4;
		let basey = Math.floor(index / 8) * 4;
		let add;
		let tx, ty;
		let attindex;
		for (let sqy = 0; sqy < 2; sqy++) for (let sqx = 0; sqx < 2; sqx++) {
			add = value >> 2 * (sqy * 2 + sqx) & 3;
			for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) {
				tx = basex + sqx * 2 + x;
				ty = basey + sqy * 2 + y;
				attindex = ty * this.width + tx;
				this.attrib[attindex] = add << 2 & 12;
			}
		}
	}
	toJSON() {
		return {
			tile: Array.from(this.tile),
			attrib: Array.from(this.attrib)
		};
	}
	fromJSON(s) {
		this.tile.set(s.tile);
		this.attrib.set(s.attrib);
	}
};
//#endregion
//#region node_modules/jsnes/src/ppu/palette-table.js
var PaletteTable = class {
	constructor() {
		this.curTable = /* @__PURE__ */ new Uint32Array(64);
		this.emphTable = new Array(8);
		this.currentEmph = -1;
	}
	loadNTSCPalette() {
		this.curTable = new Uint32Array([
			5395026,
			11796480,
			10485760,
			11599933,
			7602281,
			91,
			95,
			6208,
			12048,
			543240,
			26368,
			1196544,
			7153664,
			0,
			0,
			0,
			12899815,
			16728064,
			14421538,
			16729963,
			14090399,
			6818519,
			6588,
			21681,
			27227,
			35843,
			43776,
			2918400,
			10777088,
			0,
			0,
			0,
			16316664,
			16755516,
			16742785,
			16735173,
			16730354,
			14633471,
			4681215,
			46327,
			57599,
			58229,
			259115,
			7911470,
			15065624,
			7895160,
			0,
			0,
			16777215,
			16773822,
			16300216,
			16300248,
			16758527,
			16761855,
			13095423,
			10148607,
			8973816,
			8650717,
			12122296,
			16119980,
			16777136,
			16308472,
			0,
			0
		]);
		this.makeTables();
		this.setEmphasis(0);
	}
	loadPALPalette() {
		this.curTable = new Uint32Array([
			5395026,
			11796480,
			10485760,
			11599933,
			7602281,
			91,
			95,
			6208,
			12048,
			543240,
			26368,
			1196544,
			7153664,
			0,
			0,
			0,
			12899815,
			16728064,
			14421538,
			16729963,
			14090399,
			6818519,
			6588,
			21681,
			27227,
			35843,
			43776,
			2918400,
			10777088,
			0,
			0,
			0,
			16316664,
			16755516,
			16742785,
			16735173,
			16730354,
			14633471,
			4681215,
			46327,
			57599,
			58229,
			259115,
			7911470,
			15065624,
			7895160,
			0,
			0,
			16777215,
			16773822,
			16300216,
			16300248,
			16758527,
			16761855,
			13095423,
			10148607,
			8973816,
			8650717,
			12122296,
			16119980,
			16777136,
			16308472,
			0,
			0
		]);
		this.makeTables();
		this.setEmphasis(0);
	}
	makeTables() {
		let r, g, b, col, i, rFactor, gFactor, bFactor;
		for (let emph = 0; emph < 8; emph++) {
			rFactor = 1;
			gFactor = 1;
			bFactor = 1;
			if ((emph & 1) !== 0) {
				gFactor = .75;
				bFactor = .75;
			}
			if ((emph & 2) !== 0) {
				rFactor = .75;
				bFactor = .75;
			}
			if ((emph & 4) !== 0) {
				rFactor = .75;
				gFactor = .75;
			}
			this.emphTable[emph] = /* @__PURE__ */ new Uint32Array(64);
			for (i = 0; i < 64; i++) {
				col = this.curTable[i];
				r = Math.floor(this.getRed(col) * rFactor);
				g = Math.floor(this.getGreen(col) * gFactor);
				b = Math.floor(this.getBlue(col) * bFactor);
				this.emphTable[emph][i] = this.getRgb(r, g, b);
			}
		}
	}
	setEmphasis(emph) {
		if (emph !== this.currentEmph) {
			this.currentEmph = emph;
			for (let i = 0; i < 64; i++) this.curTable[i] = this.emphTable[emph][i];
		}
	}
	getEntry(yiq) {
		return this.curTable[yiq];
	}
	getRed(rgb) {
		return rgb >> 16 & 255;
	}
	getGreen(rgb) {
		return rgb >> 8 & 255;
	}
	getBlue(rgb) {
		return rgb & 255;
	}
	getRgb(r, g, b) {
		return r << 16 | g << 8 | b;
	}
	loadDefaultPalette() {
		this.curTable[0] = this.getRgb(117, 117, 117);
		this.curTable[1] = this.getRgb(39, 27, 143);
		this.curTable[2] = this.getRgb(0, 0, 171);
		this.curTable[3] = this.getRgb(71, 0, 159);
		this.curTable[4] = this.getRgb(143, 0, 119);
		this.curTable[5] = this.getRgb(171, 0, 19);
		this.curTable[6] = this.getRgb(167, 0, 0);
		this.curTable[7] = this.getRgb(127, 11, 0);
		this.curTable[8] = this.getRgb(67, 47, 0);
		this.curTable[9] = this.getRgb(0, 71, 0);
		this.curTable[10] = this.getRgb(0, 81, 0);
		this.curTable[11] = this.getRgb(0, 63, 23);
		this.curTable[12] = this.getRgb(27, 63, 95);
		this.curTable[13] = this.getRgb(0, 0, 0);
		this.curTable[14] = this.getRgb(0, 0, 0);
		this.curTable[15] = this.getRgb(0, 0, 0);
		this.curTable[16] = this.getRgb(188, 188, 188);
		this.curTable[17] = this.getRgb(0, 115, 239);
		this.curTable[18] = this.getRgb(35, 59, 239);
		this.curTable[19] = this.getRgb(131, 0, 243);
		this.curTable[20] = this.getRgb(191, 0, 191);
		this.curTable[21] = this.getRgb(231, 0, 91);
		this.curTable[22] = this.getRgb(219, 43, 0);
		this.curTable[23] = this.getRgb(203, 79, 15);
		this.curTable[24] = this.getRgb(139, 115, 0);
		this.curTable[25] = this.getRgb(0, 151, 0);
		this.curTable[26] = this.getRgb(0, 171, 0);
		this.curTable[27] = this.getRgb(0, 147, 59);
		this.curTable[28] = this.getRgb(0, 131, 139);
		this.curTable[29] = this.getRgb(0, 0, 0);
		this.curTable[30] = this.getRgb(0, 0, 0);
		this.curTable[31] = this.getRgb(0, 0, 0);
		this.curTable[32] = this.getRgb(255, 255, 255);
		this.curTable[33] = this.getRgb(63, 191, 255);
		this.curTable[34] = this.getRgb(95, 151, 255);
		this.curTable[35] = this.getRgb(167, 139, 253);
		this.curTable[36] = this.getRgb(247, 123, 255);
		this.curTable[37] = this.getRgb(255, 119, 183);
		this.curTable[38] = this.getRgb(255, 119, 99);
		this.curTable[39] = this.getRgb(255, 155, 59);
		this.curTable[40] = this.getRgb(243, 191, 63);
		this.curTable[41] = this.getRgb(131, 211, 19);
		this.curTable[42] = this.getRgb(79, 223, 75);
		this.curTable[43] = this.getRgb(88, 248, 152);
		this.curTable[44] = this.getRgb(0, 235, 219);
		this.curTable[45] = this.getRgb(0, 0, 0);
		this.curTable[46] = this.getRgb(0, 0, 0);
		this.curTable[47] = this.getRgb(0, 0, 0);
		this.curTable[48] = this.getRgb(255, 255, 255);
		this.curTable[49] = this.getRgb(171, 231, 255);
		this.curTable[50] = this.getRgb(199, 215, 255);
		this.curTable[51] = this.getRgb(215, 203, 255);
		this.curTable[52] = this.getRgb(255, 199, 255);
		this.curTable[53] = this.getRgb(255, 199, 219);
		this.curTable[54] = this.getRgb(255, 191, 179);
		this.curTable[55] = this.getRgb(255, 219, 171);
		this.curTable[56] = this.getRgb(255, 231, 163);
		this.curTable[57] = this.getRgb(227, 255, 163);
		this.curTable[58] = this.getRgb(171, 243, 191);
		this.curTable[59] = this.getRgb(179, 255, 207);
		this.curTable[60] = this.getRgb(159, 255, 243);
		this.curTable[61] = this.getRgb(0, 0, 0);
		this.curTable[62] = this.getRgb(0, 0, 0);
		this.curTable[63] = this.getRgb(0, 0, 0);
		this.makeTables();
		this.setEmphasis(0);
	}
};
//#endregion
//#region node_modules/jsnes/src/ppu/index.js
var MASK_DELAY = 2;
var PPU = class {
	STATUS_VRAMWRITE = 4;
	STATUS_SLSPRITECOUNT = 5;
	STATUS_SPRITE0HIT = 6;
	STATUS_VBLANK = 7;
	constructor(nes) {
		this.nes = nes;
		this.clipToTvSize = true;
		let i;
		this.vramMem = /* @__PURE__ */ new Uint8Array(32768);
		this.spriteMem = /* @__PURE__ */ new Uint8Array(256);
		this.secondaryOAM = (/* @__PURE__ */ new Uint8Array(32)).fill(255);
		this.vramMirrorTable = /* @__PURE__ */ new Uint16Array(32768);
		for (i = 0; i < 32768; i++) this.vramMirrorTable[i] = i;
		this.currentMirroring = -1;
		this.ntable1 = [
			0,
			1,
			2,
			3
		];
		this.nameTable = new Array(4);
		for (i = 0; i < 4; i++) this.nameTable[i] = new NameTable(32, 32, `Nt${i}`);
		this.ptTile = new Array(512);
		for (i = 0; i < 512; i++) this.ptTile[i] = new Tile();
		this.vramAddress = 0;
		this.vramTmpAddress = 0;
		this.fineX = 0;
		this.firstWrite = true;
		this.vramBufferedReadValue = 0;
		this.sramAddress = 0;
		this.openBusLatch = 0;
		this.openBusDecayFrames = 0;
		this.f_nmiOnVblank = 0;
		this.f_spriteSize = 0;
		this.f_bgPatternTable = 0;
		this.f_spPatternTable = 0;
		this.f_addrInc = 0;
		this.f_nTblAddress = 0;
		this.f_color = 0;
		this.f_spVisibility = 0;
		this.f_bgVisibility = 0;
		this.f_spClipping = 0;
		this.f_bgClipping = 0;
		this.f_dispType = 0;
		this.vblankFlag = 0;
		this.sprite0HitFlag = 0;
		this.spriteOverflowFlag = 0;
		this.nmiOutput = false;
		this.nmiAtPoll = false;
		this.dotTarget = 0;
		this.dotsRun = 0;
		this.nextEventDot = 0;
		this.nmiSuppressed = false;
		this.frameEnded = false;
		this.line = 241;
		this.dot = 2;
		this.scanline = 0;
		this.oddFrame = false;
		this.renderingOn = false;
		this.maskDelay = 0;
		this.bgShiftLo = 0;
		this.bgShiftHi = 0;
		this.attrShiftLo = 0;
		this.attrShiftHi = 0;
		this.attrLatchLo = 0;
		this.attrLatchHi = 0;
		this.ntByte = 0;
		this.atBits = 0;
		this.ptLo = 0;
		this.ptHi = 0;
		this.secIdx = 0;
		this.secFull = false;
		this.oamLatch = 0;
		this.evalDone = false;
		this.evalOvfStep = 0;
		this.sprite0Next = false;
		this.sprite0Line = false;
		this.oamCorruptPending = false;
		this.oamCorruptRow = 0;
		this.sprCount = 0;
		this.sprLo = /* @__PURE__ */ new Uint8Array(8);
		this.sprHi = /* @__PURE__ */ new Uint8Array(8);
		this.sprAttr = /* @__PURE__ */ new Uint8Array(8);
		this.sprX = /* @__PURE__ */ new Uint8Array(8);
		this.sprLatchX = /* @__PURE__ */ new Uint8Array(8);
		this.sprFetchCount = 0;
		this.spriteSkipGlitch = false;
		this.sprLine = /* @__PURE__ */ new Uint16Array(256);
		this.sprLineValid = false;
		this.sprLineFor = -1;
		this.buffer = /* @__PURE__ */ new Uint32Array(61440);
		this.palColors = /* @__PURE__ */ new Uint32Array(32);
		this.palTable = new PaletteTable();
		this.palTable.loadNTSCPalette();
		this.updateControlReg1(0);
		this.updateControlReg2(0);
	}
	setMirroring(mirroring) {
		if (mirroring === this.currentMirroring) return;
		this.currentMirroring = mirroring;
		for (let i = 0; i < 32768; i++) this.vramMirrorTable[i] = i;
		this.defineMirrorRegion(16160, 16128, 32);
		this.defineMirrorRegion(16192, 16128, 32);
		this.defineMirrorRegion(16256, 16128, 32);
		this.defineMirrorRegion(16320, 16128, 32);
		this.defineMirrorRegion(12288, 8192, 3840);
		this.defineMirrorRegion(16384, 0, 16384);
		if (mirroring === this.nes.rom.HORIZONTAL_MIRRORING) {
			this.ntable1[0] = 0;
			this.ntable1[1] = 0;
			this.ntable1[2] = 1;
			this.ntable1[3] = 1;
			this.defineMirrorRegion(9216, 8192, 1024);
			this.defineMirrorRegion(11264, 10240, 1024);
		} else if (mirroring === this.nes.rom.VERTICAL_MIRRORING) {
			this.ntable1[0] = 0;
			this.ntable1[1] = 1;
			this.ntable1[2] = 0;
			this.ntable1[3] = 1;
			this.defineMirrorRegion(10240, 8192, 1024);
			this.defineMirrorRegion(11264, 9216, 1024);
		} else if (mirroring === this.nes.rom.SINGLESCREEN_MIRRORING) {
			this.ntable1[0] = 0;
			this.ntable1[1] = 0;
			this.ntable1[2] = 0;
			this.ntable1[3] = 0;
			this.defineMirrorRegion(9216, 8192, 1024);
			this.defineMirrorRegion(10240, 8192, 1024);
			this.defineMirrorRegion(11264, 8192, 1024);
		} else if (mirroring === this.nes.rom.SINGLESCREEN_MIRRORING2) {
			this.ntable1[0] = 1;
			this.ntable1[1] = 1;
			this.ntable1[2] = 1;
			this.ntable1[3] = 1;
			this.defineMirrorRegion(8192, 9216, 1024);
			this.defineMirrorRegion(10240, 9216, 1024);
			this.defineMirrorRegion(11264, 9216, 1024);
		} else {
			this.ntable1[0] = 0;
			this.ntable1[1] = 1;
			this.ntable1[2] = 2;
			this.ntable1[3] = 3;
		}
	}
	defineMirrorRegion(fromStart, toStart, size) {
		for (let i = 0; i < size; i++) this.vramMirrorTable[fromStart + i] = toStart + i;
	}
	mirroredLoad(address) {
		return this.vramMem[this.vramMirrorTable[address]];
	}
	mirroredWrite(address, value) {
		if (address >= 16128 && address < 16160) {
			if ((address & 3) === 0) {
				this.writeMem(address & 16143, value);
				this.writeMem(address & 16143 | 16, value);
			} else this.writeMem(address, value);
		} else this.writeMem(this.vramMirrorTable[address], value);
	}
	writeMem(address, value) {
		this.vramMem[address] = value;
		if (address < 8192) this.patternWrite(address, value);
		else if (address >= 16128 && address < 16160) this._updatePaletteColor(address & 31);
	}
	patternWrite(address, value) {
		let tileIndex = address >> 4;
		let leftOver = address & 15;
		if (leftOver < 8) this.ptTile[tileIndex].setScanline(leftOver, value, this.vramMem[address + 8]);
		else this.ptTile[tileIndex].setScanline(leftOver - 8, this.vramMem[address - 8], value);
	}
	triggerRendering() {}
	_updatePaletteColor(index) {
		let value = this.vramMem[16128 + index] & 63;
		if (this.f_dispType !== 0) value &= 48;
		this.palColors[index] = this.palTable.getEntry(value);
	}
	updatePalettes() {
		for (let i = 0; i < 32; i++) this._updatePaletteColor(i);
	}
	updateControlReg1(value) {
		this.f_nmiOnVblank = value >> 7 & 1;
		this.f_spriteSize = value >> 5 & 1;
		this.f_bgPatternTable = value >> 4 & 1;
		this.f_spPatternTable = value >> 3 & 1;
		this.f_addrInc = value >> 2 & 1;
		this.f_nTblAddress = value & 3;
		this.vramTmpAddress = this.vramTmpAddress & 29695 | (value & 3) << 10;
		this._updateNmiOutput();
	}
	updateControlReg2(value) {
		this.f_color = value >> 5 & 7;
		this.f_spVisibility = value >> 4 & 1;
		this.f_bgVisibility = value >> 3 & 1;
		this.f_spClipping = value >> 2 & 1;
		this.f_bgClipping = value >> 1 & 1;
		this.f_dispType = value & 1;
		if (this.f_dispType === 0) this.palTable.setEmphasis(this.f_color);
		this.updatePalettes();
		this.maskDelay = MASK_DELAY;
	}
	_applyRenderingEnable() {
		const on = this.f_bgVisibility === 1 || this.f_spVisibility === 1;
		if (this.renderingOn && !on) {
			this._materializeSprites();
			this._renderingDisabled();
		}
		this.renderingOn = on;
	}
	_updateNmiOutput() {
		this.nmiOutput = this.f_nmiOnVblank !== 0 && this.vblankFlag !== 0;
	}
	setStatusFlag(flag, value) {
		const v = value ? 1 : 0;
		if (flag === this.STATUS_VBLANK) {
			this.vblankFlag = v;
			this._updateNmiOutput();
		} else if (flag === this.STATUS_SPRITE0HIT) this.sprite0HitFlag = v;
		else if (flag === this.STATUS_SLSPRITECOUNT) this.spriteOverflowFlag = v;
	}
	readStatusRegister() {
		if (this.line === 241 && this.dot === 1) this.nmiSuppressed = true;
		let value = this.vblankFlag << 7 | this.sprite0HitFlag << 6 | this.spriteOverflowFlag << 5 | this.openBusLatch & 31;
		this.vblankFlag = 0;
		this._updateNmiOutput();
		this.firstWrite = true;
		this.openBusLatch = value;
		this.openBusDecayFrames = 36;
		return value;
	}
	writeSRAMAddress(address) {
		this.sramAddress = address;
	}
	_isRenderingLine() {
		return this.renderingOn && (this.line < 240 || this.line === 261);
	}
	sramLoad() {
		if (this._isRenderingLine()) {
			const dot = this.dot;
			if (dot >= 1 && dot <= 64) return 255;
			else if (dot >= 257 && dot <= 320) return this.secondaryOAM[this.secIdx & 31];
			else if (dot === 0 || dot > 320) return this.secondaryOAM[0];
		}
		return this.spriteMem[this.sramAddress];
	}
	sramWrite(value) {
		if (this._isRenderingLine()) {
			this.sramAddress = this.sramAddress + 4 & 252;
			return;
		}
		if ((this.sramAddress & 3) === 2) value &= 227;
		this.spriteMem[this.sramAddress] = value;
		this.sramAddress = this.sramAddress + 1 & 255;
	}
	scrollWrite(value) {
		if (this.firstWrite) {
			this.vramTmpAddress = this.vramTmpAddress & 32736 | value >> 3;
			this.fineX = value & 7;
		} else this.vramTmpAddress = this.vramTmpAddress & 3103 | (value & 248) << 2 | (value & 7) << 12;
		this.firstWrite = !this.firstWrite;
	}
	writeVRAMAddress(value) {
		if (this.firstWrite) this.vramTmpAddress = this.vramTmpAddress & 255 | (value & 63) << 8;
		else {
			this.vramTmpAddress = this.vramTmpAddress & 32512 | value;
			this.vramAddress = this.vramTmpAddress;
			if (this.vramAddress < 8192) this.nes.mmap.latchAccess(this.vramAddress);
		}
		this.firstWrite = !this.firstWrite;
	}
	vramLoad() {
		const address = this.vramAddress & 16383;
		let value;
		if (address <= 16127) {
			value = this.vramBufferedReadValue;
			if (address < 8192) {
				this.vramBufferedReadValue = this.vramMem[address];
				this.nes.mmap.latchAccess(address);
			} else this.vramBufferedReadValue = this.mirroredLoad(address);
		} else {
			let palIdx = address & 31;
			if ((palIdx & 19) === 16) palIdx &= 15;
			value = this.vramMem[16128 + palIdx] & 63 | this.openBusLatch & 192;
			this.vramBufferedReadValue = this.mirroredLoad(address & 12287);
		}
		this._incrementVramAddress();
		return value;
	}
	vramWrite(value) {
		const address = this.vramAddress & 16383;
		if (address >= 8192) this.mirroredWrite(address, value);
		else {
			if (this.nes.mmap.canWriteChr(address)) this.writeMem(address, value);
			this.nes.mmap.latchAccess(address);
		}
		this._incrementVramAddress();
	}
	_incrementVramAddress() {
		if (this._isRenderingLine()) {
			this._incCoarseX();
			this._incY();
		} else this.vramAddress = this.vramAddress + (this.f_addrInc === 1 ? 32 : 1) & 32767;
	}
	_incCoarseX() {
		let v = this.vramAddress;
		if ((v & 31) === 31) v = v & -32 ^ 1024;
		else v++;
		this.vramAddress = v;
	}
	_incY() {
		let v = this.vramAddress;
		if ((v & 28672) !== 28672) v += 4096;
		else {
			v &= -28673;
			let y = (v & 992) >> 5;
			if (y === 29) {
				y = 0;
				v ^= 2048;
			} else if (y === 31) y = 0;
			else y++;
			v = v & -993 | y << 5;
		}
		this.vramAddress = v;
	}
	catchUp() {
		const target = this.dotTarget;
		while (this.dotsRun < target) {
			const dot = this.dot;
			if (this.line < 240 && dot >= 1 && dot <= 256 && this.renderingOn && this.maskDelay === 0 && !this.oamCorruptPending) {
				let end = dot + (target - this.dotsRun);
				if (end > 257) end = 257;
				this._renderSpan(this.line, dot, end);
				this.dotsRun += end - dot;
				this.dot = end;
			} else if (dot >= 257 && dot <= 320 && (this.line < 240 || this.line === 261) && this.renderingOn && this.maskDelay === 0 && !this.oamCorruptPending) {
				let end = dot + (target - this.dotsRun);
				if (end > 321) end = 321;
				this._spriteFetchSpan(this.line, dot, end, this.line === 261);
				this.dotsRun += end - dot;
				this.dot = end;
			} else if (this.line >= 240 && this.line <= 260 && (this.line !== 241 || dot >= 2) && this.maskDelay === 0) {
				const left = 341 - dot;
				const owed = target - this.dotsRun;
				if (owed >= left) {
					this.dotsRun += left;
					this._nextLine();
				} else {
					this.dotsRun += owed;
					this.dot = dot + owed;
				}
			} else {
				this._tick();
				this.dotsRun++;
			}
		}
	}
	runCycleExact() {
		const target = this.dotTarget;
		this.dotTarget = target - 2;
		this.catchUp();
		this.nmiAtPoll = this.nmiOutput;
		this.dotTarget = target;
		this.catchUp();
		this._scheduleNextEvent();
	}
	_dotsUntil(line, dot) {
		let d = (line - this.line) * 341 + (dot - this.dot);
		if (d < 0) d += 89342;
		return d;
	}
	_scheduleNextEvent() {
		let d = this._dotsUntil(241, 1);
		let e = this._dotsUntil(261, 1);
		if (e < d) d = e;
		e = this._dotsUntil(261, 339);
		if (e < d) d = e;
		if (this.renderingOn) {
			const irqDot = this.nes.mmap ? this.nes.mmap.irqClockDot : 260;
			const line = this.line;
			let next;
			if (line < 240) {
				next = this.dot <= irqDot ? line : line + 1;
				if (next === 240) next = 261;
			} else if (line === 261 && this.dot > irqDot) next = 0;
			else next = 261;
			e = this._dotsUntil(next, irqDot);
			if (e < d) d = e;
		}
		if (this.maskDelay !== 0 && this.maskDelay - 1 < d) d = this.maskDelay - 1;
		this.nextEventDot = this.dotsRun + d;
	}
	_tick() {
		const line = this.line;
		const dot = this.dot;
		if (line < 240) {
			if (this.renderingOn) this._renderingDot(line, dot, false);
			else if (dot >= 1 && dot <= 256) {
				this._blankPixel(line, dot - 1);
				for (let i = 0; i < this.sprCount; i++) if (this.sprX[i] !== 0) this.sprX[i]--;
			} else if (dot === 340) this._spriteCountersWithRenderingOff();
		} else if (line === 261) {
			if (dot === 1) {
				this.vblankFlag = 0;
				this.sprite0HitFlag = 0;
				this.spriteOverflowFlag = 0;
				this._updateNmiOutput();
			}
			if (this.renderingOn) this._renderingDot(line, dot, true);
			else if (dot === 340) this._spriteCountersWithRenderingOff();
		} else if (line === 241 && dot === 1) this._startVBlank();
		if (this.maskDelay !== 0 && --this.maskDelay === 0) this._applyRenderingEnable();
		if (dot < 340) {
			if (dot === 339 && line === 261 && this.oddFrame && this.renderingOn) {
				this._nextLine();
				this.spriteSkipGlitch = true;
				this.sprCount = this.sprFetchCount;
				this.sprLineValid = false;
				return;
			}
			this.dot = dot + 1;
		} else this._nextLine();
	}
	_nextLine() {
		this.dot = 0;
		let line = this.line + 1;
		if (line === 262) {
			line = 0;
			this.oddFrame = !this.oddFrame;
		}
		this.line = line;
		this.scanline = line >= 241 ? line - 241 : line + 21;
	}
	_startVBlank() {
		if (!this.nmiSuppressed) {
			this.vblankFlag = 1;
			this._updateNmiOutput();
		}
		this.nmiSuppressed = false;
		if (this.openBusDecayFrames > 0) {
			this.openBusDecayFrames--;
			if (this.openBusDecayFrames === 0) this.openBusLatch = 0;
		}
		this.endFrame();
		this.frameEnded = true;
	}
	_blankPixel(line, x) {
		const v = this.vramAddress & 16383;
		const color = v >= 16128 ? this.palColors[v & 31] : this.palColors[0];
		this.buffer[line << 8 | x] = color;
	}
	_renderingDot(line, dot, isPreRender) {
		if (this.oamCorruptPending) this._performOamCorruption();
		if (dot === 0) return;
		if (dot > 320 && dot === this.nes.mmap.irqClockDot) this.nes.mmap.clockIrqCounter();
		if (dot <= 256) {
			if (!isPreRender) this._renderSpan(line, dot, dot + 1);
			else {
				this._shiftBg();
				this._bgFetch(dot);
				if (dot === 256) this._incY();
			}
		} else if (dot <= 320) this._spriteFetchSpan(line, dot, dot + 1, isPreRender);
		else if (dot <= 336) {
			if (dot === 321) this.nes.mmap.onBgRender();
			this._shiftBg();
			this._bgFetch(dot);
		} else if (dot === 337) this.ntByte = this.mirroredLoad(8192 | this.vramAddress & 4095);
		else if (dot === 339) this.ntByte = this.mirroredLoad(8192 | this.vramAddress & 4095);
		else if (dot === 340) {
			for (let i = 0; i < 8; i++) this.sprX[i] = this.sprLatchX[i];
			this.sprCount = this.sprFetchCount;
			this._buildSpriteLine(line === 261 ? 0 : line + 1);
		}
	}
	_buildSpriteLine(forLine) {
		const sprLine = this.sprLine;
		sprLine.fill(0);
		this.sprLineFor = forLine;
		this.sprLineValid = true;
		for (let i = this.sprCount - 1; i >= 0; i--) {
			let lo = this.sprLo[i];
			let hi = this.sprHi[i];
			if ((lo | hi) === 0) continue;
			const attr = this.sprAttr[i];
			const flags = 16 | (attr & 3) << 2 | (attr & 32) << 3 | (i === 0 && this.sprite0Line ? 512 : 0);
			const x0 = this.sprX[i];
			for (let b = 0; b < 8 && x0 + b < 256; b++) {
				const p = lo >> 7 & 1 | hi >> 6 & 2;
				lo = lo << 1 & 255;
				hi = hi << 1 & 255;
				if (p !== 0) sprLine[x0 + b] = flags | p;
			}
		}
	}
	_materializeSprites() {
		if (!this.sprLineValid) return;
		this.sprLineValid = false;
		if (this.line !== this.sprLineFor || this.dot > 256) return;
		const done = this.dot > 0 ? this.dot - 1 : 0;
		for (let i = 0; i < this.sprCount; i++) {
			const x0 = this.sprX[i];
			if (done <= x0) this.sprX[i] = x0 - done;
			else {
				const shift = Math.min(done - x0, 8);
				this.sprX[i] = 0;
				this.sprLo[i] = this.sprLo[i] << shift & 255;
				this.sprHi[i] = this.sprHi[i] << shift & 255;
			}
		}
	}
	_spriteFetchSpan(line, from, to, isPreRender) {
		if (from === 257) {
			this.vramAddress = this.vramAddress & 31712 | this.vramTmpAddress & 1055;
			this.secIdx = 0;
			this.sprFetchCount = 0;
			this.sprite0Line = this.sprite0Next;
			this.nes.mmap.onSpriteRender();
		}
		const evalLine = isPreRender ? 5 : line;
		for (let slot = from - 257 >> 3; slot < 8; slot++) {
			const fetchDot = 264 + (slot << 3);
			if (fetchDot >= to) break;
			if (fetchDot >= from) this._fetchSprite(slot, evalLine);
		}
		this.secIdx = this.secIdx + SEC_IDX_STEPS[to - 257] - SEC_IDX_STEPS[from - 257] & 31;
		if (isPreRender && from <= 304 && to > 280) this.vramAddress = this.vramAddress & 1055 | this.vramTmpAddress & 31712;
		const irqDot = this.nes.mmap.irqClockDot;
		if (irqDot >= from && irqDot < to) this.nes.mmap.clockIrqCounter();
		this.sramAddress = 0;
	}
	_spriteCountersWithRenderingOff() {
		this.sprLineValid = false;
		this.sprX.fill(0);
		this.sprCount = this.sprFetchCount;
	}
	_bgFetch(dot) {
		switch (dot & 7) {
			case 1:
				this.ntByte = this.mirroredLoad(8192 | this.vramAddress & 4095);
				break;
			case 3: {
				const v = this.vramAddress;
				const at = this.mirroredLoad(9152 | v & 3072 | v >> 4 & 56 | v >> 2 & 7);
				this.atBits = at >> (v >> 4 & 4 | v & 2) & 3;
				break;
			}
			case 5: {
				const addr = this.f_bgPatternTable << 12 | this.ntByte << 4 | this.vramAddress >> 12;
				this.ptLo = this.vramMem[addr];
				break;
			}
			case 7: {
				const addr = (this.f_bgPatternTable << 12 | this.ntByte << 4 | this.vramAddress >> 12) + 8;
				this.ptHi = this.vramMem[addr];
				const mmap = this.nes.mmap;
				mmap.latchAccess(addr);
				if (mmap.bgTileOverride) this._mapperBgOverride();
				break;
			}
			case 0:
				this._reloadBg();
				this._incCoarseX();
		}
	}
	_mapperBgOverride() {
		const v = this.vramAddress;
		const data = this.nes.mmap.getBgTileData(this.f_bgPatternTable ? 256 : 0, this.ntByte, v & 31, v >> 5 & 31);
		if (!data) return;
		const fineY = v >> 12;
		const pix = data.tile.pix;
		let lo = 0;
		let hi = 0;
		for (let i = 0; i < 8; i++) {
			const p = pix[(fineY << 3) + i];
			lo = lo << 1 | p & 1;
			hi = hi << 1 | p >> 1;
		}
		this.ptLo = lo;
		this.ptHi = hi;
		this.atBits = data.attrib >> 2 & 3;
	}
	_shiftBg() {
		this.bgShiftLo = this.bgShiftLo << 1 & 65535;
		this.bgShiftHi = (this.bgShiftHi << 1 | 1) & 65535;
		this.attrShiftLo = (this.attrShiftLo << 1 | this.attrLatchLo) & 255;
		this.attrShiftHi = (this.attrShiftHi << 1 | this.attrLatchHi) & 255;
	}
	_reloadBg() {
		this.bgShiftLo = this.bgShiftLo & 65280 | this.ptLo;
		this.bgShiftHi = this.bgShiftHi & 65280 | this.ptHi;
		this.attrLatchLo = this.atBits & 1;
		this.attrLatchHi = this.atBits >> 1;
	}
	_renderSpan(line, from, to) {
		this._renderBackgroundSpan(line, from, to);
		this._evaluateSpan(line, from, to);
	}
	_renderBackgroundSpan(line, from, to) {
		let bgLo = this.bgShiftLo;
		let bgHi = this.bgShiftHi;
		let atLo = this.attrShiftLo;
		let atHi = this.attrShiftHi;
		let latLo = this.attrLatchLo;
		let latHi = this.attrLatchHi;
		const fineX = this.fineX;
		const bit = 15 - fineX;
		const abit = 7 - fineX;
		const showBg = this.f_bgVisibility === 1;
		const bgLeft = this.f_bgClipping === 1;
		const palColors = this.palColors;
		const buffer = this.buffer;
		const sprLine = this.sprLine;
		const showSprites = this.f_spVisibility === 1;
		const spLeft = this.f_spClipping === 1;
		const rowBase = line << 8;
		const vram = this.vramMem;
		const mirror = this.vramMirrorTable;
		let dot = from;
		while (dot < to) {
			const spritesSimple = this.sprLineValid || this.sprCount === 0 && !this.spriteSkipGlitch;
			if ((dot & 7) === 1 && dot + 8 <= to && spritesSimple) {
				{
					const v = this.vramAddress;
					const ntByte = vram[mirror[8192 | v & 4095]];
					const at = vram[mirror[9152 | v & 3072 | v >> 4 & 56 | v >> 2 & 7]];
					this.ntByte = ntByte;
					this.atBits = at >> (v >> 4 & 4 | v & 2) & 3;
					const addr = this.f_bgPatternTable << 12 | ntByte << 4 | v >> 12;
					this.ptLo = vram[addr];
					this.ptHi = vram[addr + 8];
					const mmap = this.nes.mmap;
					mmap.latchAccess(addr + 8);
					if (mmap.bgTileOverride) this._mapperBgOverride();
				}
				const x0 = dot - 1;
				const sh = 8 - fineX;
				let pix = 0;
				if (showBg && (x0 >= 8 || bgLeft)) pix = DECODE_PLANES[(bgHi >> sh & 255) << 8 | bgLo >> sh & 255];
				const pal = DECODE_PLANES[((atHi << 8 | (latHi ? 255 : 0)) >> sh & 255) << 8 | (atLo << 8 | (latLo ? 255 : 0)) >> sh & 255];
				if (!this.sprLineValid) for (let k = 0; k < 8; k++) {
					const s2 = 14 - 2 * k;
					const p = pix >> s2 & 3;
					buffer[rowBase | x0 + k] = palColors[p === 0 ? 0 : p | (pal >> s2 & 3) << 2];
				}
				else for (let k = 0; k < 8; k++) {
					const x = x0 + k;
					const s2 = 14 - 2 * k;
					const p = pix >> s2 & 3;
					const bgPixel = p === 0 ? 0 : p | (pal >> s2 & 3) << 2;
					let colorIndex = bgPixel;
					const spr = sprLine[x];
					if (spr !== 0 && showSprites && (x >= 8 || spLeft)) {
						if (spr & 512 && bgPixel !== 0 && x !== 255) this.sprite0HitFlag = 1;
						if (bgPixel === 0 || (spr & 256) === 0) colorIndex = spr & 31;
					}
					buffer[rowBase | x] = palColors[colorIndex];
				}
				bgLo = bgLo << 8 & 65280 | this.ptLo;
				bgHi = bgHi << 8 & 65280 | this.ptHi;
				atLo = latLo ? 255 : 0;
				atHi = latHi ? 255 : 0;
				latLo = this.atBits & 1;
				latHi = this.atBits >> 1;
				this._incCoarseX();
				if (dot === 249) this._incY();
				dot += 8;
				continue;
			}
			const x = dot - 1;
			let bgPixel = 0;
			if (showBg && (x >= 8 || bgLeft)) {
				const p = bgLo >> bit & 1 | (bgHi >> bit & 1) << 1;
				if (p !== 0) bgPixel = p | (atLo >> abit & 1) << 2 | (atHi >> abit & 1) << 3;
			}
			let colorIndex = bgPixel;
			if (this.sprLineValid) {
				const spr = sprLine[x];
				if (spr !== 0 && showSprites && (x >= 8 || spLeft)) {
					if (spr & 512 && bgPixel !== 0 && x !== 255) this.sprite0HitFlag = 1;
					if (bgPixel === 0 || (spr & 256) === 0) colorIndex = spr & 31;
				}
			} else if (this.sprCount !== 0 || this.spriteSkipGlitch) {
				const spr = this._spritePixel(x, bgPixel);
				if (spr !== 0 && (bgPixel === 0 || (spr & 256) === 0)) colorIndex = spr & 31;
			}
			buffer[rowBase | x] = palColors[colorIndex];
			bgLo = bgLo << 1 & 65535;
			bgHi = (bgHi << 1 | 1) & 65535;
			atLo = (atLo << 1 | latLo) & 255;
			atHi = (atHi << 1 | latHi) & 255;
			if ((dot & 7) === 0) {
				bgLo = bgLo & 65280 | this.ptLo;
				bgHi = bgHi & 65280 | this.ptHi;
				latLo = this.atBits & 1;
				latHi = this.atBits >> 1;
				this._incCoarseX();
				if (dot === 256) this._incY();
			} else if ((dot & 1) === 1) this._bgFetch(dot);
			dot++;
		}
		this.bgShiftLo = bgLo;
		this.bgShiftHi = bgHi;
		this.attrShiftLo = atLo;
		this.attrShiftHi = atHi;
		this.attrLatchLo = latLo;
		this.attrLatchHi = latHi;
	}
	_evaluateSpan(line, from, to) {
		for (let dot = from; dot < to; dot++) {
			if (dot === 65 && to === 257) {
				this._evaluateWindow(line);
				return;
			}
			if (dot <= 64) {
				if ((dot & 1) === 0) {
					this.secondaryOAM[(dot >> 1) - 1] = 255;
					this.secIdx = dot >> 1 & 31;
					if (dot === 64) this._startEvaluation();
				}
			} else if ((dot & 1) === 1) this.oamLatch = this.spriteMem[this.sramAddress];
			else this._evaluateSprites(line, dot);
		}
	}
	_spritePixel(x, bgPixel) {
		let result = 0;
		const count = this.sprCount;
		const glitch = this.spriteSkipGlitch;
		this.spriteSkipGlitch = false;
		const showSprites = this.f_spVisibility === 1 && (x >= 8 || this.f_spClipping === 1);
		const sprX = this.sprX;
		const sprLo = this.sprLo;
		const sprHi = this.sprHi;
		for (let i = 0; i < count; i++) {
			if (sprX[i] !== 0 && !glitch) {
				sprX[i]--;
				continue;
			}
			const p = sprLo[i] >> 7 & 1 | sprHi[i] >> 6 & 2;
			sprLo[i] = sprLo[i] << 1;
			sprHi[i] = sprHi[i] << 1;
			if (glitch && this.sprLatchX[i] !== 0) sprX[i] = this.sprLatchX[i] - 1;
			if (p === 0 || !showSprites) continue;
			if (i === 0 && this.sprite0Line && bgPixel !== 0 && x !== 255) this.sprite0HitFlag = 1;
			if (result === 0) {
				const attr = this.sprAttr[i];
				result = 16 | p | (attr & 3) << 2 | (attr & 32) << 3;
			}
		}
		return result;
	}
	_startEvaluation() {
		this.secIdx = 0;
		this.secFull = false;
		this.evalDone = false;
		this.evalOvfStep = 0;
		this.sprite0Next = false;
	}
	_inRange(line, y) {
		const row = line - y;
		return row >= 0 && row < (this.f_spriteSize ? 16 : 8);
	}
	_evaluateWindow(line) {
		const oam = this.spriteMem;
		const sec = this.secondaryOAM;
		const height = this.f_spriteSize ? 16 : 8;
		let addr = this.sramAddress;
		let secIdx = this.secIdx;
		let secFull = this.secFull;
		let done = this.evalDone;
		let ovfStep = this.evalOvfStep;
		let latch = this.oamLatch;
		for (let dot = 66; dot <= 256; dot += 2) {
			if (done) {
				const steps = (256 - dot >> 1) + 1;
				latch = oam[addr + 4 * (steps - 1) & 255];
				addr = addr + 4 * steps & 255;
				break;
			}
			const s = latch = oam[addr];
			const row = line - s;
			const inRange = row >= 0 && row < height;
			if (!secFull) {
				const step = secIdx & 3;
				sec[secIdx] = s;
				if (step === 0) {
					if (inRange) {
						if (dot === 66) this.sprite0Next = true;
						secIdx++;
						addr++;
					} else addr = addr + 4 & -4;
				} else if (step < 3) {
					secIdx++;
					addr++;
				} else {
					secIdx++;
					addr = inRange ? addr + 1 : addr + 1 & -4;
				}
				if (secIdx === 32) {
					secFull = true;
					secIdx = 0;
				}
			} else if (ovfStep === 0) {
				if (inRange) {
					this.spriteOverflowFlag = 1;
					ovfStep = 1;
					addr++;
				} else addr += 5;
			} else if (ovfStep < 3) {
				ovfStep++;
				addr++;
			} else {
				ovfStep = 0;
				addr = inRange ? addr + 1 : addr + 5;
			}
			if (addr > 255) {
				done = true;
				addr &= 255;
			}
		}
		this.sramAddress = addr;
		this.secIdx = secIdx;
		this.secFull = secFull;
		this.evalDone = done;
		this.evalOvfStep = ovfStep;
		this.oamLatch = latch;
	}
	_evaluateSprites(line, dot) {
		const s = this.oamLatch;
		let addr = this.sramAddress;
		if (this.evalDone) addr += 4;
		else if (!this.secFull) {
			const step = this.secIdx & 3;
			this.secondaryOAM[this.secIdx] = s;
			if (step === 0) {
				if (this._inRange(line, s)) {
					if (dot === 66) this.sprite0Next = true;
					this.secIdx++;
					addr++;
				} else addr = addr + 4 & -4;
			} else if (step < 3) {
				this.secIdx++;
				addr++;
			} else {
				this.secIdx++;
				addr = this._inRange(line, s) ? addr + 1 : addr + 1 & -4;
			}
			if (this.secIdx === 32) {
				this.secFull = true;
				this.secIdx = 0;
			}
		} else if (this.evalOvfStep === 0) {
			if (this._inRange(line, s)) {
				this.spriteOverflowFlag = 1;
				this.evalOvfStep = 1;
				addr++;
			} else addr += 5;
		} else if (this.evalOvfStep < 3) {
			this.evalOvfStep++;
			addr++;
		} else {
			this.evalOvfStep = 0;
			addr = this._inRange(line, s) ? addr + 1 : addr + 5;
		}
		if (addr > 255) {
			this.evalDone = true;
			addr &= 255;
		}
		this.sramAddress = addr;
	}
	_fetchSprite(slot, line) {
		const base = slot << 2;
		const y = this.secondaryOAM[base];
		const tile = this.secondaryOAM[base + 1];
		const attr = this.secondaryOAM[base + 2];
		const x = this.secondaryOAM[base + 3];
		const height = this.f_spriteSize ? 16 : 8;
		let row = line - y;
		const inRange = row >= 0 && row < height;
		if (attr & 128) row = height - 1 - row;
		row &= height - 1;
		let addr;
		if (height === 8) addr = this.f_spPatternTable << 12 | tile << 4 | row;
		else addr = (tile & 1) << 12 | (tile & 254) << 4 | (row & 8) << 1 | row & 7;
		let lo = this.vramMem[addr];
		let hi = this.vramMem[addr + 8];
		this.nes.mmap.latchAccess(addr + 8);
		if (!inRange) {
			lo = 0;
			hi = 0;
		} else if (attr & 64) {
			lo = REVERSE_BITS[lo];
			hi = REVERSE_BITS[hi];
		}
		this.sprLo[slot] = lo;
		this.sprHi[slot] = hi;
		this.sprAttr[slot] = attr;
		this.sprLatchX[slot] = x;
		if ((lo | hi) !== 0) this.sprFetchCount = slot + 1;
	}
	_renderingDisabled() {
		const line = this.line;
		if (!(line < 240 || line === 261)) return;
		const dot = this.dot;
		let row = this.secIdx;
		if (dot >= 65 && dot <= 256) row = row + 3 & 28;
		this.oamCorruptPending = true;
		this.oamCorruptRow = row & 31;
	}
	_performOamCorruption() {
		this.oamCorruptPending = false;
		const base = this.oamCorruptRow << 3;
		for (let i = 0; i < 8; i++) this.spriteMem[base + i] = this.spriteMem[i];
		this.secondaryOAM[this.oamCorruptRow] = this.secondaryOAM[0];
	}
	startFrame() {}
	endFrame() {
		let y;
		let buffer = this.buffer;
		if (this.clipToTvSize) {
			for (y = 0; y < 240; y++) {
				buffer.fill(0, y << 8, (y << 8) + 8);
				buffer.fill(0, (y << 8) + 248, (y << 8) + 256);
			}
			buffer.fill(0, 0, 2048);
			buffer.fill(0, 59392, 61440);
		} else if (this.f_bgClipping === 0 || this.f_spClipping === 0) for (y = 0; y < 240; y++) buffer.fill(0, y << 8, (y << 8) + 8);
		this.nes.ui.writeFrame(buffer);
	}
	isPixelWhite(x, y) {
		this.catchUp();
		return this.buffer[(y << 8) + x] === 16777215;
	}
	static JSON_PROPERTIES = [
		"vramMem",
		"spriteMem",
		"secondaryOAM",
		"vramAddress",
		"vramTmpAddress",
		"fineX",
		"firstWrite",
		"vramBufferedReadValue",
		"sramAddress",
		"openBusLatch",
		"openBusDecayFrames",
		"currentMirroring",
		"ntable1",
		"vblankFlag",
		"sprite0HitFlag",
		"spriteOverflowFlag",
		"nmiOutput",
		"nmiAtPoll",
		"nmiSuppressed",
		"line",
		"dot",
		"scanline",
		"oddFrame",
		"renderingOn",
		"maskDelay",
		"bgShiftLo",
		"bgShiftHi",
		"attrShiftLo",
		"attrShiftHi",
		"attrLatchLo",
		"attrLatchHi",
		"ntByte",
		"atBits",
		"ptLo",
		"ptHi",
		"secIdx",
		"secFull",
		"oamLatch",
		"evalDone",
		"evalOvfStep",
		"sprite0Next",
		"sprite0Line",
		"oamCorruptPending",
		"oamCorruptRow",
		"sprCount",
		"sprLo",
		"sprHi",
		"sprAttr",
		"sprX",
		"sprLatchX",
		"sprFetchCount",
		"spriteSkipGlitch",
		"f_nmiOnVblank",
		"f_spriteSize",
		"f_bgPatternTable",
		"f_spPatternTable",
		"f_addrInc",
		"f_nTblAddress",
		"f_color",
		"f_spVisibility",
		"f_bgVisibility",
		"f_spClipping",
		"f_bgClipping",
		"f_dispType"
	];
	toJSON() {
		this.catchUp();
		this._materializeSprites();
		let state = toJSON(this);
		state.vramMirrorTable = this.vramMirrorTable;
		return state;
	}
	fromJSON(state) {
		fromJSON(this, state);
		if (state.vramMirrorTable) this.vramMirrorTable.set(state.vramMirrorTable);
		this.dotTarget = 0;
		this.dotsRun = 0;
		this.nextEventDot = 0;
		for (let i = 0; i < 8192; i++) this.patternWrite(i, this.vramMem[i]);
		if (this.f_dispType === 0) this.palTable.setEmphasis(this.f_color);
		this.updatePalettes();
	}
};
var SEC_IDX_STEPS = /* @__PURE__ */ new Uint8Array(65);
for (let n = 1; n <= 64; n++) {
	const phase = n - 1 & 7;
	SEC_IDX_STEPS[n] = SEC_IDX_STEPS[n - 1] + (phase <= 2 || phase === 7 ? 1 : 0);
}
var DECODE_PLANES = /* @__PURE__ */ new Uint16Array(65536);
for (let v = 0; v < 65536; v++) {
	const lo = v & 255;
	const hi = v >> 8;
	let packed = 0;
	for (let k = 0; k < 8; k++) {
		const p = lo >> 7 - k & 1 | (hi >> 7 - k & 1) << 1;
		packed |= p << 14 - 2 * k;
	}
	DECODE_PLANES[v] = packed;
}
var REVERSE_BITS = /* @__PURE__ */ new Uint8Array(256);
for (let i = 0; i < 256; i++) {
	let r = 0;
	for (let b = 0; b < 8; b++) if (i & 1 << b) r |= 128 >> b;
	REVERSE_BITS[i] = r;
}
//#endregion
//#region node_modules/jsnes/src/papu/channel-dm.js
var ChannelDM = class {
	static JSON_PROPERTIES = [
		"isEnabled",
		"irqEnabled",
		"loop",
		"irqFlag",
		"period",
		"timer",
		"outputLevel",
		"sample",
		"sampleAddress",
		"sampleLength",
		"currentAddress",
		"bytesRemaining",
		"buffer",
		"bufferEmpty",
		"shiftRegister",
		"bitsRemaining",
		"silence",
		"startDelay",
		"disableDelay",
		"lastFetchCycle"
	];
	constructor(papu) {
		this.papu = papu;
		this.isEnabled = false;
		this.irqEnabled = false;
		this.loop = false;
		this.period = 428;
		this.irqFlag = false;
		this.timer = 428;
		this.outputLevel = 0;
		this.sample = 0;
		this.shiftRegister = 0;
		this.bitsRemaining = 8;
		this.silence = true;
		this.sampleAddress = 49152;
		this.sampleLength = 1;
		this.currentAddress = 49152;
		this.bytesRemaining = 0;
		this.buffer = 0;
		this.bufferEmpty = true;
		this.startDelay = 0;
		this.disableDelay = 0;
		this.lastFetchCycle = -100;
	}
	clockDelays() {
		if (this.disableDelay !== 0 && --this.disableDelay === 0) {
			this.bytesRemaining = 0;
			this.papu.nes.cpu.stopDmcDma();
		}
		if (this.startDelay !== 0 && --this.startDelay === 0) this._requestDma();
	}
	_clockOutput() {
		if (!this.silence) {
			if ((this.shiftRegister & 1) !== 0) {
				if (this.outputLevel <= 125) this.outputLevel += 2;
			} else if (this.outputLevel >= 2) this.outputLevel -= 2;
			this._updateSample();
		}
		this.shiftRegister >>= 1;
		if (--this.bitsRemaining === 0) {
			this.bitsRemaining = 8;
			if (this.bufferEmpty) this.silence = true;
			else {
				this.silence = false;
				this.shiftRegister = this.buffer;
				this.bufferEmpty = true;
				this._requestDma();
			}
		}
	}
	_updateSample() {
		this.papu._flushAudio();
		this.sample = this.outputLevel;
	}
	_requestDma() {
		if (!this.bufferEmpty || this.startDelay !== 0) return;
		const cpu = this.papu.nes.cpu;
		if (this.bytesRemaining > 0) cpu.startDmcDma();
		else if (cpu.cycles - this.lastFetchCycle <= 2) cpu.startAbortedDmcDma();
	}
	dmaComplete(value) {
		this.lastFetchCycle = this.papu.nes.cpu.cycles;
		if (this.bytesRemaining === 0) return;
		this.buffer = value;
		this.bufferEmpty = false;
		this.currentAddress = this.currentAddress === 65535 ? 32768 : this.currentAddress + 1;
		this.bytesRemaining--;
		if (this.bytesRemaining === 0) {
			if (this.loop) this._restart();
			else if (this.irqEnabled) this._setIrq(true);
		}
	}
	_restart() {
		this.currentAddress = this.sampleAddress;
		this.bytesRemaining = this.sampleLength;
	}
	_setIrq(active) {
		this.irqFlag = active;
		this.papu.nes.cpu.setIrqSource(4, active);
	}
	writeReg(address, value) {
		if (address === 16400) {
			this.irqEnabled = (value & 128) !== 0;
			this.loop = (value & 64) !== 0;
			if (!this.irqEnabled) this._setIrq(false);
			this.period = this.papu.getDmcFrequency(value & 15) >> 3;
		} else if (address === 16401) {
			this.outputLevel = value & 127;
			this._updateSample();
		} else if (address === 16402) this.sampleAddress = 49152 | value << 6;
		else if (address === 16403) this.sampleLength = value << 4 | 1;
		else if (address === 16405) {
			this._setIrq(false);
			const put = this.papu._isPutCycle();
			if ((value & 16) === 0) {
				if (this.disableDelay === 0) this.disableDelay = put ? 2 : 3;
			} else {
				this.disableDelay = 0;
				if (this.bytesRemaining === 0) {
					this._restart();
					this.startDelay = put ? 2 : 3;
				}
			}
		}
	}
	setEnabled(value) {
		this.isEnabled = value;
	}
	getLengthStatus() {
		return this.bytesRemaining > 0 ? 1 : 0;
	}
	getIrqStatus() {
		return this.irqFlag ? 1 : 0;
	}
	toJSON() {
		return toJSON(this);
	}
	fromJSON(s) {
		fromJSON(this, s);
	}
};
//#endregion
//#region node_modules/jsnes/src/papu/channel-noise.js
var ChannelNoise = class {
	constructor(papu) {
		this.papu = papu;
		this.progTimerCount = 0;
		this.progTimerMax = 0;
		this.isEnabled = false;
		this.lengthCounter = 0;
		this.lengthCounterEnable = false;
		this.envDecayDisable = false;
		this.envDecayLoopEnable = false;
		this.envReset = false;
		this.shiftNow = false;
		this.envDecayRate = 0;
		this.envDecayCounter = 0;
		this.envVolume = 0;
		this.masterVolume = 0;
		this.shiftReg = 1;
		this.randomBit = 0;
		this.randomMode = 0;
		this.sampleValue = 0;
		this.tmp = 0;
		this.accValue = 0;
		this.accCount = 1;
	}
	clockLengthCounter() {
		if (this.lengthCounterEnable && this.lengthCounter > 0) {
			this.lengthCounter--;
			if (this.lengthCounter === 0) this.updateSampleValue();
		}
	}
	clockEnvDecay() {
		if (this.envReset) {
			this.envReset = false;
			this.envDecayCounter = this.envDecayRate + 1;
			this.envVolume = 15;
		} else if (--this.envDecayCounter <= 0) {
			this.envDecayCounter = this.envDecayRate + 1;
			if (this.envVolume > 0) this.envVolume--;
			else this.envVolume = this.envDecayLoopEnable ? 15 : 0;
		}
		if (this.envDecayDisable) this.masterVolume = this.envDecayRate;
		else this.masterVolume = this.envVolume;
		this.updateSampleValue();
	}
	updateSampleValue() {
		if (this.isEnabled && this.lengthCounter > 0) this.sampleValue = this.randomBit * this.masterVolume;
	}
	writeReg(address, value) {
		if (address === 16396) {
			this.envDecayDisable = (value & 16) !== 0;
			this.envDecayRate = value & 15;
			this.envDecayLoopEnable = (value & 32) !== 0;
			this.lengthCounterEnable = (value & 32) === 0;
			if (this.envDecayDisable) this.masterVolume = this.envDecayRate;
			else this.masterVolume = this.envVolume;
		} else if (address === 16398) {
			this.progTimerMax = this.papu.getNoiseWaveLength(value & 15);
			this.randomMode = value >> 7;
		} else if (address === 16399) {
			if (this.isEnabled) this.lengthCounter = this.papu.getLengthMax(value & 248);
			this.envReset = true;
		}
	}
	setEnabled(value) {
		this.isEnabled = value;
		if (!value) this.lengthCounter = 0;
		this.updateSampleValue();
	}
	getLengthStatus() {
		return this.lengthCounter === 0 || !this.isEnabled ? 0 : 1;
	}
	toJSON() {
		return toJSON(this);
	}
	fromJSON(s) {
		fromJSON(this, s);
	}
	static JSON_PROPERTIES = [
		"isEnabled",
		"envDecayDisable",
		"envDecayLoopEnable",
		"lengthCounterEnable",
		"envReset",
		"shiftNow",
		"lengthCounter",
		"progTimerCount",
		"progTimerMax",
		"envDecayRate",
		"envDecayCounter",
		"envVolume",
		"masterVolume",
		"shiftReg",
		"randomBit",
		"randomMode",
		"sampleValue",
		"accValue",
		"accCount",
		"tmp"
	];
};
//#endregion
//#region node_modules/jsnes/src/papu/channel-square.js
var ChannelSquare = class {
	constructor(papu, square1) {
		this.papu = papu;
		this.dutyLookup = [
			0,
			1,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			1,
			1,
			0,
			0,
			0,
			0,
			0,
			0,
			1,
			1,
			1,
			1,
			0,
			0,
			0,
			1,
			0,
			0,
			1,
			1,
			1,
			1,
			1
		];
		this.impLookup = [
			1,
			-1,
			0,
			0,
			0,
			0,
			0,
			0,
			1,
			0,
			-1,
			0,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			-1,
			0,
			0,
			0,
			-1,
			0,
			1,
			0,
			0,
			0,
			0,
			0
		];
		this.sqr1 = square1;
		this.progTimerCount = 0;
		this.progTimerMax = 0;
		this.lengthCounter = 0;
		this.squareCounter = 0;
		this.sweepCounter = 0;
		this.sweepCounterMax = 0;
		this.sweepMode = 0;
		this.sweepShiftAmount = 0;
		this.envDecayRate = 0;
		this.envDecayCounter = 0;
		this.envVolume = 0;
		this.masterVolume = 0;
		this.dutyMode = 0;
		this.vol = 0;
		this.isEnabled = false;
		this.lengthCounterEnable = false;
		this.sweepActive = false;
		this.sweepCarry = false;
		this.envDecayDisable = false;
		this.envDecayLoopEnable = false;
		this.envReset = false;
		this.updateSweepPeriod = false;
		this.sweepResult = 0;
		this.sampleValue = 0;
	}
	clockLengthCounter() {
		if (this.lengthCounterEnable && this.lengthCounter > 0) {
			this.lengthCounter--;
			if (this.lengthCounter === 0) this.updateSampleValue();
		}
	}
	clockEnvDecay() {
		if (this.envReset) {
			this.envReset = false;
			this.envDecayCounter = this.envDecayRate + 1;
			this.envVolume = 15;
		} else if (--this.envDecayCounter <= 0) {
			this.envDecayCounter = this.envDecayRate + 1;
			if (this.envVolume > 0) this.envVolume--;
			else this.envVolume = this.envDecayLoopEnable ? 15 : 0;
		}
		if (this.envDecayDisable) this.masterVolume = this.envDecayRate;
		else this.masterVolume = this.envVolume;
		this.updateSampleValue();
	}
	clockSweep() {
		if (--this.sweepCounter <= 0) {
			this.sweepCounter = this.sweepCounterMax + 1;
			if (this.sweepActive && this.sweepShiftAmount > 0 && this.progTimerMax > 7) {
				this.sweepCarry = false;
				if (this.sweepMode === 0) {
					this.progTimerMax += this.progTimerMax >> this.sweepShiftAmount;
					if (this.progTimerMax > 2047) {
						this.progTimerMax = 4095;
						this.sweepCarry = true;
					}
				} else this.progTimerMax = this.progTimerMax - ((this.progTimerMax >> this.sweepShiftAmount) + (this.sqr1 ? 1 : 0));
			}
		}
		if (this.updateSweepPeriod) {
			this.updateSweepPeriod = false;
			this.sweepCounter = this.sweepCounterMax + 1;
		}
	}
	updateSampleValue() {
		if (this.isEnabled && this.lengthCounter > 0 && this.progTimerMax > 7) {
			if (this.sweepMode === 0 && this.progTimerMax + (this.progTimerMax >> this.sweepShiftAmount) > 2047) this.sampleValue = 0;
			else this.sampleValue = this.masterVolume * this.dutyLookup[(this.dutyMode << 3) + this.squareCounter];
		} else this.sampleValue = 0;
	}
	writeReg(address, value) {
		let addrAdd = this.sqr1 ? 0 : 4;
		if (address === 16384 + addrAdd) {
			this.envDecayDisable = (value & 16) !== 0;
			this.envDecayRate = value & 15;
			this.envDecayLoopEnable = (value & 32) !== 0;
			this.dutyMode = value >> 6 & 3;
			this.lengthCounterEnable = (value & 32) === 0;
			if (this.envDecayDisable) this.masterVolume = this.envDecayRate;
			else this.masterVolume = this.envVolume;
			this.updateSampleValue();
		} else if (address === 16385 + addrAdd) {
			this.sweepActive = (value & 128) !== 0;
			this.sweepCounterMax = value >> 4 & 7;
			this.sweepMode = value >> 3 & 1;
			this.sweepShiftAmount = value & 7;
			this.updateSweepPeriod = true;
		} else if (address === 16386 + addrAdd) {
			this.progTimerMax &= 1792;
			this.progTimerMax |= value;
		} else if (address === 16387 + addrAdd) {
			this.progTimerMax &= 255;
			this.progTimerMax |= (value & 7) << 8;
			if (this.isEnabled) this.lengthCounter = this.papu.getLengthMax(value & 248);
			this.envReset = true;
		}
	}
	setEnabled(value) {
		this.isEnabled = value;
		if (!value) this.lengthCounter = 0;
		this.updateSampleValue();
	}
	getLengthStatus() {
		return this.lengthCounter === 0 || !this.isEnabled ? 0 : 1;
	}
	toJSON() {
		return toJSON(this);
	}
	fromJSON(s) {
		fromJSON(this, s);
	}
	static JSON_PROPERTIES = [
		"isEnabled",
		"lengthCounterEnable",
		"sweepActive",
		"envDecayDisable",
		"envDecayLoopEnable",
		"envReset",
		"sweepCarry",
		"updateSweepPeriod",
		"progTimerCount",
		"progTimerMax",
		"lengthCounter",
		"squareCounter",
		"sweepCounter",
		"sweepCounterMax",
		"sweepMode",
		"sweepShiftAmount",
		"envDecayRate",
		"envDecayCounter",
		"envVolume",
		"masterVolume",
		"dutyMode",
		"sweepResult",
		"sampleValue",
		"vol"
	];
};
//#endregion
//#region node_modules/jsnes/src/papu/channel-triangle.js
var ChannelTriangle = class {
	constructor(papu) {
		this.papu = papu;
		this.progTimerCount = 0;
		this.progTimerMax = 0;
		this.triangleCounter = 0;
		this.isEnabled = false;
		this.sampleCondition = false;
		this.lengthCounter = 0;
		this.lengthCounterEnable = false;
		this.linearCounter = 0;
		this.lcLoadValue = 0;
		this.lcHalt = true;
		this.lcControl = false;
		this.tmp = 0;
		this.sampleValue = 15;
	}
	clockLengthCounter() {
		if (this.lengthCounterEnable && this.lengthCounter > 0) {
			this.lengthCounter--;
			if (this.lengthCounter === 0) this.updateSampleCondition();
		}
	}
	clockLinearCounter() {
		if (this.lcHalt) {
			this.linearCounter = this.lcLoadValue;
			this.updateSampleCondition();
		} else if (this.linearCounter > 0) {
			this.linearCounter--;
			this.updateSampleCondition();
		}
		if (!this.lcControl) this.lcHalt = false;
	}
	getLengthStatus() {
		return this.lengthCounter === 0 || !this.isEnabled ? 0 : 1;
	}
	readReg(address) {
		return 0;
	}
	writeReg(address, value) {
		if (address === 16392) {
			this.lcControl = (value & 128) !== 0;
			this.lcLoadValue = value & 127;
			this.lengthCounterEnable = !this.lcControl;
		} else if (address === 16394) {
			this.progTimerMax &= 1792;
			this.progTimerMax |= value;
		} else if (address === 16395) {
			this.progTimerMax &= 255;
			this.progTimerMax |= (value & 7) << 8;
			if (this.isEnabled) this.lengthCounter = this.papu.getLengthMax(value & 248);
			this.lcHalt = true;
		}
		this.updateSampleCondition();
	}
	clockProgrammableTimer(nCycles) {
		if (this.progTimerMax > 0) {
			this.progTimerCount += nCycles;
			while (this.progTimerMax > 0 && this.progTimerCount >= this.progTimerMax) {
				this.progTimerCount -= this.progTimerMax;
				if (this.isEnabled && this.lengthCounter > 0 && this.linearCounter > 0) this.clockTriangleGenerator();
			}
		}
	}
	clockTriangleGenerator() {
		this.triangleCounter++;
		this.triangleCounter &= 31;
	}
	setEnabled(value) {
		this.isEnabled = value;
		if (!value) this.lengthCounter = 0;
		this.updateSampleCondition();
	}
	updateSampleCondition() {
		this.sampleCondition = this.isEnabled && this.progTimerMax > 7 && this.linearCounter > 0 && this.lengthCounter > 0;
	}
	toJSON() {
		return toJSON(this);
	}
	fromJSON(s) {
		fromJSON(this, s);
	}
	static JSON_PROPERTIES = [
		"isEnabled",
		"sampleCondition",
		"lengthCounterEnable",
		"lcHalt",
		"lcControl",
		"progTimerCount",
		"progTimerMax",
		"triangleCounter",
		"lengthCounter",
		"linearCounter",
		"lcLoadValue",
		"sampleValue",
		"tmp"
	];
};
//#endregion
//#region node_modules/jsnes/src/papu/index.js
var CPU_FREQ_NTSC = 1789772.5;
var FRAME_STEPS_4 = [
	7457,
	14913,
	22371,
	29828,
	29829
];
var FRAME_STEPS_5 = [
	7457,
	14913,
	22371,
	29829,
	37281
];
var FRAME_PERIOD_4 = 29830;
var FRAME_PERIOD_5 = 37282;
var PAPU = class {
	constructor(nes) {
		this.nes = nes;
		this.lastCycle = 0;
		this.nextEventCycle = 0;
		this.square1 = new ChannelSquare(this, true);
		this.square2 = new ChannelSquare(this, false);
		this.triangle = new ChannelTriangle(this);
		this.noise = new ChannelNoise(this);
		this.dmc = new ChannelDM(this);
		this.startedPlaying = false;
		this.recordOutput = false;
		this.triValue = 0;
		this.prevSampleL = 0;
		this.prevSampleR = 0;
		this.smpAccumL = 0;
		this.smpAccumR = 0;
		this.dacRange = 0;
		this.dcValue = 0;
		this.masterVolume = 256;
		this.panning = [
			80,
			170,
			100,
			150,
			128
		];
		this.setPanning(this.panning);
		this.initLengthLookup();
		this.initDmcFrequencyLookup();
		this.initNoiseWavelengthLookup();
		this.initDACtables();
		for (let i = 0; i < 20; i++) if (i === 16) this.writeReg(16400, 16);
		else this.writeReg(16384 + i, 0);
		this.sampleRate = this.nes.opts.sampleRate;
		this.emulateSound = this.nes.opts.emulateSound !== false;
		this.sampleTimerMax = Math.floor(1024 * CPU_FREQ_NTSC / this.sampleRate);
		this.sampleTimer = 0;
		this.updateChannelEnable(0);
		this.frameCycleCounter = 0;
		this.lastCycle = 0;
		this.frameStep = 0;
		this.countSequence = 0;
		this.sampleCount = 0;
		this.frameIrqEnabled = false;
		this.frameIrqActive = false;
		this.frameIrqClearPending = false;
		this.frameIrqClearDelay = 0;
		this.nextFrameEvent = FRAME_STEPS_4[0];
		this.pendingAudioCycles = 0;
		this.audioFlushAt = 1;
		this.accCount = 0;
		this.smpSquare1 = 0;
		this.smpSquare2 = 0;
		this.smpTriangle = 0;
		this.smpDmc = 0;
		this.channelEnableValue = 255;
		this.maxSample = -5e5;
		this.minSample = 5e5;
		this._scheduleNextEvent();
	}
	readReg(address) {
		this.catchUp(this.nes.cpu.cycles);
		const value = this._readStatus(address);
		this._scheduleNextEvent();
		return value;
	}
	writeReg(address, value) {
		this.catchUp(this.nes.cpu.cycles);
		this._writeRegister(address, value);
		this._scheduleNextEvent();
	}
	_readStatus(address) {
		let tmp = 0;
		tmp |= this.square1.getLengthStatus();
		tmp |= this.square2.getLengthStatus() << 1;
		tmp |= this.triangle.getLengthStatus() << 2;
		tmp |= this.noise.getLengthStatus() << 3;
		tmp |= this.dmc.getLengthStatus() << 4;
		tmp |= this.nes.cpu.dataBus & 32;
		tmp |= (this.frameIrqActive ? 1 : 0) << 6;
		tmp |= this.dmc.getIrqStatus() << 7;
		if (this.frameIrqActive) {
			this.frameIrqClearPending = true;
			this.frameIrqClearDelay = this._isPutCycle() ? 1 : 2;
		}
		return tmp & 255;
	}
	_writeRegister(address, value) {
		this._flushAudio();
		if (address >= 16384 && address < 16388) this.square1.writeReg(address, value);
		else if (address >= 16388 && address < 16392) this.square2.writeReg(address, value);
		else if (address >= 16392 && address < 16396) this.triangle.writeReg(address, value);
		else if (address >= 16396 && address <= 16399) this.noise.writeReg(address, value);
		else if (address === 16400) this.dmc.writeReg(address, value);
		else if (address === 16401) this.dmc.writeReg(address, value);
		else if (address === 16402) this.dmc.writeReg(address, value);
		else if (address === 16403) this.dmc.writeReg(address, value);
		else if (address === 16405) {
			this.updateChannelEnable(value);
			this.dmc.writeReg(address, value);
		} else if (address === 16407) {
			this.countSequence = value >> 7 & 1;
			this.frameCycleCounter = this._isPutCycle() ? -3 : -4;
			this.frameStep = 0;
			this._updateNextFrameEvent();
			if (value & 64) {
				this.frameIrqEnabled = false;
				this.frameIrqClearPending = false;
				this._setFrameIrq(false);
			} else {
				this.frameIrqEnabled = true;
				this._setFrameIrq(this.frameIrqActive);
			}
			if (this.countSequence === 1) {
				this.clockQuarterFrame();
				this.clockHalfFrame();
			}
		}
	}
	updateChannelEnable(value) {
		this.channelEnableValue = value & 65535;
		this.square1.setEnabled((value & 1) !== 0);
		this.square2.setEnabled((value & 2) !== 0);
		this.triangle.setEnabled((value & 4) !== 0);
		this.noise.setEnabled((value & 8) !== 0);
		this.dmc.setEnabled((value & 16) !== 0);
	}
	catchUp(cycle) {
		while (this.lastCycle < cycle) {
			let next = this.nextEventCycle;
			if (next <= this.lastCycle) next = this.lastCycle + 1;
			if (next > cycle) {
				this._advance(cycle - this.lastCycle);
				this.lastCycle = cycle;
				return;
			}
			if (next - 1 > this.lastCycle) {
				this._advance(next - 1 - this.lastCycle);
				this.lastCycle = next - 1;
			}
			this.clockCycle(next);
			this.lastCycle = next;
			this._scheduleNextEvent();
		}
	}
	_advance(n) {
		if (this.emulateSound) this.pendingAudioCycles += n;
		this.frameCycleCounter += n;
		const a = this.lastCycle;
		this.dmc.timer -= 2 * ((a + n >> 1) - (a >> 1));
	}
	_scheduleNextEvent() {
		const last = this.lastCycle;
		const dmc = this.dmc;
		if ((this.frameIrqClearDelay | dmc.disableDelay | dmc.startDelay) !== 0) {
			this.nextEventCycle = last + 1;
			return;
		}
		let next = last + (this.nextFrameEvent - this.frameCycleCounter);
		if (this.emulateSound) {
			const a = last + (this.audioFlushAt - this.pendingAudioCycles);
			if (a < next) next = a;
		}
		let even = last + 1;
		if (even & 1) even++;
		const steps = dmc.timer + 1 >> 1;
		const d = steps > 1 ? even + 2 * (steps - 1) : even;
		if (d < next) next = d;
		this.nextEventCycle = next > last ? next : last + 1;
	}
	clockCycle(cycle) {
		if (this.emulateSound && ++this.pendingAudioCycles >= this.audioFlushAt) this._flushAudio();
		const dmc = this.dmc;
		if ((this.frameIrqClearDelay | dmc.disableDelay | dmc.startDelay) !== 0) this._clockDelays();
		if (++this.frameCycleCounter >= this.nextFrameEvent) this._advanceFrameSteps();
		if ((cycle & 1) === 0) {
			dmc.timer -= 2;
			if (dmc.timer <= 0) {
				dmc.timer = dmc.period;
				dmc._clockOutput();
			}
		}
	}
	_clockDelays() {
		if (this.frameIrqClearDelay !== 0 && --this.frameIrqClearDelay === 0) {
			if (this.frameIrqClearPending) {
				this.frameIrqClearPending = false;
				this._setFrameIrq(false);
			}
		}
		this.dmc.clockDelays();
	}
	_flushAudio() {
		let nCycles = this.pendingAudioCycles;
		this.pendingAudioCycles = 0;
		while (nCycles > 0) {
			let n = this._cyclesToNextSample();
			if (nCycles < n) n = nCycles;
			this._clockChannels(n);
			nCycles -= n;
		}
		this.audioFlushAt = this._cyclesToNextSample();
	}
	_cyclesToNextSample() {
		const n = (this.sampleTimerMax - this.sampleTimer >> 10) + 1;
		return n < 1 ? 1 : n;
	}
	_clockChannels(nCycles) {
		let triangle = this.triangle;
		let square1 = this.square1;
		let square2 = this.square2;
		let noise = this.noise;
		if (triangle.progTimerMax > 0) {
			triangle.progTimerCount -= nCycles;
			while (triangle.progTimerCount <= 0) {
				triangle.progTimerCount += triangle.progTimerMax + 1;
				if (triangle.linearCounter > 0 && triangle.lengthCounter > 0) {
					triangle.triangleCounter++;
					triangle.triangleCounter &= 31;
					if (triangle.isEnabled) {
						if (triangle.triangleCounter >= 16) triangle.sampleValue = triangle.triangleCounter & 15;
						else triangle.sampleValue = 15 - (triangle.triangleCounter & 15);
						triangle.sampleValue <<= 4;
					}
				}
			}
		}
		this.smpSquare1 += this._clockSquare(square1, nCycles);
		this.smpSquare2 += this._clockSquare(square2, nCycles);
		this._clockNoise(noise, nCycles);
		this.accSample(nCycles);
		this.sampleTimer += nCycles << 10;
		if (this.sampleTimer >= this.sampleTimerMax) {
			this.sample();
			this.sampleTimer -= this.sampleTimerMax;
		}
	}
	_clockSquare(square, nCycles) {
		const period = square.progTimerMax + 1 << 1;
		let count = square.progTimerCount;
		if (count < 0) count = 0;
		let remaining = nCycles;
		if (!(square.isEnabled && square.lengthCounter > 0 && square.progTimerMax > 7)) {
			if (count > remaining) square.progTimerCount = count - remaining;
			else {
				const rest = remaining - count;
				const steps = 1 + Math.floor(rest / period);
				square.squareCounter = square.squareCounter + steps & 7;
				square.progTimerCount = period - rest % period;
				square.sampleValue = 0;
			}
			return 0;
		}
		let sum = 0;
		while (count <= remaining) {
			sum += square.sampleValue * count;
			remaining -= count;
			count = period;
			square.squareCounter = square.squareCounter + 1 & 7;
			square.updateSampleValue();
		}
		square.progTimerCount = count - remaining;
		return sum + square.sampleValue * remaining;
	}
	_clockNoise(noise, nCycles) {
		noise.accCount += nCycles;
		if (noise.progTimerMax <= 0) {
			noise.progTimerCount -= nCycles;
			noise.accValue += nCycles * noise.sampleValue;
			return;
		}
		let count = noise.progTimerCount;
		if (count < 1) count = 1;
		let remaining = nCycles;
		let sum = 0;
		while (count <= remaining) {
			sum += noise.sampleValue * (count - 1);
			remaining -= count;
			noise.shiftReg <<= 1;
			noise.tmp = (noise.shiftReg << (noise.randomMode === 0 ? 1 : 6) ^ noise.shiftReg) & 32768;
			if (noise.tmp !== 0) {
				noise.shiftReg |= 1;
				noise.randomBit = 0;
				noise.sampleValue = 0;
			} else {
				noise.randomBit = 1;
				noise.sampleValue = noise.isEnabled && noise.lengthCounter > 0 ? noise.masterVolume : 0;
			}
			sum += noise.sampleValue;
			count = noise.progTimerMax;
		}
		noise.progTimerCount = count - remaining;
		noise.accValue += sum + noise.sampleValue * remaining;
	}
	_setFrameIrq(active) {
		this.frameIrqActive = active;
		this.nes.cpu.setIrqSource(2, active && this.frameIrqEnabled);
	}
	_isPutCycle() {
		return (this.nes.cpu.cycles & 1) === 1;
	}
	_advanceFrameSteps() {
		let steps = this.countSequence === 0 ? FRAME_STEPS_4 : FRAME_STEPS_5;
		let period = this.countSequence === 0 ? FRAME_PERIOD_4 : FRAME_PERIOD_5;
		for (;;) if (this.frameStep < steps.length && this.frameCycleCounter >= steps[this.frameStep]) {
			this.fireFrameStep(this.frameStep);
			this.frameStep++;
		} else if (this.frameStep >= steps.length && this.frameCycleCounter >= period) {
			this.frameStep = 0;
			this.frameCycleCounter -= period;
			if (this.countSequence === 0) {
				this.frameIrqClearPending = false;
				this._setFrameIrq(this.frameIrqEnabled);
			}
		} else break;
		this._updateNextFrameEvent();
	}
	_updateNextFrameEvent() {
		let steps = this.countSequence === 0 ? FRAME_STEPS_4 : FRAME_STEPS_5;
		let period = this.countSequence === 0 ? FRAME_PERIOD_4 : FRAME_PERIOD_5;
		this.nextFrameEvent = this.frameStep < steps.length ? steps[this.frameStep] : period;
	}
	accSample(cycles) {
		if (this.triangle.sampleCondition) {
			this.triValue = Math.floor((this.triangle.progTimerCount << 4) / (this.triangle.progTimerMax + 1));
			if (this.triValue > 16) this.triValue = 16;
			if (this.triangle.triangleCounter >= 16) this.triValue = 16 - this.triValue;
			this.triValue += this.triangle.sampleValue;
		}
		this.smpTriangle += cycles * this.triValue;
		this.smpDmc += cycles * this.dmc.sample;
		this.accCount += cycles;
	}
	fireFrameStep(step) {
		if (this.countSequence === 0) switch (step) {
			case 0:
				this.clockQuarterFrame();
				break;
			case 1:
				this.clockQuarterFrame();
				this.clockHalfFrame();
				break;
			case 2:
				this.clockQuarterFrame();
				break;
			case 3:
				this.frameIrqClearPending = false;
				this._setFrameIrq(true);
				break;
			case 4:
				this.clockQuarterFrame();
				this.clockHalfFrame();
				this.frameIrqClearPending = false;
				this._setFrameIrq(true);
		}
		else switch (step) {
			case 0:
				this.clockQuarterFrame();
				break;
			case 1:
				this.clockQuarterFrame();
				this.clockHalfFrame();
				break;
			case 2:
				this.clockQuarterFrame();
				break;
			case 3: break;
			case 4:
				this.clockQuarterFrame();
				this.clockHalfFrame();
		}
	}
	clockQuarterFrame() {
		this._flushAudio();
		this.square1.clockEnvDecay();
		this.square2.clockEnvDecay();
		this.noise.clockEnvDecay();
		this.triangle.clockLinearCounter();
	}
	clockHalfFrame() {
		this.triangle.clockLengthCounter();
		this.square1.clockLengthCounter();
		this.square2.clockLengthCounter();
		this.noise.clockLengthCounter();
		this.square1.clockSweep();
		this.square2.clockSweep();
	}
	sample() {
		let sq_index, tnd_index;
		if (this.accCount > 0) {
			this.smpSquare1 <<= 4;
			this.smpSquare1 = Math.floor(this.smpSquare1 / this.accCount);
			this.smpSquare2 <<= 4;
			this.smpSquare2 = Math.floor(this.smpSquare2 / this.accCount);
			this.smpTriangle = Math.floor(this.smpTriangle / this.accCount);
			this.smpDmc <<= 4;
			this.smpDmc = Math.floor(this.smpDmc / this.accCount);
			this.accCount = 0;
		} else {
			this.smpSquare1 = this.square1.sampleValue << 4;
			this.smpSquare2 = this.square2.sampleValue << 4;
			this.smpTriangle = this.triangle.sampleValue;
			this.smpDmc = this.dmc.sample << 4;
		}
		let smpNoise = Math.floor((this.noise.accValue << 4) / this.noise.accCount);
		this.noise.accValue = smpNoise >> 4;
		this.noise.accCount = 1;
		sq_index = this.smpSquare1 * this.stereoPosLSquare1 + this.smpSquare2 * this.stereoPosLSquare2 >> 8;
		tnd_index = 3 * this.smpTriangle * this.stereoPosLTriangle + (smpNoise << 1) * this.stereoPosLNoise + this.smpDmc * this.stereoPosLDMC >> 8;
		if (sq_index >= this.square_table.length) sq_index = this.square_table.length - 1;
		if (tnd_index >= this.tnd_table.length) tnd_index = this.tnd_table.length - 1;
		let sampleValueL = this.square_table[sq_index] + this.tnd_table[tnd_index] - this.dcValue;
		sq_index = this.smpSquare1 * this.stereoPosRSquare1 + this.smpSquare2 * this.stereoPosRSquare2 >> 8;
		tnd_index = 3 * this.smpTriangle * this.stereoPosRTriangle + (smpNoise << 1) * this.stereoPosRNoise + this.smpDmc * this.stereoPosRDMC >> 8;
		if (sq_index >= this.square_table.length) sq_index = this.square_table.length - 1;
		if (tnd_index >= this.tnd_table.length) tnd_index = this.tnd_table.length - 1;
		let sampleValueR = this.square_table[sq_index] + this.tnd_table[tnd_index] - this.dcValue;
		let smpDiffL = sampleValueL - this.prevSampleL;
		this.prevSampleL += smpDiffL;
		this.smpAccumL += smpDiffL - (this.smpAccumL >> 10);
		sampleValueL = this.smpAccumL;
		let smpDiffR = sampleValueR - this.prevSampleR;
		this.prevSampleR += smpDiffR;
		this.smpAccumR += smpDiffR - (this.smpAccumR >> 10);
		sampleValueR = this.smpAccumR;
		if (sampleValueL > this.maxSample) this.maxSample = sampleValueL;
		if (sampleValueL < this.minSample) this.minSample = sampleValueL;
		if (this.nes.opts.onAudioSample) this.nes.opts.onAudioSample(sampleValueL / 32768, sampleValueR / 32768);
		this.smpSquare1 = 0;
		this.smpSquare2 = 0;
		this.smpTriangle = 0;
		this.smpDmc = 0;
	}
	getLengthMax(value) {
		return this.lengthLookup[value >> 3];
	}
	getDmcFrequency(value) {
		if (value >= 0 && value < 16) return this.dmcFreqLookup[value];
		return 0;
	}
	getNoiseWaveLength(value) {
		if (value >= 0 && value < 16) return this.noiseWavelengthLookup[value];
		return 0;
	}
	setFrameRate(rate) {
		this.sampleTimerMax = Math.floor(1024 * CPU_FREQ_NTSC * rate / (this.sampleRate * 60));
	}
	setPanning(pos) {
		for (let i = 0; i < 5; i++) this.panning[i] = pos[i];
		this.updateStereoPos();
	}
	setMasterVolume(value) {
		if (value < 0) value = 0;
		if (value > 256) value = 256;
		this.masterVolume = value;
		this.updateStereoPos();
	}
	updateStereoPos() {
		this.stereoPosLSquare1 = this.panning[0] * this.masterVolume >> 8;
		this.stereoPosLSquare2 = this.panning[1] * this.masterVolume >> 8;
		this.stereoPosLTriangle = this.panning[2] * this.masterVolume >> 8;
		this.stereoPosLNoise = this.panning[3] * this.masterVolume >> 8;
		this.stereoPosLDMC = this.panning[4] * this.masterVolume >> 8;
		this.stereoPosRSquare1 = this.masterVolume - this.stereoPosLSquare1;
		this.stereoPosRSquare2 = this.masterVolume - this.stereoPosLSquare2;
		this.stereoPosRTriangle = this.masterVolume - this.stereoPosLTriangle;
		this.stereoPosRNoise = this.masterVolume - this.stereoPosLNoise;
		this.stereoPosRDMC = this.masterVolume - this.stereoPosLDMC;
	}
	initLengthLookup() {
		this.lengthLookup = [
			10,
			254,
			20,
			2,
			40,
			4,
			80,
			6,
			160,
			8,
			60,
			10,
			14,
			12,
			26,
			14,
			12,
			16,
			24,
			18,
			48,
			20,
			96,
			22,
			192,
			24,
			72,
			26,
			16,
			28,
			32,
			30
		];
	}
	initDmcFrequencyLookup() {
		this.dmcFreqLookup = new Array(16);
		this.dmcFreqLookup[0] = 3424;
		this.dmcFreqLookup[1] = 3040;
		this.dmcFreqLookup[2] = 2720;
		this.dmcFreqLookup[3] = 2560;
		this.dmcFreqLookup[4] = 2288;
		this.dmcFreqLookup[5] = 2032;
		this.dmcFreqLookup[6] = 1808;
		this.dmcFreqLookup[7] = 1712;
		this.dmcFreqLookup[8] = 1520;
		this.dmcFreqLookup[9] = 1280;
		this.dmcFreqLookup[10] = 1136;
		this.dmcFreqLookup[11] = 1024;
		this.dmcFreqLookup[12] = 848;
		this.dmcFreqLookup[13] = 672;
		this.dmcFreqLookup[14] = 576;
		this.dmcFreqLookup[15] = 432;
	}
	initNoiseWavelengthLookup() {
		this.noiseWavelengthLookup = new Array(16);
		this.noiseWavelengthLookup[0] = 4;
		this.noiseWavelengthLookup[1] = 8;
		this.noiseWavelengthLookup[2] = 16;
		this.noiseWavelengthLookup[3] = 32;
		this.noiseWavelengthLookup[4] = 64;
		this.noiseWavelengthLookup[5] = 96;
		this.noiseWavelengthLookup[6] = 128;
		this.noiseWavelengthLookup[7] = 160;
		this.noiseWavelengthLookup[8] = 202;
		this.noiseWavelengthLookup[9] = 254;
		this.noiseWavelengthLookup[10] = 380;
		this.noiseWavelengthLookup[11] = 508;
		this.noiseWavelengthLookup[12] = 762;
		this.noiseWavelengthLookup[13] = 1016;
		this.noiseWavelengthLookup[14] = 2034;
		this.noiseWavelengthLookup[15] = 4068;
	}
	initDACtables() {
		let value, ival, i;
		let max_sqr = 0;
		let max_tnd = 0;
		this.square_table = new Array(512);
		this.tnd_table = new Array(3264);
		for (i = 0; i < 512; i++) {
			value = 95.52 / (8128 / (i / 16) + 100);
			value *= .98411;
			value *= 5e4;
			ival = Math.floor(value);
			this.square_table[i] = ival;
			if (ival > max_sqr) max_sqr = ival;
		}
		for (i = 0; i < 3264; i++) {
			value = 163.67 / (24329 / (i / 16) + 100);
			value *= .98411;
			value *= 5e4;
			ival = Math.floor(value);
			this.tnd_table[i] = ival;
			if (ival > max_tnd) max_tnd = ival;
		}
		this.dacRange = max_sqr + max_tnd;
		this.dcValue = this.dacRange / 2;
	}
	toJSON() {
		this.catchUp(this.nes.cpu.cycles);
		let obj = toJSON(this);
		obj.dmc = this.dmc.toJSON();
		obj.noise = this.noise.toJSON();
		obj.square1 = this.square1.toJSON();
		obj.square2 = this.square2.toJSON();
		obj.triangle = this.triangle.toJSON();
		return obj;
	}
	fromJSON(s) {
		fromJSON(this, s);
		this.dmc.fromJSON(s.dmc);
		this.noise.fromJSON(s.noise);
		this.square1.fromJSON(s.square1);
		this.square2.fromJSON(s.square2);
		this.triangle.fromJSON(s.triangle);
		this._scheduleNextEvent();
	}
	static JSON_PROPERTIES = [
		"channelEnableValue",
		"sampleRate",
		"frameIrqEnabled",
		"frameIrqActive",
		"frameIrqClearPending",
		"frameIrqClearDelay",
		"nextFrameEvent",
		"pendingAudioCycles",
		"lastCycle",
		"audioFlushAt",
		"startedPlaying",
		"recordOutput",
		"frameCycleCounter",
		"frameStep",
		"countSequence",
		"sampleTimer",
		"sampleTimerMax",
		"sampleCount",
		"triValue",
		"smpSquare1",
		"smpSquare2",
		"smpTriangle",
		"smpDmc",
		"accCount",
		"prevSampleL",
		"prevSampleR",
		"smpAccumL",
		"smpAccumR",
		"masterVolume",
		"stereoPosLSquare1",
		"stereoPosLSquare2",
		"stereoPosLTriangle",
		"stereoPosLNoise",
		"stereoPosLDMC",
		"stereoPosRSquare1",
		"stereoPosRSquare2",
		"stereoPosRTriangle",
		"stereoPosRNoise",
		"stereoPosRDMC",
		"maxSample",
		"minSample",
		"panning"
	];
};
//#endregion
//#region node_modules/jsnes/src/gamegenie.js
var LETTER_VALUES = "APZLGITYEOXUKSVN";
function toDigit(letter) {
	return LETTER_VALUES.indexOf(letter);
}
function toLetter(digit) {
	return LETTER_VALUES[digit];
}
function toHex(n, width) {
	const s = n.toString(16);
	return "0000".substring(0, width - s.length) + s;
}
var GameGenie = class {
	constructor() {
		this.patches = [];
		this.enabled = true;
		this.onChange = null;
	}
	setEnabled(enabled) {
		this.enabled = enabled;
		if (this.onChange) this.onChange();
	}
	addCode(code) {
		const patch = this.decode(code);
		if (!patch) throw new Error(`Invalid Game Genie code: ${code}`);
		this.patches.push(patch);
		if (this.onChange) this.onChange();
	}
	addPatch(addr, value, key) {
		this.patches.push({
			addr,
			value,
			key
		});
		if (this.onChange) this.onChange();
	}
	removeAllCodes() {
		this.patches = [];
		if (this.onChange) this.onChange();
	}
	applyCodes(addr, value) {
		if (!this.enabled) return value;
		for (let i = 0; i < this.patches.length; ++i) if (this.patches[i].addr === (addr & 32767)) {
			if (this.patches[i].key === void 0 || this.patches[i].key === value) return this.patches[i].value;
		}
		return value;
	}
	decode(code) {
		if (code.includes(":")) return this.decodeHex(code);
		const digits = code.toUpperCase().split("").map(toDigit);
		let value = ((digits[0] & 8) << 4) + ((digits[1] & 7) << 4) + (digits[0] & 7);
		const addr = ((digits[3] & 7) << 12) + ((digits[4] & 8) << 8) + ((digits[5] & 7) << 8) + ((digits[1] & 8) << 4) + ((digits[2] & 7) << 4) + (digits[3] & 8) + (digits[4] & 7);
		let key;
		if (digits.length === 8) {
			value += digits[7] & 8;
			key = ((digits[6] & 8) << 4) + ((digits[7] & 7) << 4) + (digits[5] & 8) + (digits[6] & 7);
		} else value += digits[5] & 8;
		const wantskey = !!(digits[2] >> 3);
		return {
			value,
			addr,
			wantskey,
			key
		};
	}
	encodeHex(addr, value, key, wantskey) {
		let s = toHex(addr, 4) + ":" + toHex(value, 2);
		if (key !== void 0 || wantskey) s += "?";
		if (key !== void 0) s += toHex(key, 2);
		return s;
	}
	decodeHex(s) {
		const match = s.match(/([0-9a-fA-F]+):([0-9a-fA-F]+)(\?[0-9a-fA-F]*)?/);
		if (!match) return null;
		const addr = parseInt(match[1], 16);
		return {
			value: parseInt(match[2], 16),
			addr,
			wantskey: match[3] !== void 0,
			key: match[3] !== void 0 && match[3].length > 1 ? parseInt(match[3].substring(1), 16) : void 0
		};
	}
	encode(addr, value, key, wantskey) {
		const digits = Array(6);
		digits[0] = (value & 7) + (value >> 4 & 8);
		digits[1] = (value >> 4 & 7) + (addr >> 4 & 8);
		digits[2] = addr >> 4 & 7;
		digits[3] = (addr >> 12) + (addr & 8);
		digits[4] = (addr & 7) + (addr >> 8 & 8);
		digits[5] = addr >> 8 & 7;
		if (key === void 0) {
			digits[5] += value & 8;
			if (wantskey) digits[2] += 8;
		} else {
			digits[2] += 8;
			digits[5] += key & 8;
			digits[6] = (key & 7) + (key >> 4 & 8);
			digits[7] = (key >> 4 & 7) + (value & 8);
		}
		return digits.map(toLetter).join("");
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper0.js
var Mapper0 = class Mapper0 {
	static mapperName = "NROM";
	constructor(nes) {
		this.nes = nes;
		this.joy1StrobeState = 0;
		this.joy2StrobeState = 0;
		this.joypadLastWrite = 0;
		this.joypadOutputBit0 = 0;
		this.joypadLastWriteCycle = -2;
		this.zapperFired = false;
		this.zapperX = null;
		this.zapperY = null;
		this.bgTileOverride = false;
		this.irqClockDot = 260;
	}
	write(address, value) {
		if (address < 8192) this.nes.cpu.mem[address & 2047] = value;
		else if (address >= 32768) {} else if (address >= 24576) {
			this.nes.cpu.mem[address] = value;
			this.nes.opts.onBatteryRamWrite(address, value);
		} else if (address > 16407) this.nes.cpu.mem[address] = value;
		else if (address > 8199 && address < 16384) this.regWrite(8192 + (address & 7), value);
		else this.regWrite(address, value);
	}
	writelow(address, value) {
		if (address < 8192) this.nes.cpu.mem[address & 2047] = value;
		else if (address >= 32768) {} else if (address > 16407) this.nes.cpu.mem[address] = value;
		else if (address > 8199 && address < 16384) this.regWrite(8192 + (address & 7), value);
		else this.regWrite(address, value);
	}
	readsPrgFromCpuMem() {
		return this.load === Mapper0.prototype.load;
	}
	load(address) {
		address &= 65535;
		if (address > 16407) {
			if (address < 24576) return this.nes.cpu.dataBus;
			return this.nes.cpu.mem[address];
		} else if (address >= 8192) return this.regLoad(address);
		else return this.nes.cpu.mem[address & 2047];
	}
	regLoad(address) {
		switch (address >> 12) {
			case 0: break;
			case 1: break;
			case 2:
			case 3:
				switch (address & 7) {
					case 0: return this.nes.ppu.openBusLatch;
					case 1: return this.nes.ppu.openBusLatch;
					case 2: return this.nes.ppu.readStatusRegister();
					case 3: return this.nes.ppu.openBusLatch;
					case 4: return this.nes.ppu.sramLoad();
					case 5: return this.nes.ppu.openBusLatch;
					case 6: return this.nes.ppu.openBusLatch;
					case 7: return this.nes.ppu.vramLoad();
				}
				break;
			case 4: switch (address - 16405) {
				case 0: return this.nes.papu.readReg(address);
				case 1: return this.joy1Read() & 31 | this.nes.cpu.dataBus & 224;
				case 2: {
					let w = 0;
					if (this.zapperX !== null && this.zapperY !== null) {
						if (!this.nes.ppu.isPixelWhite(this.zapperX, this.zapperY)) w = 8;
					}
					if (this.zapperFired) w |= 16;
					return (this.joy2Read() | w) & 31 | this.nes.cpu.dataBus & 224;
				}
			}
		}
		return this.nes.cpu.dataBus;
	}
	regWrite(address, value) {
		if (address >= 8192 && address <= 16383) {
			this.nes.ppu.openBusLatch = value;
			this.nes.ppu.openBusDecayFrames = 36;
		}
		switch (address) {
			case 8192:
				this.nes.cpu.mem[address] = value;
				this.nes.ppu.updateControlReg1(value);
				break;
			case 8193:
				this.nes.cpu.mem[address] = value;
				this.nes.ppu.updateControlReg2(value);
				break;
			case 8195:
				this.nes.ppu.writeSRAMAddress(value);
				break;
			case 8196:
				this.nes.ppu.sramWrite(value);
				break;
			case 8197:
				this.nes.ppu.scrollWrite(value);
				break;
			case 8198:
				this.nes.ppu.writeVRAMAddress(value);
				break;
			case 8199:
				this.nes.ppu.vramWrite(value);
				break;
			case 16404:
				this.nes.cpu.startOamDma(value);
				break;
			case 16405:
				this.nes.papu.writeReg(address, value);
				break;
			case 16406: {
				let cycle = this.nes.cpu.cycles;
				if (cycle - this.joypadLastWriteCycle > 1) {
					let prevBit = this.joypadLastWrite & 1;
					if (prevBit !== this.joypadOutputBit0) {
						if (this.joypadOutputBit0 === 1 && prevBit === 0) {
							this.joy1StrobeState = 0;
							this.joy2StrobeState = 0;
						}
						this.joypadOutputBit0 = prevBit;
					}
				}
				this.joypadLastWrite = value;
				this.joypadLastWriteCycle = cycle;
				if (!this.nes.papu._isPutCycle()) {
					let newBit = value & 1;
					if (this.joypadOutputBit0 === 1 && newBit === 0) {
						this.joy1StrobeState = 0;
						this.joy2StrobeState = 0;
					}
					this.joypadOutputBit0 = newBit;
				}
				break;
			}
			case 16407:
				this.nes.papu.writeReg(address, value);
				break;
			default: if (address >= 16384 && address <= 16407) this.nes.papu.writeReg(address, value);
		}
	}
	_syncJoypadOutput() {
		let newBit = this.joypadLastWrite & 1;
		if (newBit !== this.joypadOutputBit0) {
			if (this.joypadOutputBit0 === 1 && newBit === 0) {
				this.joy1StrobeState = 0;
				this.joy2StrobeState = 0;
			}
			this.joypadOutputBit0 = newBit;
		}
	}
	joy1Read() {
		this._syncJoypadOutput();
		if (this.joypadOutputBit0) return this.nes.controllers[1].state[0];
		let ret;
		if (this.joy1StrobeState < 8) ret = this.nes.controllers[1].state[this.joy1StrobeState];
		else ret = 1;
		if (this.joy1StrobeState < 8) this.joy1StrobeState++;
		return ret;
	}
	joy2Read() {
		this._syncJoypadOutput();
		if (this.joypadOutputBit0) return this.nes.controllers[2].state[0];
		let ret;
		if (this.joy2StrobeState < 8) ret = this.nes.controllers[2].state[this.joy2StrobeState];
		else ret = 1;
		if (this.joy2StrobeState < 8) this.joy2StrobeState++;
		return ret;
	}
	loadROM() {
		if (!this.nes.rom.valid || this.nes.rom.romCount < 1) throw new Error("NoMapper: Invalid ROM! Unable to load.");
		this.loadPRGROM();
		this.loadCHRROM();
		this.loadBatteryRam();
		this.nes.cpu.requestIrq(this.nes.cpu.IRQ_RESET);
	}
	loadPRGROM() {
		if (this.nes.rom.romCount > 1) {
			this.loadRomBank(0, 32768);
			this.loadRomBank(1, 49152);
		} else {
			this.loadRomBank(0, 32768);
			this.loadRomBank(0, 49152);
		}
	}
	loadCHRROM() {
		if (this.nes.rom.vromCount > 0) {
			if (this.nes.rom.vromCount === 1) {
				this.loadVromBank(0, 0);
				this.loadVromBank(0, 4096);
			} else {
				this.loadVromBank(0, 0);
				this.loadVromBank(1, 4096);
			}
		}
	}
	loadBatteryRam() {
		if (this.nes.rom.batteryRam) {
			let ram = this.nes.rom.batteryRam;
			if (ram !== null && ram.length === 8192) copyArrayElements(ram, 0, this.nes.cpu.mem, 24576, 8192);
		}
	}
	loadRomBank(bank, address) {
		bank %= this.nes.rom.romCount;
		copyArrayElements(this.nes.rom.rom[bank], 0, this.nes.cpu.mem, address, 16384);
	}
	loadVromBank(bank, address) {
		if (this.nes.rom.vromCount === 0) return;
		this.nes.ppu.triggerRendering();
		copyArrayElements(this.nes.rom.vrom[bank % this.nes.rom.vromCount], 0, this.nes.ppu.vramMem, address, 4096);
		let vromTile = this.nes.rom.vromTile[bank % this.nes.rom.vromCount];
		copyArrayElements(vromTile, 0, this.nes.ppu.ptTile, address >> 4, 256);
	}
	load32kRomBank(bank, address) {
		this.loadRomBank(bank * 2 % this.nes.rom.romCount, address);
		this.loadRomBank((bank * 2 + 1) % this.nes.rom.romCount, address + 16384);
	}
	load8kVromBank(bank4kStart, address) {
		if (this.nes.rom.vromCount === 0) return;
		this.nes.ppu.triggerRendering();
		this.loadVromBank(bank4kStart % this.nes.rom.vromCount, address);
		this.loadVromBank((bank4kStart + 1) % this.nes.rom.vromCount, address + 4096);
	}
	load1kVromBank(bank1k, address) {
		if (this.nes.rom.vromCount === 0) return;
		this.nes.ppu.triggerRendering();
		let bank4k = Math.floor(bank1k / 4) % this.nes.rom.vromCount;
		let bankoffset = bank1k % 4 * 1024;
		copyArrayElements(this.nes.rom.vrom[bank4k], bankoffset, this.nes.ppu.vramMem, address, 1024);
		let vromTile = this.nes.rom.vromTile[bank4k];
		let baseIndex = address >> 4;
		for (let i = 0; i < 64; i++) this.nes.ppu.ptTile[baseIndex + i] = vromTile[(bank1k % 4 << 6) + i];
	}
	load2kVromBank(bank2k, address) {
		if (this.nes.rom.vromCount === 0) return;
		this.nes.ppu.triggerRendering();
		let bank4k = Math.floor(bank2k / 2) % this.nes.rom.vromCount;
		let bankoffset = bank2k % 2 * 2048;
		copyArrayElements(this.nes.rom.vrom[bank4k], bankoffset, this.nes.ppu.vramMem, address, 2048);
		let vromTile = this.nes.rom.vromTile[bank4k];
		let baseIndex = address >> 4;
		for (let i = 0; i < 128; i++) this.nes.ppu.ptTile[baseIndex + i] = vromTile[(bank2k % 2 << 7) + i];
	}
	load8kRomBank(bank8k, address) {
		let bank16k = Math.floor(bank8k / 2) % this.nes.rom.romCount;
		let offset = bank8k % 2 * 8192;
		copyArrayElements(this.nes.rom.rom[bank16k], offset, this.nes.cpu.mem, address, 8192);
	}
	canWriteChr(address) {
		return this.nes.rom.vromCount === 0;
	}
	clockIrqCounter() {}
	latchAccess(address) {}
	onBgRender() {}
	onSpriteRender() {}
	getBgTileData() {
		return null;
	}
	getSpritePatternTile(index) {
		return this.nes.ppu.ptTile[index];
	}
	toJSON() {
		return {
			joy1StrobeState: this.joy1StrobeState,
			joy2StrobeState: this.joy2StrobeState,
			joypadLastWrite: this.joypadLastWrite,
			joypadOutputBit0: this.joypadOutputBit0,
			joypadLastWriteCycle: this.joypadLastWriteCycle
		};
	}
	fromJSON(s) {
		this.joy1StrobeState = s.joy1StrobeState;
		this.joy2StrobeState = s.joy2StrobeState;
		this.joypadLastWrite = s.joypadLastWrite;
		this.joypadOutputBit0 = s.joypadOutputBit0 || 0;
		this.joypadLastWriteCycle = s.joypadLastWriteCycle ?? -2;
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper1.js
var Mapper1 = class extends Mapper0 {
	static mapperName = "MMC1";
	constructor(nes) {
		super(nes);
		this.regBuffer = 0;
		this.regBufferCounter = 0;
		this.mirroring = 0;
		this.oneScreenMirroring = 0;
		this.prgSwitchingArea = 1;
		this.prgSwitchingSize = 1;
		this.vromSwitchingSize = 0;
		this.romSelectionReg0 = 0;
		this.romSelectionReg1 = 0;
		this.romBankSelect = 0;
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		}
		if ((value & 128) !== 0) {
			this.regBufferCounter = 0;
			this.regBuffer = 0;
			if (this.getRegNumber(address) === 0) {
				this.prgSwitchingArea = 1;
				this.prgSwitchingSize = 1;
			}
		} else {
			this.regBuffer = this.regBuffer & 255 - (1 << this.regBufferCounter) | (value & 1) << this.regBufferCounter;
			this.regBufferCounter++;
			if (this.regBufferCounter === 5) {
				this.setReg(this.getRegNumber(address), this.regBuffer);
				this.regBuffer = 0;
				this.regBufferCounter = 0;
			}
		}
	}
	setReg(reg, value) {
		let tmp;
		switch (reg) {
			case 0:
				tmp = value & 3;
				if (tmp !== this.mirroring) {
					this.mirroring = tmp;
					if ((this.mirroring & 2) === 0) this.nes.ppu.setMirroring(this.nes.rom.SINGLESCREEN_MIRRORING);
					else if ((this.mirroring & 1) !== 0) this.nes.ppu.setMirroring(this.nes.rom.HORIZONTAL_MIRRORING);
					else this.nes.ppu.setMirroring(this.nes.rom.VERTICAL_MIRRORING);
				}
				this.prgSwitchingArea = value >> 2 & 1;
				this.prgSwitchingSize = value >> 3 & 1;
				this.vromSwitchingSize = value >> 4 & 1;
				break;
			case 1:
				this.romSelectionReg0 = value >> 4 & 1;
				if (this.nes.rom.vromCount > 0) {
					if (this.vromSwitchingSize === 0) {
						if (this.romSelectionReg0 === 0) this.load8kVromBank(value & 15, 0);
						else this.load8kVromBank(Math.floor(this.nes.rom.vromCount / 2) + (value & 15), 0);
					} else if (this.romSelectionReg0 === 0) this.loadVromBank(value & 15, 0);
					else this.loadVromBank(Math.floor(this.nes.rom.vromCount / 2) + (value & 15), 0);
				}
				break;
			case 2:
				this.romSelectionReg1 = value >> 4 & 1;
				if (this.nes.rom.vromCount > 0) {
					if (this.vromSwitchingSize === 1) {
						if (this.romSelectionReg1 === 0) this.loadVromBank(value & 15, 4096);
						else this.loadVromBank(Math.floor(this.nes.rom.vromCount / 2) + (value & 15), 4096);
					}
				}
				break;
			default: {
				let bank;
				let baseBank = 0;
				if (this.nes.rom.romCount >= 32) {
					if (this.vromSwitchingSize === 0) {
						if (this.romSelectionReg0 === 1) baseBank = 16;
					} else baseBank = (this.romSelectionReg0 | this.romSelectionReg1 << 1) << 3;
				} else if (this.nes.rom.romCount >= 16) {
					if (this.romSelectionReg0 === 1) baseBank = 8;
				}
				if (this.prgSwitchingSize === 0) {
					bank = baseBank + (value & 15);
					this.load32kRomBank(bank, 32768);
				} else {
					bank = baseBank * 2 + (value & 15);
					if (this.prgSwitchingArea === 0) this.loadRomBank(bank, 49152);
					else this.loadRomBank(bank, 32768);
				}
			}
		}
	}
	getRegNumber(address) {
		if (address >= 32768 && address <= 40959) return 0;
		else if (address >= 40960 && address <= 49151) return 1;
		else if (address >= 49152 && address <= 57343) return 2;
		else return 3;
	}
	loadROM() {
		if (!this.nes.rom.valid) throw new Error("MMC1: Invalid ROM! Unable to load.");
		this.loadRomBank(0, 32768);
		this.loadRomBank(this.nes.rom.romCount - 1, 49152);
		this.loadCHRROM();
		this.loadBatteryRam();
		this.nes.cpu.requestIrq(this.nes.cpu.IRQ_RESET);
	}
	switchLowHighPrgRom(oldSetting) {}
	switch16to32() {}
	switch32to16() {}
	toJSON() {
		let s = super.toJSON();
		s.mirroring = this.mirroring;
		s.oneScreenMirroring = this.oneScreenMirroring;
		s.prgSwitchingArea = this.prgSwitchingArea;
		s.prgSwitchingSize = this.prgSwitchingSize;
		s.vromSwitchingSize = this.vromSwitchingSize;
		s.romSelectionReg0 = this.romSelectionReg0;
		s.romSelectionReg1 = this.romSelectionReg1;
		s.romBankSelect = this.romBankSelect;
		s.regBuffer = this.regBuffer;
		s.regBufferCounter = this.regBufferCounter;
		return s;
	}
	fromJSON(s) {
		super.fromJSON(s);
		this.mirroring = s.mirroring;
		this.oneScreenMirroring = s.oneScreenMirroring;
		this.prgSwitchingArea = s.prgSwitchingArea;
		this.prgSwitchingSize = s.prgSwitchingSize;
		this.vromSwitchingSize = s.vromSwitchingSize;
		this.romSelectionReg0 = s.romSelectionReg0;
		this.romSelectionReg1 = s.romSelectionReg1;
		this.romBankSelect = s.romBankSelect;
		this.regBuffer = s.regBuffer;
		this.regBufferCounter = s.regBufferCounter;
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper2.js
var Mapper2 = class extends Mapper0 {
	static mapperName = "UxROM";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		} else this.loadRomBank(value, 32768);
	}
	loadROM() {
		if (!this.nes.rom.valid) throw new Error("UNROM: Invalid ROM! Unable to load.");
		this.loadRomBank(0, 32768);
		this.loadRomBank(this.nes.rom.romCount - 1, 49152);
		this.loadCHRROM();
		this.nes.cpu.requestIrq(this.nes.cpu.IRQ_RESET);
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper3.js
var Mapper3 = class extends Mapper0 {
	static mapperName = "CNROM";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		} else this.load8kVromBank(value * 2, 0);
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper4.js
var Mapper4 = class Mapper4 extends Mapper0 {
	static mapperName = "MMC3";
	static CMD_SEL_2_1K_VROM_0000 = 0;
	static CMD_SEL_2_1K_VROM_0800 = 1;
	static CMD_SEL_1K_VROM_1000 = 2;
	static CMD_SEL_1K_VROM_1400 = 3;
	static CMD_SEL_1K_VROM_1800 = 4;
	static CMD_SEL_1K_VROM_1C00 = 5;
	static CMD_SEL_ROM_PAGE1 = 6;
	static CMD_SEL_ROM_PAGE2 = 7;
	constructor(nes) {
		super(nes);
		this.command = 0;
		this.prgAddressSelect = 0;
		this.chrAddressSelect = 0;
		this.pageNumber = 0;
		this.irqCounter = 0;
		this.irqLatchValue = 0;
		this.irqEnable = 0;
		this.prgAddressChanged = false;
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		}
		switch (address & 57345) {
			case 32768: {
				this.command = value & 7;
				const tmp = value >> 6 & 1;
				if (tmp !== this.prgAddressSelect) this.prgAddressChanged = true;
				this.prgAddressSelect = tmp;
				this.chrAddressSelect = value >> 7 & 1;
				break;
			}
			case 32769:
				this.executeCommand(this.command, value);
				break;
			case 40960:
				if ((value & 1) !== 0) this.nes.ppu.setMirroring(this.nes.rom.HORIZONTAL_MIRRORING);
				else this.nes.ppu.setMirroring(this.nes.rom.VERTICAL_MIRRORING);
				break;
			case 40961: break;
			case 49152:
				this.irqCounter = value;
				break;
			case 49153:
				this.irqLatchValue = value;
				break;
			case 57344:
				this.irqEnable = 0;
				this.nes.cpu.clearIrq();
				break;
			case 57345: this.irqEnable = 1;
		}
	}
	executeCommand(cmd, arg) {
		switch (cmd) {
			case Mapper4.CMD_SEL_2_1K_VROM_0000:
				if (this.chrAddressSelect === 0) {
					this.load1kVromBank(arg, 0);
					this.load1kVromBank(arg + 1, 1024);
				} else {
					this.load1kVromBank(arg, 4096);
					this.load1kVromBank(arg + 1, 5120);
				}
				break;
			case Mapper4.CMD_SEL_2_1K_VROM_0800:
				if (this.chrAddressSelect === 0) {
					this.load1kVromBank(arg, 2048);
					this.load1kVromBank(arg + 1, 3072);
				} else {
					this.load1kVromBank(arg, 6144);
					this.load1kVromBank(arg + 1, 7168);
				}
				break;
			case Mapper4.CMD_SEL_1K_VROM_1000:
				if (this.chrAddressSelect === 0) this.load1kVromBank(arg, 4096);
				else this.load1kVromBank(arg, 0);
				break;
			case Mapper4.CMD_SEL_1K_VROM_1400:
				if (this.chrAddressSelect === 0) this.load1kVromBank(arg, 5120);
				else this.load1kVromBank(arg, 1024);
				break;
			case Mapper4.CMD_SEL_1K_VROM_1800:
				if (this.chrAddressSelect === 0) this.load1kVromBank(arg, 6144);
				else this.load1kVromBank(arg, 2048);
				break;
			case Mapper4.CMD_SEL_1K_VROM_1C00:
				if (this.chrAddressSelect === 0) this.load1kVromBank(arg, 7168);
				else this.load1kVromBank(arg, 3072);
				break;
			case Mapper4.CMD_SEL_ROM_PAGE1:
				if (this.prgAddressChanged) {
					if (this.prgAddressSelect === 0) this.load8kRomBank((this.nes.rom.romCount - 1) * 2, 49152);
					else this.load8kRomBank((this.nes.rom.romCount - 1) * 2, 32768);
					this.prgAddressChanged = false;
				}
				if (this.prgAddressSelect === 0) this.load8kRomBank(arg, 32768);
				else this.load8kRomBank(arg, 49152);
				break;
			case Mapper4.CMD_SEL_ROM_PAGE2:
				this.load8kRomBank(arg, 40960);
				if (this.prgAddressChanged) {
					if (this.prgAddressSelect === 0) this.load8kRomBank((this.nes.rom.romCount - 1) * 2, 49152);
					else this.load8kRomBank((this.nes.rom.romCount - 1) * 2, 32768);
					this.prgAddressChanged = false;
				}
		}
	}
	loadROM() {
		if (!this.nes.rom.valid) throw new Error("MMC3: Invalid ROM! Unable to load.");
		this.load8kRomBank((this.nes.rom.romCount - 1) * 2, 49152);
		this.load8kRomBank((this.nes.rom.romCount - 1) * 2 + 1, 57344);
		this.load8kRomBank(0, 32768);
		this.load8kRomBank(1, 40960);
		this.loadCHRROM();
		this.loadBatteryRam();
		this.nes.cpu.requestIrq(this.nes.cpu.IRQ_RESET);
	}
	clockIrqCounter() {
		if (this.irqEnable === 1) {
			this.irqCounter--;
			if (this.irqCounter < 0) {
				this.nes.cpu.requestIrq(this.nes.cpu.IRQ_NORMAL);
				this.irqCounter = this.irqLatchValue;
			}
		}
	}
	toJSON() {
		let s = super.toJSON();
		s.command = this.command;
		s.prgAddressSelect = this.prgAddressSelect;
		s.chrAddressSelect = this.chrAddressSelect;
		s.pageNumber = this.pageNumber;
		s.irqCounter = this.irqCounter;
		s.irqLatchValue = this.irqLatchValue;
		s.irqEnable = this.irqEnable;
		s.prgAddressChanged = this.prgAddressChanged;
		return s;
	}
	fromJSON(s) {
		super.fromJSON(s);
		this.command = s.command;
		this.prgAddressSelect = s.prgAddressSelect;
		this.chrAddressSelect = s.chrAddressSelect;
		this.pageNumber = s.pageNumber;
		this.irqCounter = s.irqCounter;
		this.irqLatchValue = s.irqLatchValue;
		this.irqEnable = s.irqEnable;
		this.prgAddressChanged = s.prgAddressChanged;
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper5.js
var Mapper5 = class extends Mapper0 {
	static mapperName = "MMC5";
	constructor(nes) {
		super(nes);
		this.irqClockDot = 339;
		this.prgMode = 3;
		this.prgBankReg = /* @__PURE__ */ new Uint8Array(5);
		this.prgBankReg[4] = 255;
		this.prgRam = /* @__PURE__ */ new Uint8Array(65536);
		this.prgRamProtectA = 3;
		this.prgRamProtectB = 3;
		this.chrMode = 3;
		this.chrBankA = /* @__PURE__ */ new Uint16Array(8);
		this.chrBankB = /* @__PURE__ */ new Uint16Array(4);
		this.chrUpperBits = 0;
		this.lastChrWrite = 0;
		this.ntMapping = /* @__PURE__ */ new Uint8Array(4);
		this.exramMode = 0;
		this.exram = /* @__PURE__ */ new Uint8Array(1024);
		this.fillTile = 0;
		this.fillAttr = 0;
		this.irqTarget = 0;
		this.irqEnabled = false;
		this.irqPending = false;
		this.inFrame = false;
		this.irqCounter = 0;
		this.multA = 0;
		this.multB = 0;
		this.splitEnabled = false;
		this.splitRight = false;
		this.splitTile = 0;
		this.splitScroll = 0;
		this.splitPage = 0;
		this.pulse1 = this._initPulse();
		this.pulse2 = this._initPulse();
		this.pcmValue = 0;
		this.pcmReadMode = false;
		this.pcmIrqEnabled = false;
		this.audioEnabled = 0;
		this._chrBankTarget = -1;
	}
	_initPulse() {
		return {
			enabled: false,
			dutyCycle: 0,
			lengthHalt: false,
			constantVolume: false,
			volume: 0,
			timer: 0,
			timerCounter: 0,
			lengthCounter: 0,
			envelopeCounter: 0,
			envelopeDecay: 15,
			envelopeStart: false,
			sequencePos: 0
		};
	}
	load(address) {
		address &= 65535;
		if (address < 20480) return super.load(address);
		if (address === 20501) {
			let val = 0;
			if (this.pulse1.lengthCounter > 0) val |= 1;
			if (this.pulse2.lengthCounter > 0) val |= 2;
			return val;
		}
		if (address === 20496) return 0;
		if (address >= 20736 && address <= 20740) return this.nes.cpu.dataBus;
		if (address === 20741) return this.nes.cpu.dataBus;
		if (address === 20996) {
			let ppu = this.nes.ppu;
			if (!(ppu.scanline >= 20 && ppu.scanline <= 260 && (ppu.f_bgVisibility === 1 || ppu.f_spVisibility === 1))) this.inFrame = false;
			let val = 0;
			if (this.irqPending) val |= 128;
			if (this.inFrame) val |= 64;
			this.irqPending = false;
			this.nes.cpu.clearIrq();
			return val;
		}
		if (address === 20997) return this.multA * this.multB & 255;
		if (address === 20998) return this.multA * this.multB >> 8 & 255;
		if (address >= 23552 && address <= 24575) {
			if (this.exramMode >= 2) return this.exram[address - 23552];
			return this.nes.cpu.dataBus;
		}
		if (address < 24576) return this.nes.cpu.dataBus;
		if (address < 32768) {
			let offset = (this.prgBankReg[0] & 7) * 8192 + (address - 24576);
			return this.prgRam[offset & 65535];
		}
		return this._readPrg(address);
	}
	_readPrg(address) {
		let slot, reg, isRam, bank, base;
		switch (this.prgMode) {
			case 0:
				reg = this.prgBankReg[4];
				bank = (reg & 124) >> 2;
				return this._readPrgRom32k(bank, address - 32768);
			case 1: if (address < 49152) {
				reg = this.prgBankReg[2];
				isRam = (reg & 128) === 0;
				if (isRam) {
					bank = (reg & 6) >> 1;
					return this.prgRam[bank * 16384 + (address - 32768)];
				}
				bank = (reg & 126) >> 1;
				return this._readPrgRom16k(bank, address - 32768);
			} else {
				reg = this.prgBankReg[4];
				bank = (reg & 126) >> 1;
				return this._readPrgRom16k(bank, address - 49152);
			}
			case 2: if (address < 49152) {
				reg = this.prgBankReg[2];
				isRam = (reg & 128) === 0;
				if (isRam) {
					bank = (reg & 6) >> 1;
					return this.prgRam[bank * 16384 + (address - 32768)];
				}
				bank = (reg & 126) >> 1;
				return this._readPrgRom16k(bank, address - 32768);
			} else if (address < 57344) {
				reg = this.prgBankReg[3];
				isRam = (reg & 128) === 0;
				if (isRam) {
					bank = reg & 7;
					return this.prgRam[bank * 8192 + (address - 49152)];
				}
				bank = reg & 127;
				return this._readPrgRom8k(bank, address - 49152);
			} else {
				reg = this.prgBankReg[4];
				bank = reg & 127;
				return this._readPrgRom8k(bank, address - 57344);
			}
			default:
				if (address < 40960) slot = 1;
				else if (address < 49152) slot = 2;
				else if (address < 57344) slot = 3;
				else slot = 4;
				reg = this.prgBankReg[slot];
				base = slot === 1 ? 32768 : slot === 2 ? 40960 : slot === 3 ? 49152 : 57344;
				if (slot < 4 && (reg & 128) === 0) {
					bank = reg & 7;
					return this.prgRam[bank * 8192 + (address - base)];
				}
				bank = reg & 127;
				return this._readPrgRom8k(bank, address - base);
		}
	}
	_readPrgRom32k(bank32k, offset) {
		let bank16k = (bank32k * 2 + Math.floor(offset / 16384)) % this.nes.rom.romCount;
		let innerOffset = offset % 16384;
		return this.nes.rom.rom[bank16k][innerOffset];
	}
	_readPrgRom16k(bank16k, offset) {
		bank16k %= this.nes.rom.romCount;
		return this.nes.rom.rom[bank16k][offset];
	}
	_readPrgRom8k(bank8k, offset) {
		let bank16k = Math.floor(bank8k / 2) % this.nes.rom.romCount;
		let innerOffset = bank8k % 2 * 8192 + offset;
		if (bank16k < this.nes.rom.romCount) return this.nes.rom.rom[bank16k][innerOffset];
		return 0;
	}
	write(address, value) {
		if (address < 20480) {
			super.write(address, value);
			return;
		}
		if (address >= 20480 && address <= 20483) {
			this._writePulse(this.pulse1, address - 20480, value);
			return;
		}
		if (address >= 20484 && address <= 20487) {
			this._writePulse(this.pulse2, address - 20484, value);
			return;
		}
		if (address === 20496) {
			this.pcmReadMode = (value & 1) !== 0;
			this.pcmIrqEnabled = (value & 128) !== 0;
			return;
		}
		if (address === 20497) {
			if (!this.pcmReadMode && value !== 0) this.pcmValue = value;
			return;
		}
		if (address === 20501) {
			this.audioEnabled = value & 3;
			this.pulse1.enabled = (value & 1) !== 0;
			this.pulse2.enabled = (value & 2) !== 0;
			if (!this.pulse1.enabled) this.pulse1.lengthCounter = 0;
			if (!this.pulse2.enabled) this.pulse2.lengthCounter = 0;
			return;
		}
		if (address === 20736) {
			this.prgMode = value & 3;
			this._syncPrg();
			return;
		}
		if (address === 20737) {
			this.chrMode = value & 3;
			this._syncChr();
			return;
		}
		if (address === 20738) {
			this.prgRamProtectA = value & 3;
			return;
		}
		if (address === 20739) {
			this.prgRamProtectB = value & 3;
			return;
		}
		if (address === 20740) {
			this.exramMode = value & 3;
			this.bgTileOverride = this.exramMode === 1;
			this._syncNametables();
			return;
		}
		if (address === 20741) {
			let v = value;
			this.ntMapping[0] = v & 3;
			v >>= 2;
			this.ntMapping[1] = v & 3;
			v >>= 2;
			this.ntMapping[2] = v & 3;
			v >>= 2;
			this.ntMapping[3] = v & 3;
			this._syncNametables();
			return;
		}
		if (address === 20742) {
			this.fillTile = value;
			this._syncNametables();
			return;
		}
		if (address === 20743) {
			this.fillAttr = value & 3;
			this._syncNametables();
			return;
		}
		if (address === 20755) {
			this.prgBankReg[0] = value & 7;
			return;
		}
		if (address >= 20756 && address <= 20759) {
			let idx = address - 20755;
			this.prgBankReg[idx] = value;
			this._syncPrg();
			return;
		}
		if (address >= 20768 && address <= 20775) {
			let reg = address - 20768;
			this.chrBankA[reg] = this.chrUpperBits << 8 | value;
			this.lastChrWrite = 0;
			this._syncChr();
			return;
		}
		if (address >= 20776 && address <= 20779) {
			let reg = address - 20776;
			this.chrBankB[reg] = this.chrUpperBits << 8 | value;
			this.lastChrWrite = 1;
			this._syncChr();
			return;
		}
		if (address === 20784) {
			this.chrUpperBits = value & 3;
			return;
		}
		if (address === 20992) {
			this.splitEnabled = (value & 128) !== 0;
			this.splitRight = (value & 64) !== 0;
			this.splitTile = value & 31;
			return;
		}
		if (address === 20993) {
			this.splitScroll = value;
			return;
		}
		if (address === 20994) {
			this.splitPage = value & 63;
			return;
		}
		if (address === 20995) {
			this.irqTarget = value;
			return;
		}
		if (address === 20996) {
			this.irqEnabled = (value & 128) !== 0;
			if (this.irqEnabled && this.irqPending) this.nes.cpu.requestIrq(this.nes.cpu.IRQ_NORMAL);
			else if (!this.irqEnabled) this.nes.cpu.clearIrq();
			return;
		}
		if (address === 20997) {
			this.multA = value;
			return;
		}
		if (address === 20998) {
			this.multB = value;
			return;
		}
		if (address >= 23552 && address <= 24575) {
			let exAddr = address - 23552;
			if (this.exramMode === 0 || this.exramMode === 1) {
				this.exram[exAddr] = this.inFrame ? value : 0;
				this._syncExramToVram(exAddr);
			} else if (this.exramMode === 2) this.exram[exAddr] = value;
			return;
		}
		if (address >= 24576 && address <= 32767) {
			if (this.prgRamProtectA === 2 && this.prgRamProtectB === 1) {
				let offset = (this.prgBankReg[0] & 7) * 8192 + (address - 24576);
				this.prgRam[offset & 65535] = value;
				this.nes.cpu.mem[address] = value;
				this.nes.opts.onBatteryRamWrite(address, value);
			}
			return;
		}
		if (address >= 32768) {
			this._writePrg(address, value);
			return;
		}
	}
	_writePrg(address, value) {
		let slot, reg, isRam, bank, base;
		switch (this.prgMode) {
			case 0: return;
			case 1:
				if (address < 49152) {
					reg = this.prgBankReg[2];
					isRam = (reg & 128) === 0;
					if (isRam && this._isPrgRamWritable()) {
						bank = (reg & 6) >> 1;
						this.prgRam[bank * 16384 + (address - 32768)] = value;
					}
				}
				return;
			case 2:
				if (address < 49152) {
					reg = this.prgBankReg[2];
					isRam = (reg & 128) === 0;
					if (isRam && this._isPrgRamWritable()) {
						bank = (reg & 6) >> 1;
						this.prgRam[bank * 16384 + (address - 32768)] = value;
					}
				} else if (address < 57344) {
					reg = this.prgBankReg[3];
					isRam = (reg & 128) === 0;
					if (isRam && this._isPrgRamWritable()) {
						bank = reg & 7;
						this.prgRam[bank * 8192 + (address - 49152)] = value;
					}
				}
				return;
			default:
				if (address < 40960) {
					slot = 1;
					base = 32768;
				} else if (address < 49152) {
					slot = 2;
					base = 40960;
				} else if (address < 57344) {
					slot = 3;
					base = 49152;
				} else return;
				reg = this.prgBankReg[slot];
				isRam = (reg & 128) === 0;
				if (isRam && this._isPrgRamWritable()) {
					bank = reg & 7;
					this.prgRam[bank * 8192 + (address - base)] = value;
				}
				return;
		}
	}
	_isPrgRamWritable() {
		return this.prgRamProtectA === 2 && this.prgRamProtectB === 1;
	}
	_syncPrg() {
		switch (this.prgMode) {
			case 0: {
				let bank = (this.prgBankReg[4] & 124) >> 2;
				this.load32kRomBank(bank, 32768);
				break;
			}
			case 1: {
				let regLo = this.prgBankReg[2];
				if (regLo & 128) {
					let bank16k = (regLo & 126) >> 1;
					this.loadRomBank(bank16k % this.nes.rom.romCount, 32768);
				}
				let bank16kHi = (this.prgBankReg[4] & 126) >> 1;
				this.loadRomBank(bank16kHi % this.nes.rom.romCount, 49152);
				break;
			}
			case 2: {
				let regA = this.prgBankReg[2];
				if (regA & 128) {
					let bank16k = (regA & 126) >> 1;
					this.loadRomBank(bank16k % this.nes.rom.romCount, 32768);
				}
				let regB = this.prgBankReg[3];
				if (regB & 128) this.load8kRomBank(regB & 127, 49152);
				let regC = this.prgBankReg[4];
				this.load8kRomBank(regC & 127, 57344);
				break;
			}
			default: for (let i = 1; i <= 4; i++) {
				let reg = this.prgBankReg[i];
				let addr = 24576 + i * 8192;
				if (i === 4 || reg & 128) this.load8kRomBank(reg & 127, addr);
			}
		}
	}
	_syncChr() {
		this.nes.ppu.triggerRendering();
		this._chrBankTarget = -1;
		if (this.nes.ppu.f_spriteSize === 0) {
			this._applyChrSetA();
			this._chrBankTarget = 0;
		}
	}
	_applyChrSetA() {
		if (this.nes.rom.vromCount === 0) return;
		switch (this.chrMode) {
			case 0:
				this.load8kVromBank((this.chrBankA[7] & 255) * 2, 0);
				break;
			case 1:
				this.loadVromBank(this.chrBankA[3] & 255, 0);
				this.loadVromBank(this.chrBankA[7] & 255, 4096);
				break;
			case 2:
				this.load2kVromBank(this.chrBankA[1] & 511, 0);
				this.load2kVromBank(this.chrBankA[3] & 511, 2048);
				this.load2kVromBank(this.chrBankA[5] & 511, 4096);
				this.load2kVromBank(this.chrBankA[7] & 511, 6144);
				break;
			default: for (let i = 0; i < 8; i++) this.load1kVromBank(this.chrBankA[i] & 1023, i * 1024);
		}
	}
	_applyChrSetB() {
		if (this.nes.rom.vromCount === 0) return;
		switch (this.chrMode) {
			case 0:
				this.load8kVromBank((this.chrBankB[3] & 255) * 2, 0);
				break;
			case 1:
				this.loadVromBank(this.chrBankB[3] & 255, 0);
				this.loadVromBank(this.chrBankB[3] & 255, 4096);
				break;
			case 2:
				this.load2kVromBank(this.chrBankB[1] & 511, 0);
				this.load2kVromBank(this.chrBankB[3] & 511, 2048);
				this.load2kVromBank(this.chrBankB[1] & 511, 4096);
				this.load2kVromBank(this.chrBankB[3] & 511, 6144);
				break;
			default: for (let i = 0; i < 4; i++) {
				this.load1kVromBank(this.chrBankB[i] & 1023, i * 1024);
				this.load1kVromBank(this.chrBankB[i] & 1023, (i + 4) * 1024);
			}
		}
	}
	_syncNametables() {
		let ppu = this.nes.ppu;
		let fillAttrByte = this.fillAttr | this.fillAttr << 2 | this.fillAttr << 4 | this.fillAttr << 6;
		for (let i = 0; i < 960; i++) ppu.vramMem[11264 + i] = this.fillTile;
		for (let i = 960; i < 1024; i++) ppu.vramMem[11264 + i] = fillAttrByte;
		if (this.exramMode >= 2) for (let i = 0; i < 1024; i++) ppu.vramMem[10240 + i] = 0;
		else copyArrayElements(this.exram, 0, ppu.vramMem, 10240, 1024);
		const sourceBase = [
			8192,
			9216,
			10240,
			11264
		];
		for (let nt = 0; nt < 4; nt++) {
			let logicalBase = 8192 + nt * 1024;
			let physBase = sourceBase[this.ntMapping[nt]];
			ppu.defineMirrorRegion(logicalBase, physBase, 1024);
		}
		ppu.defineMirrorRegion(12288, 8192, 3840);
		for (let nt = 0; nt < 4; nt++) ppu.ntable1[nt] = this.ntMapping[nt];
		this._populateNameTable(2, 10240);
		this._populateNameTable(3, 11264);
	}
	_populateNameTable(ntIndex, vramBase) {
		let ppu = this.nes.ppu;
		let nt = ppu.nameTable[ntIndex];
		for (let i = 0; i < 960; i++) nt.tile[i] = ppu.vramMem[vramBase + i];
		for (let i = 0; i < 64; i++) nt.writeAttrib(i, ppu.vramMem[vramBase + 960 + i]);
	}
	_syncExramToVram(exAddr) {
		if (this.exramMode < 2) {
			let ppu = this.nes.ppu;
			ppu.vramMem[10240 + exAddr] = this.exram[exAddr];
			if (exAddr < 960) ppu.nameTable[2].tile[exAddr] = this.exram[exAddr];
			else if (exAddr < 1024) ppu.nameTable[2].writeAttrib(exAddr - 960, this.exram[exAddr]);
		}
	}
	_writePulse(pulse, reg, value) {
		switch (reg) {
			case 0:
				pulse.dutyCycle = value >> 6 & 3;
				pulse.lengthHalt = (value & 32) !== 0;
				pulse.constantVolume = (value & 16) !== 0;
				pulse.volume = value & 15;
				break;
			case 1: break;
			case 2:
				pulse.timer = pulse.timer & 1792 | value;
				break;
			case 3:
				pulse.timer = pulse.timer & 255 | (value & 7) << 8;
				if (pulse.enabled) pulse.lengthCounter = this.nes.papu.getLengthMax(value);
				pulse.envelopeStart = true;
				pulse.sequencePos = 0;
		}
	}
	clockIrqCounter() {
		if (this.nes.ppu.scanline === 20) {
			this.inFrame = true;
			this.irqCounter = 0;
			return;
		}
		this.irqCounter++;
		if (this.irqTarget !== 0 && this.irqCounter === this.irqTarget) {
			this.irqPending = true;
			if (this.irqEnabled) this.nes.cpu.requestIrq(this.nes.cpu.IRQ_NORMAL);
		}
		if ((this.irqCounter & 3) === 0) {
			this._clockPulseLengthCounter(this.pulse1);
			this._clockPulseLengthCounter(this.pulse2);
		}
	}
	_clockPulseLengthCounter(pulse) {
		if (pulse.enabled && !pulse.lengthHalt && pulse.lengthCounter > 0) pulse.lengthCounter--;
	}
	onBgRender() {
		if (this.nes.ppu.f_spriteSize === 1 && this._chrBankTarget !== 1) {
			this._applyChrSetB();
			this._chrBankTarget = 1;
			this.nes.ppu.validTileData = false;
		}
	}
	onSpriteRender() {
		if (this.nes.ppu.f_spriteSize === 1 && this._chrBankTarget !== 0) {
			this._applyChrSetA();
			this._chrBankTarget = 0;
		}
	}
	getSpritePatternTile(index) {
		if (this.nes.ppu.f_spriteSize !== 1 || this.nes.rom.vromCount === 0) return this.nes.ppu.ptTile[index];
		let vromCount = this.nes.rom.vromCount;
		let vromTile = this.nes.rom.vromTile;
		switch (this.chrMode) {
			case 0: {
				let bank4kStart = (this.chrBankA[7] & 255) * 2;
				let half = index >= 256 ? 1 : 0;
				return vromTile[(bank4kStart + half) % vromCount][index - half * 256];
			}
			case 1: {
				let bank4k;
				if (index < 256) bank4k = (this.chrBankA[3] & 255) % vromCount;
				else bank4k = (this.chrBankA[7] & 255) % vromCount;
				return vromTile[bank4k][index % 256];
			}
			case 2: {
				let regIndex = [
					1,
					3,
					5,
					7
				];
				let slot = index >> 7;
				let tileInSlot = index & 127;
				let bank2k = this.chrBankA[regIndex[slot]] & 511;
				return vromTile[Math.floor(bank2k / 2) % vromCount][(bank2k % 2 << 7) + tileInSlot];
			}
			default: {
				let slot = index >> 6;
				let tileInSlot = index & 63;
				let bank1k = this.chrBankA[slot] & 1023;
				return vromTile[Math.floor(bank1k / 4) % vromCount][(bank1k % 4 << 6) + tileInSlot];
			}
		}
	}
	getBgTileData(baseTile, tileIndex, ht, vt) {
		if (this.exramMode !== 1 || this.nes.rom.vromCount === 0) return null;
		let exAddr = vt * 32 + ht;
		let exByte = this.exram[exAddr];
		let bank4k = (exByte & 63 | this.chrUpperBits << 6) % this.nes.rom.vromCount;
		let tile = this.nes.rom.vromTile[bank4k][tileIndex];
		if (!tile) return null;
		return {
			tile,
			attrib: (exByte >> 6 & 3) << 2
		};
	}
	loadROM() {
		if (!this.nes.rom.valid) throw new Error("MMC5: Invalid ROM! Unable to load.");
		this.prgBankReg[4] = 255;
		this._syncPrg();
		this.loadCHRROM();
		this.loadBatteryRam();
		this._syncNametables();
		this.nes.cpu.requestIrq(this.nes.cpu.IRQ_RESET);
	}
	toJSON() {
		let s = super.toJSON();
		s.prgMode = this.prgMode;
		s.prgBankReg = Array.from(this.prgBankReg);
		s.prgRam = Array.from(this.prgRam);
		s.prgRamProtectA = this.prgRamProtectA;
		s.prgRamProtectB = this.prgRamProtectB;
		s.chrMode = this.chrMode;
		s.chrBankA = Array.from(this.chrBankA);
		s.chrBankB = Array.from(this.chrBankB);
		s.chrUpperBits = this.chrUpperBits;
		s.lastChrWrite = this.lastChrWrite;
		s.ntMapping = Array.from(this.ntMapping);
		s.exramMode = this.exramMode;
		s.exram = Array.from(this.exram);
		s.fillTile = this.fillTile;
		s.fillAttr = this.fillAttr;
		s.irqTarget = this.irqTarget;
		s.irqEnabled = this.irqEnabled;
		s.irqPending = this.irqPending;
		s.inFrame = this.inFrame;
		s.irqCounter = this.irqCounter;
		s.multA = this.multA;
		s.multB = this.multB;
		s.splitEnabled = this.splitEnabled;
		s.splitRight = this.splitRight;
		s.splitTile = this.splitTile;
		s.splitScroll = this.splitScroll;
		s.splitPage = this.splitPage;
		s.pcmValue = this.pcmValue;
		s.pcmReadMode = this.pcmReadMode;
		s.pcmIrqEnabled = this.pcmIrqEnabled;
		s.audioEnabled = this.audioEnabled;
		s.pulse1 = Object.assign({}, this.pulse1);
		s.pulse2 = Object.assign({}, this.pulse2);
		return s;
	}
	fromJSON(s) {
		super.fromJSON(s);
		this.prgMode = s.prgMode;
		this.prgBankReg = new Uint8Array(s.prgBankReg);
		this.prgRam = new Uint8Array(s.prgRam);
		this.prgRamProtectA = s.prgRamProtectA;
		this.prgRamProtectB = s.prgRamProtectB;
		this.chrMode = s.chrMode;
		this.chrBankA = new Uint16Array(s.chrBankA);
		this.chrBankB = new Uint16Array(s.chrBankB);
		this.chrUpperBits = s.chrUpperBits;
		this.lastChrWrite = s.lastChrWrite;
		this.ntMapping = new Uint8Array(s.ntMapping);
		this.exramMode = s.exramMode;
		this.bgTileOverride = this.exramMode === 1;
		this.exram = new Uint8Array(s.exram);
		this.fillTile = s.fillTile;
		this.fillAttr = s.fillAttr;
		this.irqTarget = s.irqTarget;
		this.irqEnabled = s.irqEnabled;
		this.irqPending = s.irqPending;
		this.inFrame = s.inFrame;
		this.irqCounter = s.irqCounter;
		this.multA = s.multA;
		this.multB = s.multB;
		this.splitEnabled = s.splitEnabled;
		this.splitRight = s.splitRight;
		this.splitTile = s.splitTile;
		this.splitScroll = s.splitScroll;
		this.splitPage = s.splitPage;
		this.pcmValue = s.pcmValue;
		this.pcmReadMode = s.pcmReadMode;
		this.pcmIrqEnabled = s.pcmIrqEnabled;
		this.audioEnabled = s.audioEnabled;
		if (s.pulse1) this.pulse1 = Object.assign(this._initPulse(), s.pulse1);
		if (s.pulse2) this.pulse2 = Object.assign(this._initPulse(), s.pulse2);
		this._syncPrg();
		this._syncChr();
		this._syncNametables();
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper7.js
var Mapper7 = class extends Mapper0 {
	static mapperName = "AxROM";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 32768) super.write(address, value);
		else {
			this.load32kRomBank(value & 7, 32768);
			if (value & 16) this.nes.ppu.setMirroring(this.nes.rom.SINGLESCREEN_MIRRORING2);
			else this.nes.ppu.setMirroring(this.nes.rom.SINGLESCREEN_MIRRORING);
		}
	}
	loadROM() {
		if (!this.nes.rom.valid) throw new Error("AOROM: Invalid ROM! Unable to load.");
		this.loadPRGROM();
		this.loadCHRROM();
		this.nes.cpu.requestIrq(this.nes.cpu.IRQ_RESET);
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper9.js
var Mapper9 = class extends Mapper0 {
	static mapperName = "MMC2";
	constructor(nes) {
		super(nes);
		this.prgBank = 0;
		this.chrBankFD0 = 0;
		this.chrBankFE0 = 0;
		this.chrBankFD1 = 0;
		this.chrBankFE1 = 0;
		this.latch0 = 254;
		this.latch1 = 254;
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		}
		switch (address & 61440) {
			case 40960:
				this.prgBank = value & 15;
				this.load8kRomBank(this.prgBank, 32768);
				break;
			case 45056:
				this.chrBankFD0 = value & 31;
				this._updateChr0();
				break;
			case 49152:
				this.chrBankFE0 = value & 31;
				this._updateChr0();
				break;
			case 53248:
				this.chrBankFD1 = value & 31;
				this._updateChr1();
				break;
			case 57344:
				this.chrBankFE1 = value & 31;
				this._updateChr1();
				break;
			case 61440: if (value & 1) this.nes.ppu.setMirroring(this.nes.rom.HORIZONTAL_MIRRORING);
			else this.nes.ppu.setMirroring(this.nes.rom.VERTICAL_MIRRORING);
		}
	}
	_updateChr0() {
		let bank = this.latch0 === 253 ? this.chrBankFD0 : this.chrBankFE0;
		this.loadVromBank(bank, 0);
	}
	_updateChr1() {
		let bank = this.latch1 === 253 ? this.chrBankFD1 : this.chrBankFE1;
		this.loadVromBank(bank, 4096);
	}
	latchAccess(address) {
		if (address === 4056) {
			if (this.latch0 !== 253) {
				this.latch0 = 253;
				this._updateChr0();
			}
		} else if (address === 4072) {
			if (this.latch0 !== 254) {
				this.latch0 = 254;
				this._updateChr0();
			}
		} else if (address >= 8152 && address <= 8159) {
			if (this.latch1 !== 253) {
				this.latch1 = 253;
				this._updateChr1();
			}
		} else if (address >= 8168 && address <= 8175) {
			if (this.latch1 !== 254) {
				this.latch1 = 254;
				this._updateChr1();
			}
		}
	}
	loadROM() {
		if (!this.nes.rom.valid) throw new Error("MMC2: Invalid ROM! Unable to load.");
		this.load8kRomBank(0, 32768);
		let lastBank8k = (this.nes.rom.romCount - 1) * 2 + 1;
		this.load8kRomBank(lastBank8k - 2, 40960);
		this.load8kRomBank(lastBank8k - 1, 49152);
		this.load8kRomBank(lastBank8k, 57344);
		this.loadCHRROM();
		this.loadBatteryRam();
		this.nes.cpu.requestIrq(this.nes.cpu.IRQ_RESET);
	}
	toJSON() {
		let s = super.toJSON();
		s.prgBank = this.prgBank;
		s.chrBankFD0 = this.chrBankFD0;
		s.chrBankFE0 = this.chrBankFE0;
		s.chrBankFD1 = this.chrBankFD1;
		s.chrBankFE1 = this.chrBankFE1;
		s.latch0 = this.latch0;
		s.latch1 = this.latch1;
		return s;
	}
	fromJSON(s) {
		super.fromJSON(s);
		this.prgBank = s.prgBank;
		this.chrBankFD0 = s.chrBankFD0;
		this.chrBankFE0 = s.chrBankFE0;
		this.chrBankFD1 = s.chrBankFD1;
		this.chrBankFE1 = s.chrBankFE1;
		this.latch0 = s.latch0;
		this.latch1 = s.latch1;
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper11.js
var Mapper11 = class extends Mapper0 {
	static mapperName = "Color Dreams";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		} else {
			let prgbank1 = (value & 15) * 2 % this.nes.rom.romCount;
			let prgbank2 = ((value & 15) * 2 + 1) % this.nes.rom.romCount;
			this.loadRomBank(prgbank1, 32768);
			this.loadRomBank(prgbank2, 49152);
			if (this.nes.rom.vromCount > 0) {
				let bank = (value >> 4) * 2 % this.nes.rom.vromCount;
				this.loadVromBank(bank, 0);
				this.loadVromBank(bank + 1, 4096);
			}
		}
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper34.js
var Mapper34 = class extends Mapper0 {
	static mapperName = "BNROM";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		} else this.load32kRomBank(value, 32768);
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper38.js
var Mapper38 = class extends Mapper0 {
	static mapperName = "PCI556";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 28672 || address > 32767) {
			super.write(address, value);
			return;
		} else {
			this.load32kRomBank(value & 3, 32768);
			this.load8kVromBank((value >> 2 & 3) * 2, 0);
		}
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper66.js
var Mapper66 = class extends Mapper0 {
	static mapperName = "GxROM";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		} else {
			this.load32kRomBank(value >> 4 & 3, 32768);
			this.load8kVromBank((value & 3) * 2, 0);
		}
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper71.js
var Mapper71 = class extends Mapper0 {
	static mapperName = "Camerica";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		}
		if (address >= 36864 && address < 40960) {
			if (value & 16) this.nes.ppu.setMirroring(this.nes.rom.SINGLESCREEN_MIRRORING2);
			else this.nes.ppu.setMirroring(this.nes.rom.SINGLESCREEN_MIRRORING);
		} else if (address >= 49152) this.loadRomBank(value & 15, 32768);
	}
	loadROM() {
		if (!this.nes.rom.valid) throw new Error("Mapper 71: Invalid ROM! Unable to load.");
		this.loadRomBank(0, 32768);
		this.loadRomBank(this.nes.rom.romCount - 1, 49152);
		this.loadCHRROM();
		this.nes.cpu.requestIrq(this.nes.cpu.IRQ_RESET);
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper79.js
var Mapper79 = class extends Mapper0 {
	static mapperName = "NINA-03/NINA-06";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if ((address & 57600) === 16640) {
			this.load32kRomBank(value >> 3 & 1, 32768);
			this.load8kVromBank((value & 7) * 2, 0);
		}
		super.write(address, value);
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper94.js
var Mapper94 = class extends Mapper0 {
	static mapperName = "UN1ROM";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		} else this.loadRomBank(value >> 2, 32768);
	}
	loadROM() {
		if (!this.nes.rom.valid) throw new Error("UN1ROM: Invalid ROM! Unable to load.");
		this.loadRomBank(0, 32768);
		this.loadRomBank(this.nes.rom.romCount - 1, 49152);
		this.loadCHRROM();
		this.nes.cpu.requestIrq(this.nes.cpu.IRQ_RESET);
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper118.js
var Mapper118 = class extends Mapper4 {
	static mapperName = "TxSROM";
	constructor(nes) {
		super(nes);
		this.chrRegs = [
			0,
			0,
			0,
			0,
			0,
			0
		];
	}
	write(address, value) {
		if (address === 40960) return;
		super.write(address, value);
		if (address === 32768) this.updateNametableMirroring();
	}
	executeCommand(cmd, arg) {
		if (cmd <= 5) {
			this.chrRegs[cmd] = arg;
			super.executeCommand(cmd, arg & 127);
			this.updateNametableMirroring();
		} else super.executeCommand(cmd, arg);
	}
	updateNametableMirroring() {
		let ppu = this.nes.ppu;
		if (this.chrAddressSelect === 0) {
			let nt01 = this.chrRegs[0] >> 7 & 1;
			let nt23 = this.chrRegs[1] >> 7 & 1;
			ppu.ntable1[0] = nt01;
			ppu.ntable1[1] = nt01;
			ppu.ntable1[2] = nt23;
			ppu.ntable1[3] = nt23;
		} else {
			ppu.ntable1[0] = this.chrRegs[2] >> 7 & 1;
			ppu.ntable1[1] = this.chrRegs[3] >> 7 & 1;
			ppu.ntable1[2] = this.chrRegs[4] >> 7 & 1;
			ppu.ntable1[3] = this.chrRegs[5] >> 7 & 1;
		}
		for (let i = 0; i < 4; i++) {
			let source = 8192 + i * 1024;
			let target = 8192 + ppu.ntable1[i] * 1024;
			ppu.defineMirrorRegion(source, target, 1024);
		}
		ppu.currentMirroring = -1;
	}
	loadROM() {
		super.loadROM();
		this.updateNametableMirroring();
	}
	toJSON() {
		let s = super.toJSON();
		s.chrRegs = this.chrRegs.slice();
		return s;
	}
	fromJSON(s) {
		super.fromJSON(s);
		this.chrRegs = s.chrRegs;
		this.updateNametableMirroring();
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper119.js
var Mapper119 = class extends Mapper4 {
	static mapperName = "TQROM";
	constructor(nes) {
		super(nes);
		this.chrRam = /* @__PURE__ */ new Uint8Array(8192);
		this.chrRamTiles = new Array(8);
		for (let i = 0; i < 8; i++) {
			this.chrRamTiles[i] = new Array(64);
			for (let j = 0; j < 64; j++) this.chrRamTiles[i][j] = new Tile();
		}
		this.chrRamSlots = [
			-1,
			-1,
			-1,
			-1,
			-1,
			-1,
			-1,
			-1
		];
	}
	executeCommand(cmd, arg) {
		switch (cmd) {
			case Mapper4.CMD_SEL_2_1K_VROM_0000: {
				let base = this.chrAddressSelect === 0 ? 0 : 4096;
				if (arg & 64) {
					let bank = arg & 6;
					this.load1kChrRamBank(bank, base);
					this.load1kChrRamBank(bank + 1, base + 1024);
				} else {
					let bank = arg & 63;
					this.saveChrRamSlot(base);
					this.saveChrRamSlot(base + 1024);
					this.chrRamSlots[base >> 10] = -1;
					this.chrRamSlots[(base >> 10) + 1] = -1;
					this.load1kVromBank(bank, base);
					this.load1kVromBank(bank + 1, base + 1024);
				}
				break;
			}
			case Mapper4.CMD_SEL_2_1K_VROM_0800: {
				let base = this.chrAddressSelect === 0 ? 2048 : 6144;
				if (arg & 64) {
					let bank = arg & 6;
					this.load1kChrRamBank(bank, base);
					this.load1kChrRamBank(bank + 1, base + 1024);
				} else {
					let bank = arg & 63;
					this.saveChrRamSlot(base);
					this.saveChrRamSlot(base + 1024);
					this.chrRamSlots[base >> 10] = -1;
					this.chrRamSlots[(base >> 10) + 1] = -1;
					this.load1kVromBank(bank, base);
					this.load1kVromBank(bank + 1, base + 1024);
				}
				break;
			}
			case Mapper4.CMD_SEL_1K_VROM_1000: {
				let base = this.chrAddressSelect === 0 ? 4096 : 0;
				if (arg & 64) this.load1kChrRamBank(arg & 7, base);
				else {
					this.saveChrRamSlot(base);
					this.chrRamSlots[base >> 10] = -1;
					this.load1kVromBank(arg & 63, base);
				}
				break;
			}
			case Mapper4.CMD_SEL_1K_VROM_1400: {
				let base = this.chrAddressSelect === 0 ? 5120 : 1024;
				if (arg & 64) this.load1kChrRamBank(arg & 7, base);
				else {
					this.saveChrRamSlot(base);
					this.chrRamSlots[base >> 10] = -1;
					this.load1kVromBank(arg & 63, base);
				}
				break;
			}
			case Mapper4.CMD_SEL_1K_VROM_1800: {
				let base = this.chrAddressSelect === 0 ? 6144 : 2048;
				if (arg & 64) this.load1kChrRamBank(arg & 7, base);
				else {
					this.saveChrRamSlot(base);
					this.chrRamSlots[base >> 10] = -1;
					this.load1kVromBank(arg & 63, base);
				}
				break;
			}
			case Mapper4.CMD_SEL_1K_VROM_1C00: {
				let base = this.chrAddressSelect === 0 ? 7168 : 3072;
				if (arg & 64) this.load1kChrRamBank(arg & 7, base);
				else {
					this.saveChrRamSlot(base);
					this.chrRamSlots[base >> 10] = -1;
					this.load1kVromBank(arg & 63, base);
				}
				break;
			}
			default: super.executeCommand(cmd, arg);
		}
	}
	saveChrRamSlot(address) {
		let slot = address >> 10;
		let bank = this.chrRamSlots[slot];
		if (bank === -1) return;
		copyArrayElements(this.nes.ppu.vramMem, slot << 10, this.chrRam, bank * 1024, 1024);
	}
	load1kChrRamBank(bank, address) {
		this.nes.ppu.triggerRendering();
		bank &= 7;
		this.saveChrRamSlot(address);
		let slot = address >> 10;
		this.chrRamSlots[slot] = bank;
		let srcOffset = bank * 1024;
		copyArrayElements(this.chrRam, srcOffset, this.nes.ppu.vramMem, address, 1024);
		this.rebuildChrRamTiles(bank);
		let baseIndex = address >> 4;
		for (let i = 0; i < 64; i++) this.nes.ppu.ptTile[baseIndex + i] = this.chrRamTiles[bank][i];
	}
	rebuildChrRamTiles(bank) {
		let base = bank * 1024;
		for (let i = 0; i < 1024; i++) {
			let tileIndex = i >> 4;
			let leftOver = i % 16;
			if (leftOver < 8) this.chrRamTiles[bank][tileIndex].setScanline(leftOver, this.chrRam[base + i], this.chrRam[base + i + 8]);
			else this.chrRamTiles[bank][tileIndex].setScanline(leftOver - 8, this.chrRam[base + i - 8], this.chrRam[base + i]);
		}
	}
	canWriteChr(address) {
		if (address >= 8192) return false;
		return this.chrRamSlots[address >> 10] !== -1;
	}
	toJSON() {
		for (let slot = 0; slot < 8; slot++) this.saveChrRamSlot(slot << 10);
		let s = super.toJSON();
		s.chrRam = Array.from(this.chrRam);
		s.chrRamSlots = this.chrRamSlots.slice();
		return s;
	}
	fromJSON(s) {
		super.fromJSON(s);
		this.chrRam = new Uint8Array(s.chrRam);
		this.chrRamSlots = s.chrRamSlots;
		for (let bank = 0; bank < 8; bank++) this.rebuildChrRamTiles(bank);
		for (let slot = 0; slot < 8; slot++) {
			let bank = this.chrRamSlots[slot];
			if (bank !== -1) {
				let baseIndex = slot << 10 >> 4;
				for (let i = 0; i < 64; i++) this.nes.ppu.ptTile[baseIndex + i] = this.chrRamTiles[bank][i];
			}
		}
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper140.js
var Mapper140 = class extends Mapper0 {
	static mapperName = "Jaleco JF-11/JF-14";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 24576 || address > 32767) {
			super.write(address, value);
			return;
		} else {
			this.load32kRomBank(value >> 4 & 3, 32768);
			this.load8kVromBank((value & 15) * 2, 0);
		}
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper180.js
var Mapper180 = class extends Mapper0 {
	static mapperName = "UNROM (Crazy Climber)";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		} else this.loadRomBank(value, 49152);
	}
	loadROM() {
		if (!this.nes.rom.valid) throw new Error("Mapper 180: Invalid ROM! Unable to load.");
		this.loadRomBank(0, 32768);
		this.loadRomBank(0, 49152);
		this.loadCHRROM();
		this.nes.cpu.requestIrq(this.nes.cpu.IRQ_RESET);
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper240.js
var Mapper240 = class extends Mapper0 {
	static mapperName = "Mapper 240";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 16416 || address > 24575) {
			super.write(address, value);
			return;
		} else {
			this.load32kRomBank(value >> 4 & 3, 32768);
			this.load8kVromBank((value & 15) * 2, 0);
		}
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/mapper241.js
var Mapper241 = class extends Mapper0 {
	static mapperName = "BxROM (Mapper 241)";
	constructor(nes) {
		super(nes);
	}
	write(address, value) {
		if (address < 32768) {
			super.write(address, value);
			return;
		} else this.load32kRomBank(value, 32768);
	}
};
//#endregion
//#region node_modules/jsnes/src/mappers/index.js
var mappers_default = {
	0: Mapper0,
	1: Mapper1,
	2: Mapper2,
	3: Mapper3,
	4: Mapper4,
	5: Mapper5,
	7: Mapper7,
	9: Mapper9,
	11: Mapper11,
	34: Mapper34,
	38: Mapper38,
	66: Mapper66,
	71: Mapper71,
	79: Mapper79,
	94: Mapper94,
	118: Mapper118,
	119: Mapper119,
	140: Mapper140,
	180: Mapper180,
	240: Mapper240,
	241: Mapper241
};
//#endregion
//#region node_modules/jsnes/src/rom.js
var ROM = class ROM {
	VERTICAL_MIRRORING = 0;
	HORIZONTAL_MIRRORING = 1;
	FOURSCREEN_MIRRORING = 2;
	SINGLESCREEN_MIRRORING = 3;
	SINGLESCREEN_MIRRORING2 = 4;
	SINGLESCREEN_MIRRORING3 = 5;
	SINGLESCREEN_MIRRORING4 = 6;
	CHRROM_MIRRORING = 7;
	constructor(nes) {
		this.nes = nes;
		this.valid = false;
	}
	load(data) {
		let i, j, v;
		if (data instanceof ArrayBuffer) data = new Uint8Array(data);
		const isTypedArray = ArrayBuffer.isView(data);
		if (isTypedArray) {
			if (data.length < 4 || data[0] !== 78 || data[1] !== 69 || data[2] !== 83 || data[3] !== 26) throw new Error("Not a valid NES ROM.");
		} else if (!data.startsWith("NES")) throw new Error("Not a valid NES ROM.");
		this.header = /* @__PURE__ */ new Uint8Array(16);
		for (i = 0; i < 16; i++) this.header[i] = isTypedArray ? data[i] : data.charCodeAt(i) & 255;
		this.mirroring = (this.header[6] & 1) !== 0 ? 1 : 0;
		this.batteryRam = (this.header[6] & 2) !== 0;
		this.trainer = (this.header[6] & 4) !== 0;
		this.fourScreen = (this.header[6] & 8) !== 0;
		this.isNES2 = (this.header[7] & 12) === 8;
		if (this.isNES2) this._loadNES2Header();
		else this._loadINES1Header();
		this.rom = new Array(this.romCount);
		let offset = 16 + (this.trainer ? 512 : 0);
		for (i = 0; i < this.romCount; i++) {
			this.rom[i] = /* @__PURE__ */ new Uint8Array(16384);
			for (j = 0; j < 16384; j++) {
				if (offset + j >= data.length) break;
				this.rom[i][j] = isTypedArray ? data[offset + j] : data.charCodeAt(offset + j) & 255;
			}
			offset += 16384;
		}
		this.vrom = new Array(this.vromCount);
		for (i = 0; i < this.vromCount; i++) {
			this.vrom[i] = /* @__PURE__ */ new Uint8Array(4096);
			for (j = 0; j < 4096; j++) {
				if (offset + j >= data.length) break;
				this.vrom[i][j] = isTypedArray ? data[offset + j] : data.charCodeAt(offset + j) & 255;
			}
			offset += 4096;
		}
		this.vromTile = new Array(this.vromCount);
		for (i = 0; i < this.vromCount; i++) {
			this.vromTile[i] = new Array(256);
			for (j = 0; j < 256; j++) this.vromTile[i][j] = new Tile();
		}
		let tileIndex;
		let leftOver;
		for (v = 0; v < this.vromCount; v++) for (i = 0; i < 4096; i++) {
			tileIndex = i >> 4;
			leftOver = i % 16;
			if (leftOver < 8) this.vromTile[v][tileIndex].setScanline(leftOver, this.vrom[v][i], this.vrom[v][i + 8]);
			else this.vromTile[v][tileIndex].setScanline(leftOver - 8, this.vrom[v][i - 8], this.vrom[v][i]);
		}
		this.valid = true;
	}
	_loadINES1Header() {
		this.romCount = this.header[4];
		this.vromCount = this.header[5] * 2;
		this.mapperType = this.header[6] >> 4 | this.header[7] & 240;
		let foundError = false;
		for (let i = 8; i < 16; i++) if (this.header[i] !== 0) {
			foundError = true;
			break;
		}
		if (foundError) this.mapperType &= 15;
		this.subMapper = 0;
		this.prgRamSize = 0;
		this.prgNvRamSize = 0;
		this.chrRamSize = 0;
		this.chrNvRamSize = 0;
		this.timingMode = 0;
		this.consoleType = 0;
	}
	_loadNES2Header() {
		this.mapperType = this.header[6] >> 4 | this.header[7] & 240 | (this.header[8] & 15) << 8;
		this.subMapper = this.header[8] >> 4 & 15;
		const prgMsb = this.header[9] & 15;
		if (prgMsb === 15) {
			const e = this.header[4] >> 2 & 63;
			const m = this.header[4] & 3;
			this.romCount = Math.ceil(Math.pow(2, e) * (m * 2 + 1) / 16384);
		} else this.romCount = prgMsb << 8 | this.header[4];
		const chrMsb = this.header[9] >> 4 & 15;
		if (chrMsb === 15) {
			const e = this.header[5] >> 2 & 63;
			const m = this.header[5] & 3;
			this.vromCount = Math.ceil(Math.pow(2, e) * (m * 2 + 1) / 4096);
		} else this.vromCount = (chrMsb << 8 | this.header[5]) * 2;
		this.prgRamSize = ROM._decodeRamSize(this.header[10] & 15);
		this.prgNvRamSize = ROM._decodeRamSize(this.header[10] >> 4 & 15);
		this.chrRamSize = ROM._decodeRamSize(this.header[11] & 15);
		this.chrNvRamSize = ROM._decodeRamSize(this.header[11] >> 4 & 15);
		this.timingMode = this.header[12] & 3;
		this.consoleType = this.header[7] & 3;
	}
	static _decodeRamSize(value) {
		if (value === 0) return 0;
		return 64 << value;
	}
	getMirroringType() {
		if (this.fourScreen) return this.FOURSCREEN_MIRRORING;
		if (this.mirroring === 0) return this.HORIZONTAL_MIRRORING;
		return this.VERTICAL_MIRRORING;
	}
	mapperSupported() {
		return typeof mappers_default[this.mapperType] !== "undefined";
	}
	createMapper() {
		if (this.mapperSupported()) return new mappers_default[this.mapperType](this.nes);
		else throw new Error(`Unsupported mapper: ${this.mapperType}`);
	}
};
//#endregion
//#region node_modules/jsnes/src/nes.js
var SAVE_STATE_VERSION = 2;
var NES = class {
	constructor(opts) {
		this.opts = {
			onFrame: function() {},
			onAudioSample: null,
			onStatusUpdate: function() {},
			onBatteryRamWrite: function() {},
			emulateSound: true,
			sampleRate: 48e3,
			...opts
		};
		this.ui = {
			writeFrame: this.opts.onFrame,
			updateStatus: this.opts.onStatusUpdate
		};
		this.cpu = new CPU(this);
		this.ppu = new PPU(this);
		this.papu = new PAPU(this);
		this.cpu.ppu = this.ppu;
		this.cpu.papu = this.papu;
		this.gameGenie = new GameGenie();
		this.gameGenie.onChange = () => this.cpu._updateCartridgeLoader();
		this.mmap = null;
		this.controllers = {
			1: new Controller(),
			2: new Controller()
		};
		this.fpsFrameCount = 0;
		this.romData = null;
		this.ui.updateStatus("Ready to load a ROM.");
	}
	reset() {
		this.cpu = new CPU(this);
		this.ppu = new PPU(this);
		this.papu = new PAPU(this);
		this.cpu.ppu = this.ppu;
		this.cpu.papu = this.papu;
		if (this.mmap !== null) this.mmap = this.rom.createMapper();
		this.lastFpsTime = null;
		this.fpsFrameCount = 0;
		this.crashed = false;
	}
	frame = () => {
		if (this.crashed) throw new Error("Game has crashed. Call reset() or loadROM() to restart.");
		this.controllers[1].clock();
		this.controllers[2].clock();
		this.ppu.startFrame();
		const cpu = this.cpu;
		const ppu = this.ppu;
		try {
			if (this.mmap === null) return;
			while (!ppu.frameEnded) cpu.emulate();
			ppu.frameEnded = false;
		} catch (e) {
			this.crashed = true;
			throw e;
		}
		this.fpsFrameCount++;
	};
	buttonDown = (controller, button) => {
		this.controllers[controller].buttonDown(button);
	};
	buttonUp = (controller, button) => {
		this.controllers[controller].buttonUp(button);
	};
	zapperMove = (x, y) => {
		if (!this.mmap) return;
		this.mmap.zapperX = x;
		this.mmap.zapperY = y;
	};
	zapperFireDown = () => {
		if (!this.mmap) return;
		this.mmap.zapperFired = true;
	};
	zapperFireUp = () => {
		if (!this.mmap) return;
		this.mmap.zapperFired = false;
	};
	getFPS() {
		const now = Date.now();
		let fps = null;
		if (this.lastFpsTime) fps = this.fpsFrameCount / ((now - this.lastFpsTime) / 1e3);
		this.fpsFrameCount = 0;
		this.lastFpsTime = now;
		return fps;
	}
	reloadROM() {
		if (this.romData !== null) this.loadROM(this.romData);
	}
	loadROM(data) {
		this.rom = new ROM(this);
		this.rom.load(data);
		this.reset();
		this.mmap = this.rom.createMapper();
		this.mmap.loadROM();
		this.cpu._updatePrgReadPath();
		this.ppu.setMirroring(this.rom.getMirroringType());
		this.romData = data;
	}
	setFramerate(rate) {
		this.papu.setFrameRate(rate);
	}
	toJSON() {
		return {
			version: SAVE_STATE_VERSION,
			cpu: this.cpu.toJSON(),
			mmap: this.mmap.toJSON(),
			ppu: this.ppu.toJSON(),
			papu: this.papu.toJSON(),
			controllers: {
				1: this.controllers[1].toJSON(),
				2: this.controllers[2].toJSON()
			}
		};
	}
	fromJSON(s) {
		if (s.version !== SAVE_STATE_VERSION) throw new Error("This save state was made with an incompatible version of JSNES.");
		this.reset();
		this.cpu.fromJSON(s.cpu);
		this.mmap.fromJSON(s.mmap);
		this.ppu.fromJSON(s.ppu);
		this.papu.fromJSON(s.papu);
		if (s.controllers) {
			if (s.controllers[1]) this.controllers[1].fromJSON(s.controllers[1]);
			if (s.controllers[2]) this.controllers[2].fromJSON(s.controllers[2]);
		}
	}
};
try {
	localStorage.getItem("jsnes_debug");
} catch {}
Controller.BUTTON_A, Controller.BUTTON_B, Controller.BUTTON_B, Controller.BUTTON_SELECT, Controller.BUTTON_START, Controller.BUTTON_UP, Controller.BUTTON_DOWN, Controller.BUTTON_LEFT, Controller.BUTTON_RIGHT, Controller.BUTTON_TURBO_A, Controller.BUTTON_TURBO_B, Controller.BUTTON_A, Controller.BUTTON_B, Controller.BUTTON_SELECT, Controller.BUTTON_START, Controller.BUTTON_UP, Controller.BUTTON_DOWN, Controller.BUTTON_LEFT, Controller.BUTTON_RIGHT;
try {
	localStorage.getItem("jsnes_debug");
} catch {}
//#endregion
//#region node_modules/jsnes/src/index.js
var src_exports = /* @__PURE__ */ __exportAll({ NES: () => NES });
//#endregion
export { src_exports as t };
