import { useEffect, useState } from "react";
import { CODE_RE, ROOM_KEY, SECRET_RE, type RoomCredentials } from "@/lib/pad-protocol";
import { apiUrl, mandoUrl } from "@/lib/public-url";

export type PeerState = "preparando" | "esperando" | "conectado" | "error";

interface TvRoom {
  code: string | null;
  link: string | null;
  mask: number;
  peer: PeerState;
}

function readSaved(): RoomCredentials | null {
  try {
    const raw = sessionStorage.getItem(ROOM_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<RoomCredentials>;
    if (!parsed.code || !parsed.secret) return null;
    if (!CODE_RE.test(parsed.code) || !SECRET_RE.test(parsed.secret)) return null;
    return { code: parsed.code, secret: parsed.secret };
  } catch {
    return null;
  }
}

async function openRoom(): Promise<RoomCredentials> {
  const response = await fetch(apiUrl("/api/pad"), {
    method: "POST",
    headers: { "content-type": "application/json" },
    cache: "no-store",
    body: JSON.stringify({ op: "open" }),
  });
  if (!response.ok) throw new Error("open failed");
  const body = (await response.json()) as Partial<RoomCredentials>;
  if (!body.code || !body.secret || !CODE_RE.test(body.code) || !SECRET_RE.test(body.secret)) {
    throw new Error("bad room");
  }
  const room = { code: body.code, secret: body.secret };
  sessionStorage.setItem(ROOM_KEY, JSON.stringify(room));
  return room;
}

export function useTvRoom(): TvRoom {
  const [room, setRoom] = useState<RoomCredentials | null>(null);
  const [mask, setMask] = useState(0);
  const [peer, setPeer] = useState<PeerState>("preparando");

  useEffect(() => {
    let stop = false;
    const boot = async () => {
      const saved = readSaved();
      if (saved) {
        const ok = await poll(saved);
        if (stop) return;
        if (ok) {
          setRoom(saved);
          return;
        }
        sessionStorage.removeItem(ROOM_KEY);
      }
      try {
        const opened = await openRoom();
        if (!stop) setRoom(opened);
      } catch {
        if (!stop) setPeer("error");
      }
    };
    void boot();
    return () => {
      stop = true;
    };
  }, []);

  useEffect(() => {
    if (!room) return;
    let stop = false;
    let channelAt = 0;
    let channelMask = 0;
    const channel = new BroadcastChannel(`catodo-${room.code}`);
    channel.onmessage = (event) => {
      const data = event.data as { mask?: unknown };
      if (typeof data?.mask !== "number") return;
      channelMask = data.mask & 255;
      channelAt = performance.now();
    };

    let timer = 0;
    const tick = async () => {
      if (stop) return;
      let serverMask = 0;
      let serverFresh = false;
      try {
        const response = await fetch(apiUrl("/api/pad"), {
          method: "POST",
          headers: { "content-type": "application/json" },
          cache: "no-store",
          body: JSON.stringify({ op: "poll", code: room.code, secret: room.secret }),
        });
        if (response.status === 401) {
          sessionStorage.removeItem(ROOM_KEY);
          const opened = await openRoom();
          if (!stop) setRoom(opened);
          return;
        }
        if (response.ok) {
          const body = (await response.json()) as { mask?: unknown; ageMs?: unknown };
          const age = Number(body.ageMs);
          const buttons = Number(body.mask);
          if (Number.isFinite(age) && Number.isFinite(buttons) && age < 800) {
            serverMask = buttons & 255;
            serverFresh = true;
          }
        }
      } catch {
        if (!stop) setPeer("error");
      }
      const channelFresh = performance.now() - channelAt < 800;
      const next = channelFresh ? channelMask : serverFresh ? serverMask : 0;
      const alive = channelFresh || serverFresh;
      if (!stop) {
        setMask(next);
        setPeer(alive ? "conectado" : "esperando");
      }
      if (!stop) timer = window.setTimeout(tick, 80);
    };
    timer = window.setTimeout(tick, 80);
    return () => {
      stop = true;
      window.clearTimeout(timer);
      channel.close();
    };
  }, [room]);

  return {
    code: room?.code ?? null,
    link: room ? mandoUrl(room.code, room.secret) : null,
    mask,
    peer,
  };
}

async function poll(room: RoomCredentials): Promise<boolean> {
  try {
    const response = await fetch(apiUrl("/api/pad"), {
      method: "POST",
      headers: { "content-type": "application/json" },
      cache: "no-store",
      body: JSON.stringify({ op: "poll", code: room.code, secret: room.secret }),
    });
    return response.ok;
  } catch {
    return false;
  }
}
