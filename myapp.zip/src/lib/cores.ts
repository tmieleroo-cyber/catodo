export type CoreWeight = "ligero" | "medio" | "pesado" | "muy pesado";
export type CoreStatus = "listo" | "previsto";

export interface CoreInfo {
  id: string;
  short: string;
  name: string;
  year: string;
  extensions: string[];
  status: CoreStatus;
  weight: CoreWeight;
  note: string;
}

/**
 * One entry per system. A later core is a new module plus flipping `status`.
 * Nothing here ships a game.
 */
export const CORES: CoreInfo[] = [
  {
    id: "nes",
    short: "NES",
    name: "Nintendo Entertainment System",
    year: "1983",
    extensions: [".nes"],
    status: "listo",
    weight: "ligero",
    note: "Núcleo jsnes (Apache-2.0) dentro de la app. Corre en una Smart TV modesta.",
  },
  {
    id: "gb",
    short: "GB",
    name: "Game Boy y Color",
    year: "1989",
    extensions: [".gb", ".gbc"],
    status: "previsto",
    weight: "ligero",
    note: "Cabe en el televisor. En el APK el núcleo sería Gambatte.",
  },
  {
    id: "sms",
    short: "SMS",
    name: "Master System",
    year: "1985",
    extensions: [".sms"],
    status: "previsto",
    weight: "ligero",
    note: "Muy parecido en peso al NES. Núcleo previsto: SMS Plus.",
  },
  {
    id: "md",
    short: "MD",
    name: "Mega Drive",
    year: "1988",
    extensions: [".md", ".gen"],
    status: "previsto",
    weight: "medio",
    note: "En el APK: Genesis Plus GX. En JavaScript ya se nota el calor del televisor.",
  },
  {
    id: "snes",
    short: "SNES",
    name: "Super Nintendo",
    year: "1990",
    extensions: [".sfc", ".smc"],
    status: "previsto",
    weight: "pesado",
    note: "Muchas TCL se ahogan con SNES en el navegador. En nativo: Snes9x.",
  },
  {
    id: "gba",
    short: "GBA",
    name: "Game Boy Advance",
    year: "2001",
    extensions: [".gba"],
    status: "previsto",
    weight: "pesado",
    note: "Solo teles de gama media o alta, con mGBA nativo. No en esta versión ligera.",
  },
  {
    id: "nds",
    short: "NDS",
    name: "Nintendo DS",
    year: "2004",
    extensions: [".nds"],
    status: "previsto",
    weight: "muy pesado",
    note: "Dos pantallas y mucho procesador. No es realista en una Smart TV básica.",
  },
];

export function coreById(id: string): CoreInfo {
  return CORES.find((core) => core.id === id) ?? CORES[0];
}
