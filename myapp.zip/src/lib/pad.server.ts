/**
 * Phone-pad relay. The TV and the phone share a room.
 * The raw secret is never stored — only SHA-256 — and never logged.
 * Button state is an 8-bit mask. ROM bytes never reach this module.
 */
import { z } from "zod";
import { getSql } from "@/lib/db";
import { CODE_RE, SECRET_RE } from "@/lib/pad-protocol";

const CODE = z.string().regex(CODE_RE);
const SECRET = z.string().regex(SECRET_RE);

const postSchema = z.discriminatedUnion("op", [
  z.object({ op: z.literal("open") }),
  z.object({
    op: z.literal("push"),
    code: CODE,
    secret: SECRET,
    mask: z.number().int().min(0).max(255),
  }),
  z.object({
    op: z.literal("poll"),
    code: CODE,
    secret: SECRET,
  }),
]);

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const ROOM_HOURS = 4;

const globalRef = globalThis as typeof globalThis & {
  __padOpens__?: number[];
  __padPushes__?: Map<string, number[]>;
};

function allowOpen(): boolean {
  const now = Date.now();
  const opens = (globalRef.__padOpens__ ??= []);
  while (opens.length && opens[0] < now - 60_000) opens.shift();
  if (opens.length >= 30) return false;
  opens.push(now);
  return true;
}

function allowPush(code: string): boolean {
  const now = Date.now();
  const book: Map<string, number[]> = (globalRef.__padPushes__ ??= new Map());
  const hits = book.get(code) ?? [];
  const fresh = hits.filter((stamp) => stamp > now - 1000);
  if (fresh.length >= 40) {
    book.set(code, fresh);
    return false;
  }
  fresh.push(now);
  book.set(code, fresh);
  return true;
}

function randomCode(): string {
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  let out = "";
  for (const byte of bytes) out += ALPHABET[byte % ALPHABET.length];
  return out;
}

function randomSecret(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha256Hex(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
      "referrer-policy": "no-referrer",
    },
  });
}

async function prune(): Promise<void> {
  const sql = await getSql();
  await sql.query(
    `DELETE FROM pad_rooms WHERE created_at < now() - make_interval(hours => $1)`,
    [ROOM_HOURS],
  );
}

async function openRoom(): Promise<Response> {
  if (!allowOpen()) return json({ error: "rate" }, 429);
  const sql = await getSql();
  if (Math.random() < 0.2) await prune();
  for (let attempt = 0; attempt < 4; attempt++) {
    const code = randomCode();
    const secret = randomSecret();
    const hash = await sha256Hex(secret);
    try {
      await sql.query(
        `INSERT INTO pad_rooms (code, secret_hash, mask, updated_at)
         VALUES ($1, $2, 0, now() - make_interval(hours => 1))`,
        [code, hash],
      );
      return json({ code, secret });
    } catch {
      // primary-key collision: try another code
    }
  }
  return json({ error: "busy" }, 503);
}

async function authorized(
  code: string,
  secret: string,
): Promise<{ mask: number; ageMs: number } | null> {
  const sql = await getSql();
  const hash = await sha256Hex(secret);
  const rows = await sql.query<{ mask: number | string; age_ms: number | string }>(
    `SELECT mask,
            (EXTRACT(EPOCH FROM (now() - updated_at)) * 1000)::int AS age_ms
     FROM pad_rooms
     WHERE code = $1 AND secret_hash = $2
       AND created_at > now() - make_interval(hours => $3)`,
    [code, hash, ROOM_HOURS],
  );
  const row = rows[0];
  if (!row) return null;
  return { mask: Number(row.mask) & 255, ageMs: Number(row.age_ms) };
}

export async function handlePad(request: Request): Promise<Response> {
  if (request.method !== "POST") return json({ error: "method" }, 405);
  let text: string;
  try {
    text = await request.text();
  } catch {
    return json({ error: "invalid" }, 400);
  }
  if (text.length > 2048) return json({ error: "invalid" }, 413);
  let body: unknown;
  try {
    body = JSON.parse(text);
  } catch {
    return json({ error: "invalid" }, 400);
  }
  const parsed = postSchema.safeParse(body);
  if (!parsed.success) return json({ error: "invalid" }, 400);

  try {
    if (parsed.data.op === "open") return await openRoom();
    if (!allowPush(parsed.data.code)) return json({ error: "rate" }, 429);
    if (parsed.data.op === "push") {
      const sql = await getSql();
      const hash = await sha256Hex(parsed.data.secret);
      const rows = await sql.query<{ code: string }>(
        `UPDATE pad_rooms
         SET mask = $3, updated_at = now()
         WHERE code = $1 AND secret_hash = $2
           AND created_at > now() - make_interval(hours => $4)
         RETURNING code`,
        [parsed.data.code, hash, parsed.data.mask, ROOM_HOURS],
      );
      if (!rows[0]) return json({ error: "unauthorized" }, 401);
      return json({ ok: true });
    }
    const state = await authorized(parsed.data.code, parsed.data.secret);
    if (!state) return json({ error: "unauthorized" }, 401);
    return json(state);
  } catch {
    console.error("[pad] relay failed");
    return json({ error: "failed" }, 500);
  }
}
