const MAX_BYTES = 2 * 1024 * 1024;

export function assertInes(bytes: Uint8Array): void {
  if (bytes.length < 16 || bytes.length > MAX_BYTES) {
    throw new Error("El archivo debe ser un .nes de hasta 2 MB.");
  }
  const headerOk =
    bytes[0] === 0x4e && bytes[1] === 0x45 && bytes[2] === 0x53 && bytes[3] === 0x1a;
  if (!headerOk) {
    throw new Error("No es un ROM de NES: falta la cabecera iNES.");
  }
}

export async function readNesFile(file: File): Promise<Uint8Array> {
  const name = file.name.toLowerCase();
  if (!name.endsWith(".nes")) {
    throw new Error("Solo se aceptan archivos .nes en este núcleo.");
  }
  const bytes = new Uint8Array(await file.arrayBuffer());
  assertInes(bytes);
  return bytes;
}
