import { previewPathPrefix } from "@/lib/preview-path-prefix";

/** Preview hosts serve the app under /hds-…/; the phone must use that public path. */
export function publicPrefix(): string {
  if (typeof window === "undefined") return "";
  return previewPathPrefix(window.location.hostname, window.location.pathname) ?? "";
}

export function apiUrl(path: string): string {
  return `${publicPrefix()}${path}`;
}

export function mandoUrl(code: string, secret: string): string {
  const url = new URL(window.location.origin);
  url.pathname = `${publicPrefix()}/mando`;
  url.searchParams.set("code", code);
  url.hash = `k=${secret}`;
  return url.toString();
}

export function readHashSecret(): string {
  const raw = window.location.hash.replace(/^#/, "");
  return new URLSearchParams(raw).get("k") ?? "";
}
