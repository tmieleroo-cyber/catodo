/** Bit index matches jsnes Controller buttons 0–7. */
export const PAD = {
  A: 0,
  B: 1,
  SELECT: 2,
  START: 3,
  UP: 4,
  DOWN: 5,
  LEFT: 6,
  RIGHT: 7,
} as const;

export const ROOM_KEY = "catodo.room";
export const CODE_RE = /^[A-Z2-9]{8}$/;
export const SECRET_RE = /^[a-f0-9]{32}$/;

export interface RoomCredentials {
  code: string;
  secret: string;
}

export function maskBit(mask: number, bit: number): boolean {
  return (mask & (1 << bit)) !== 0;
}

export function withBit(mask: number, bit: number, down: boolean): number {
  return down ? mask | (1 << bit) : mask & ~(1 << bit);
}

const KEY_BITS: Record<string, number> = {
  ArrowUp: PAD.UP,
  ArrowDown: PAD.DOWN,
  ArrowLeft: PAD.LEFT,
  ArrowRight: PAD.RIGHT,
  KeyX: PAD.A,
  KeyK: PAD.A,
  KeyZ: PAD.B,
  KeyJ: PAD.B,
  Enter: PAD.START,
  ShiftLeft: PAD.SELECT,
  ShiftRight: PAD.SELECT,
};

export function bitForKey(code: string): number | null {
  return KEY_BITS[code] ?? null;
}

/** Standard Gamepad mapping (USB / Bluetooth pads the TV already sees). */
export function gamepadMask(): number {
  const pads = navigator.getGamepads?.();
  if (!pads) return 0;
  let mask = 0;
  for (const pad of pads) {
    if (!pad) continue;
    const pressed = (index: number) => Boolean(pad.buttons[index]?.pressed);
    if (pressed(0)) mask |= 1 << PAD.A;
    if (pressed(1)) mask |= 1 << PAD.B;
    if (pressed(8)) mask |= 1 << PAD.SELECT;
    if (pressed(9)) mask |= 1 << PAD.START;
    const up = pressed(12) || (pad.axes[1] ?? 0) < -0.5;
    const down = pressed(13) || (pad.axes[1] ?? 0) > 0.5;
    const left = pressed(14) || (pad.axes[0] ?? 0) < -0.5;
    const right = pressed(15) || (pad.axes[0] ?? 0) > 0.5;
    if (up) mask |= 1 << PAD.UP;
    if (down) mask |= 1 << PAD.DOWN;
    if (left) mask |= 1 << PAD.LEFT;
    if (right) mask |= 1 << PAD.RIGHT;
  }
  return mask;
}
