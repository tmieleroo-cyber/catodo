declare module "qrcode" {
  interface QrCode {
    toDataURL(text: string, opts?: Record<string, unknown>): Promise<string>;
  }
  const qrcode: QrCode;
  export default qrcode;
}
