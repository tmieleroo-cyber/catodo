import { createFileRoute } from "@tanstack/react-router";
import { handlePad } from "@/lib/pad.server";

const handle = ({ request }: { request: Request }) => handlePad(request);

export const Route = createFileRoute("/api/pad")({
  server: { handlers: { POST: handle } },
});
