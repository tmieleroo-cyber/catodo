import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Shield } from "lucide-react";
import { CORES, type CoreInfo } from "@/lib/cores";
import { demoRomBytes } from "@/lib/demo-rom";
import { withBit } from "@/lib/pad-protocol";
import { readNesFile } from "@/lib/rom";
import { useTvRoom } from "@/lib/use-tv-room";
import { NesScreen } from "@/components/nes-screen";
import { PadFace } from "@/components/pad-face";
import { QrCard } from "@/components/qr-card";

export const Route = createFileRoute("/")({ component: Home });

interface LoadedRom {
  name: string;
  bytes: Uint8Array;
}

function Home() {
  const room = useTvRoom();
  const [loaded, setLoaded] = useState<LoadedRom | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [openCore, setOpenCore] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const loadFile = async (file: File) => {
    try {
      const bytes = await readNesFile(file);
      setNotice(null);
      setLoaded({ name: file.name, bytes });
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "No se pudo leer el archivo.");
    }
  };

  if (loaded) {
    return (
      <PlayStage
        rom={loaded}
        remoteMask={room.mask}
        peer={room.peer}
        onExit={() => setLoaded(null)}
      />
    );
  }

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-5xl flex-col gap-8 px-4 py-6 sm:px-6">
      <header className="flex items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs tracking-[0.22em] text-ember">SMART TV</p>
          <h1 className="mt-1 font-mono text-4xl font-semibold tracking-tight text-fg">CÁTODO</h1>
          <p className="mt-2 max-w-xl text-pretty text-muted">
            Elige un emulador, carga tu archivo desde el USB y juega con el teléfono. Aquí no hay juegos
            incluidos.
          </p>
        </div>
      </header>

      <section
        className="rounded-lg border border-line bg-surface p-4 sm:p-5"
        onDragOver={(event) => event.preventDefault()}
        onDrop={(event) => {
          event.preventDefault();
          const file = event.dataTransfer.files[0];
          if (file) void loadFile(file);
        }}
      >
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="font-mono text-xs tracking-[0.16em] text-ember">LISTO</p>
            <h2 className="mt-1 text-2xl font-semibold text-fg">NES</h2>
            <p className="mt-1 text-sm text-muted">Nintendo Entertainment System · .nes · núcleo ligero</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              className="h-12 rounded-md bg-ember px-4 text-sm font-semibold text-ember-ink"
              onClick={() => {
                setNotice(null);
                setLoaded({ name: "Prueba Cátodo", bytes: demoRomBytes() });
              }}
            >
              Probar el núcleo
            </button>
            <button
              type="button"
              className="h-12 rounded-md border border-line bg-surface-2 px-4 text-sm font-semibold text-fg"
              onClick={() => fileRef.current?.click()}
            >
              Cargar .nes
            </button>
            <input
              ref={fileRef}
              type="file"
              accept=".nes,application/octet-stream"
              className="sr-only"
              onChange={(event) => {
                const file = event.target.files?.[0];
                event.target.value = "";
                if (file) void loadFile(file);
              }}
            />
          </div>
        </div>
        <p className="mt-4 text-sm text-pretty text-muted">
          En el televisor, “Cargar .nes” abre el USB o el almacenamiento. El archivo se lee en el aparato y
          no se envía a internet. La prueba es un cuadrado propio, no un juego comercial: cruceta para
          moverlo, A pinta el fondo.
        </p>
        {notice ? (
          <p role="alert" className="mt-3 text-sm text-ember">
            {notice}
          </p>
        ) : null}
      </section>

      <section>
        <h2 className="font-mono text-xs tracking-[0.16em] text-muted">DESPUÉS, SIN INFLAR LA APP</h2>
        <ul className="mt-3 divide-y divide-line border-y border-line">
          {CORES.filter((core) => core.status !== "listo").map((core) => (
            <CoreRow
              key={core.id}
              core={core}
              open={openCore === core.id}
              onToggle={() => setOpenCore((current) => (current === core.id ? null : core.id))}
            />
          ))}
        </ul>
      </section>

      <div className="grid items-start gap-4 lg:grid-cols-[1.2fr_0.8fr]">
        <QrCard link={room.link} code={room.code} peer={room.peer} />
        <details className="rounded-lg border border-line bg-surface p-4">
          <summary className="flex cursor-pointer items-center gap-2 font-medium text-fg">
            <Shield className="size-4 text-ember" aria-hidden />
            Seguridad de esta versión
          </summary>
          <ul className="mt-3 space-y-2 text-sm text-pretty text-muted">
            <li>El ROM no sale del dispositivo. Esta app no tiene subida de archivos.</li>
            <li>La sala del mando dura 4 horas. En el servidor solo se guarda el hash de la clave.</li>
            <li>La clave viaja en el fragmento del enlace, así no queda en la consulta.</li>
            <li>El mando solo puede enviar una máscara de 8 botones, con un tope de peticiones.</li>
            <li>No certificamos ISO 27001: eso es un sistema de gestión de una organización. Aquí están los controles técnicos que le corresponden a la app.</li>
          </ul>
        </details>
      </div>

      <footer className="pb-6 text-xs text-muted">
        Núcleo NES: jsnes, Apache-2.0. Código QR: qrcode, MIT. Carga solo ROMs que tengas derecho a usar.
      </footer>
    </main>
  );
}

function CoreRow({ core, open, onToggle }: { core: CoreInfo; open: boolean; onToggle: () => void }) {
  return (
    <li>
      <button type="button" onClick={onToggle} className="flex w-full items-center gap-3 py-3 text-left">
        <span className="w-14 shrink-0 font-mono text-sm text-fg">{core.short}</span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-fg">{core.name}</span>
          <span className="block text-sm text-muted">
            {core.extensions.join(" ")} · {core.weight}
          </span>
        </span>
        <span className="shrink-0 text-xs tracking-wide text-muted">{open ? "Cerrar" : "Ver"}</span>
      </button>
      {open ? <p className="pb-3 pl-14 text-sm text-pretty text-muted">{core.note}</p> : null}
    </li>
  );
}

function PlayStage({
  rom,
  remoteMask,
  peer,
  onExit,
}: {
  rom: LoadedRom;
  remoteMask: number;
  peer: string;
  onExit: () => void;
}) {
  const [touchMask, setTouchMask] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const peerLabel =
    peer === "conectado" ? "Teléfono enlazado" : peer === "error" ? "Mando en la nube no disponible" : "Teléfono sin enlazar";

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="flex items-center justify-between gap-3 px-4 py-3">
        <button
          type="button"
          onClick={onExit}
          className="h-11 rounded-md border border-line px-3 text-sm font-medium text-fg"
        >
          Salir
        </button>
        <div className="min-w-0 text-right">
          <p className="truncate text-sm text-fg">{rom.name}</p>
          <p className="text-xs text-muted">{peerLabel}</p>
        </div>
      </header>
      {error ? (
        <p role="alert" className="px-4 text-sm text-ember">
          {error}
        </p>
      ) : null}
      <NesScreen rom={rom.bytes} extraMask={remoteMask | touchMask} onError={setError} />
      <div className="safe-pad mx-auto w-full max-w-xl px-4 pb-4">
        <p className="mb-3 text-center text-sm text-muted">
          Flechas · Z = B · X = A · Enter = Start · Mayús = Select
        </p>
        <PadFace mask={touchMask} onBit={(bit, down) => setTouchMask((current) => withBit(current, bit, down))} />
      </div>
    </div>
  );
}
