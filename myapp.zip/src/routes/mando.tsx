import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { PadFace } from "@/components/pad-face";
import { CODE_RE, SECRET_RE, bitForKey, withBit } from "@/lib/pad-protocol";
import { apiUrl, readHashSecret } from "@/lib/public-url";

export const Route = createFileRoute("/mando")({
  validateSearch: (search: Record<string, unknown>) => ({
    code: typeof search.code === "string" ? search.code.toUpperCase().slice(0, 8) : "",
  }),
  component: MandoPage,
});

type LinkState = "leyendo" | "incompleto" | "enlazando" | "conectado" | "rechazado" | "error";

function MandoPage() {
  const { code } = Route.useSearch();
  const [secret, setSecret] = useState<string | null>(null);
  const [mask, setMask] = useState(0);
  const [link, setLink] = useState<LinkState>("leyendo");
  const maskRef = useRef(0);
  const sendRef = useRef<(() => void) | null>(null);
  maskRef.current = mask;

  useEffect(() => {
    setSecret(readHashSecret());
  }, []);

  useEffect(() => {
    if (secret === null) return;
    if (!CODE_RE.test(code) || !SECRET_RE.test(secret)) {
      setLink("incompleto");
      return;
    }
    let stop = false;
    const channel = new BroadcastChannel(`catodo-${code}`);
    const send = async () => {
      const buttons = maskRef.current & 255;
      channel.postMessage({ mask: buttons });
      try {
        const response = await fetch(apiUrl("/api/pad"), {
          method: "POST",
          headers: { "content-type": "application/json" },
          cache: "no-store",
          body: JSON.stringify({ op: "push", code, secret, mask: buttons }),
        });
        if (stop) return;
        if (response.status === 401) setLink("rechazado");
        else if (response.ok) setLink("conectado");
        else setLink("error");
      } catch {
        if (!stop) setLink("error");
      }
    };
    setLink("enlazando");
    sendRef.current = () => void send();
    void send();
    const timer = window.setInterval(() => void send(), 200);
    return () => {
      stop = true;
      sendRef.current = null;
      window.clearInterval(timer);
      channel.close();
    };
  }, [code, secret]);

  useEffect(() => {
    sendRef.current?.();
  }, [mask]);

  useEffect(() => {
    const down = (event: KeyboardEvent) => {
      const bit = bitForKey(event.code);
      if (bit === null || event.repeat) return;
      event.preventDefault();
      setMask((current) => withBit(current, bit, true));
    };
    const up = (event: KeyboardEvent) => {
      const bit = bitForKey(event.code);
      if (bit === null) return;
      setMask((current) => withBit(current, bit, false));
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  const ready = secret !== null && CODE_RE.test(code) && SECRET_RE.test(secret);

  return (
    <main className="safe-pad mx-auto flex min-h-dvh w-full max-w-lg flex-col gap-6 px-4 py-5">
      <header>
        <p className="font-mono text-xs tracking-[0.2em] text-ember">CÁTODO</p>
        <h1 className="mt-1 text-3xl font-semibold text-fg">Mando</h1>
        <p className="mt-2 text-sm text-pretty text-muted">{statusCopy(link, code)}</p>
      </header>
      <div className={ready ? "" : "pointer-events-none opacity-40"}>
        <PadFace mask={mask} onBit={(bit, down) => setMask((current) => withBit(current, bit, down))} />
      </div>
    </main>
  );
}

function statusCopy(link: LinkState, code: string): string {
  if (link === "leyendo") return "Leyendo el enlace…";
  if (link === "incompleto")
    return "Escanea otra vez el QR del televisor. Este enlace no trae la clave y no se escribe a mano.";
  if (link === "enlazando") return `Sala ${code}. Enlazando…`;
  if (link === "conectado") return `Sala ${code}. Enlazado. Lo que pulses llega al televisor.`;
  if (link === "rechazado") return "Esta sala ya no vale. En el televisor, vuelve a mostrar el QR.";
  return "No hay enlace con el televisor. Comprueba que ambos siguen abiertos.";
}
