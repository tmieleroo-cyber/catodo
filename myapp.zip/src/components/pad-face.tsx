import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp } from "lucide-react";
import type { ReactNode } from "react";
import { PAD, maskBit } from "@/lib/pad-protocol";

interface PadFaceProps {
  mask: number;
  onBit: (bit: number, down: boolean) => void;
}

export function PadFace({ mask, onBit }: PadFaceProps) {
  const hold = (
    bit: number,
    label: string,
    className: string,
    children: ReactNode,
    emphasize = false,
  ) => {
    const down = maskBit(mask, bit);
    const tone = down
      ? "border-ember bg-ember text-ember-ink"
      : emphasize
        ? "border-ember bg-surface text-ember"
        : "border-line bg-surface-2 text-fg";
    return (
      <button
        type="button"
        aria-label={label}
        aria-pressed={down}
        className={`touch-none grid select-none place-items-center border text-sm font-semibold tracking-wide ${className} ${tone}`}
        onContextMenu={(event) => event.preventDefault()}
        onPointerDown={(event) => {
          event.preventDefault();
          event.currentTarget.setPointerCapture(event.pointerId);
          onBit(bit, true);
          navigator.vibrate?.(8);
        }}
        onPointerUp={() => onBit(bit, false)}
        onPointerCancel={() => onBit(bit, false)}
      >
        {children}
      </button>
    );
  };

  return (
    <div className="flex flex-wrap items-center justify-between gap-6">
      <div className="pad-grid" aria-label="Cruceta">
        {hold(PAD.UP, "Arriba", "col-start-2 row-start-1 size-16 rounded-full", <ChevronUp />)}
        {hold(PAD.LEFT, "Izquierda", "col-start-1 row-start-2 size-16 rounded-full", <ChevronLeft />)}
        <span className="col-start-2 row-start-2 grid place-items-center font-mono text-xs tracking-[0.18em] text-muted">
          DIR
        </span>
        {hold(PAD.RIGHT, "Derecha", "col-start-3 row-start-2 size-16 rounded-full", <ChevronRight />)}
        {hold(PAD.DOWN, "Abajo", "col-start-2 row-start-3 size-16 rounded-full", <ChevronDown />)}
      </div>
      <div className="flex flex-col items-end gap-4">
        <div className="flex items-center gap-3">
          {hold(PAD.B, "B", "size-16 rounded-full text-base", "B")}
          {hold(PAD.A, "A", "size-16 rounded-full text-base", "A", true)}
        </div>
        <div className="flex gap-3">
          {hold(PAD.SELECT, "Select", "h-12 rounded-md px-4 text-xs", "Select")}
          {hold(PAD.START, "Start", "h-12 rounded-md px-4 text-xs", "Start")}
        </div>
      </div>
    </div>
  );
}
