import { useEffect, useRef } from "react";
import { bitForKey, gamepadMask } from "@/lib/pad-protocol";

interface NesScreenProps {
  rom: Uint8Array;
  extraMask: number;
  onError: (message: string) => void;
}

export function NesScreen({ rom, extraMask, onError }: NesScreenProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const extraRef = useRef(extraMask);
  extraRef.current = extraMask;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) return;

    let cancelled = false;
    let raf = 0;
    let keyMask = 0;
    const held = new Uint8Array(8);
    const audio = createAudio();

    const onKeyDown = (event: KeyboardEvent) => {
      const bit = bitForKey(event.code);
      if (bit === null || event.repeat) return;
      const target = event.target;
      if (target instanceof HTMLElement && target !== canvas && isFormControl(target)) return;
      event.preventDefault();
      keyMask |= 1 << bit;
      void audio.resume();
    };
    const onKeyUp = (event: KeyboardEvent) => {
      const bit = bitForKey(event.code);
      if (bit === null) return;
      keyMask &= ~(1 << bit);
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    canvas.focus();

    const image = context.createImageData(256, 240);
    const backing = new ArrayBuffer(image.data.length);
    const buf32 = new Uint32Array(backing);
    const buf8 = new Uint8ClampedArray(backing);

    void (async () => {
      const { NES } = await import("jsnes");
      if (cancelled) return;
      await audio.resume();
      const nes = new NES({
        sampleRate: audio.sampleRate,
        onFrame(buffer: Uint32Array) {
          for (let i = 0; i < buffer.length; i++) buf32[i] = 0xff000000 | buffer[i];
        },
        onAudioSample(left: number, right: number) {
          audio.write(left, right);
        },
      });
      try {
        nes.loadROM(rom);
      } catch (error) {
        const detail = error instanceof Error ? error.message : "mapper no soportado";
        onError(`Este núcleo liviano no abre ese ROM (${detail}).`);
        return;
      }

      const frameMs = 1000 / 60.098;
      let last = performance.now();
      let acc = 0;

      const sync = () => {
        const mask = (extraRef.current | keyMask | gamepadMask()) & 255;
        for (let bit = 0; bit < 8; bit++) {
          const down = (mask >>> bit) & 1;
          if (down === held[bit]) continue;
          held[bit] = down;
          if (down) nes.buttonDown(1, bit as 0);
          else nes.buttonUp(1, bit as 0);
        }
      };

      const loop = (now: number) => {
        if (cancelled) return;
        acc += Math.min(80, now - last);
        last = now;
        let steps = 0;
        while (acc >= frameMs && steps < 3) {
          sync();
          try {
            nes.frame();
          } catch (error) {
            const detail = error instanceof Error ? error.message : "fallo del núcleo";
            onError(`El núcleo se detuvo (${detail}).`);
            return;
          }
          acc -= frameMs;
          steps++;
        }
        image.data.set(buf8);
        context.putImageData(image, 0, 0);
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
    })();

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      audio.close();
    };
  }, [rom, onError]);

  return (
    <div className="screen-slot">
      <canvas
        ref={canvasRef}
        width={256}
        height={240}
        tabIndex={0}
        aria-label="Pantalla del emulador NES"
        className="screen-canvas"
        onPointerDown={() => canvasRef.current?.focus()}
      />
    </div>
  );
}

function isFormControl(target: HTMLElement): boolean {
  const tag = target.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || tag === "BUTTON" || tag === "A";
}

function createAudio() {
  const Ctx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  const ctx = Ctx ? new Ctx() : null;
  const size = 8192;
  const left = new Float32Array(size);
  const right = new Float32Array(size);
  let writeAt = 0;
  let readAt = 0;
  let count = 0;
  let node: ScriptProcessorNode | null = null;
  if (ctx) {
    node = ctx.createScriptProcessor(1024, 0, 2);
    node.onaudioprocess = (event) => {
      const outL = event.outputBuffer.getChannelData(0);
      const outR = event.outputBuffer.getChannelData(1);
      for (let i = 0; i < outL.length; i++) {
        if (count > 0) {
          outL[i] = left[readAt];
          outR[i] = right[readAt];
          readAt = (readAt + 1) % size;
          count--;
        } else {
          outL[i] = 0;
          outR[i] = 0;
        }
      }
    };
    node.connect(ctx.destination);
  }
  return {
    sampleRate: ctx?.sampleRate ?? 48000,
    write(sampleL: number, sampleR: number) {
      if (!ctx) return;
      if (count >= size) {
        readAt = (readAt + 1) % size;
        count--;
      }
      left[writeAt] = sampleL;
      right[writeAt] = sampleR;
      writeAt = (writeAt + 1) % size;
      count++;
    },
    async resume() {
      if (ctx && ctx.state !== "running") await ctx.resume();
    },
    close() {
      node?.disconnect();
      void ctx?.close();
    },
  };
}
