import { useEffect, useState } from "react";
import type { PeerState } from "@/lib/use-tv-room";

const PEER_LABEL: Record<PeerState, string> = {
  preparando: "Preparando la sala",
  esperando: "Esperando al teléfono",
  conectado: "Teléfono enlazado",
  error: "No se pudo crear la sala",
};

export function QrCard({
  link,
  code,
  peer,
}: {
  link: string | null;
  code: string | null;
  peer: PeerState;
}) {
  const [src, setSrc] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!link) return;
    let cancel = false;
    void import("qrcode").then(async (mod) => {
      const url = await mod.default.toDataURL(link, {
        margin: 1,
        width: 280,
        errorCorrectionLevel: "M",
        color: { dark: "#14120f", light: "#f4ede2" },
      });
      if (!cancel) setSrc(url);
    });
    return () => {
      cancel = true;
    };
  }, [link]);

  const copy = async () => {
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };

  return (
    <aside className="rounded-lg border border-line bg-surface p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="font-mono text-xs tracking-[0.16em] text-muted">MANDO</h2>
        <p className="text-sm text-fg">{PEER_LABEL[peer]}</p>
      </div>
      <p className="mt-2 text-sm text-pretty text-muted">
        Escanea el QR con el teléfono, en la misma red. No se instala nada: se abre el mando y queda
        enlazado.
      </p>
      <div className="mt-4 grid place-items-center rounded-md bg-fg p-3">
        {src ? (
          <img src={src} alt="Código QR para enlazar el teléfono como mando" className="w-full max-w-56" />
        ) : (
          <div className="grid h-52 w-full max-w-56 place-items-center text-sm text-ember-ink">
            Generando QR…
          </div>
        )}
      </div>
      {code ? (
        <p className="mt-3 text-center font-mono text-lg tracking-[0.25em] text-fg">{code}</p>
      ) : null}
      <button
        type="button"
        onClick={() => void copy()}
        disabled={!link}
        className="mt-3 h-11 w-full rounded-md border border-line bg-surface-2 text-sm font-medium text-fg disabled:opacity-40"
      >
        {copied ? "Enlace copiado" : "Copiar enlace del mando"}
      </button>
    </aside>
  );
}
