/**
 * Builds an original NROM test ROM (not a commercial game).
 * A white square moves with the D-pad. A turns the background red.
 * Output: src/lib/demo-rom.ts
 */
import { writeFileSync } from "node:fs";
import { NES, Controller } from "jsnes";

const prg = new Uint8Array(16384);
const chr = new Uint8Array(8192);
for (let row = 0; row < 8; row++) chr[16 + row] = 0xff;

let pc = 0;
const labels = new Map();
const fixups = [];

function emit(...bytes) {
  for (const b of bytes) prg[pc++] = b & 0xff;
}
function label(name) {
  labels.set(name, pc);
}
function rel(op, name) {
  emit(op);
  fixups.push({ at: pc, name, type: "rel" });
  emit(0);
}
function abs(op, name) {
  emit(op);
  fixups.push({ at: pc, name, type: "abs" });
  emit(0, 0);
}
function addr(n) {
  emit(n & 0xff, (n >> 8) & 0xff);
}

label("reset");
emit(0x78, 0xd8); // sei cld
emit(0xa2, 0x40); // ldx #$40
emit(0x8e, 0x17, 0x40); // stx $4017
emit(0xa2, 0xff, 0x9a, 0xe8); // ldx #$ff txs inx
emit(0x8e, 0x00, 0x20); // stx $2000
emit(0x8e, 0x01, 0x20); // stx $2001
emit(0x8e, 0x10, 0x40); // stx $4010
emit(0x2c, 0x02, 0x20); // bit $2002
label("vb1");
emit(0x2c, 0x02, 0x20);
rel(0x10, "vb1"); // bpl
emit(0x8a); // txa
label("clr");
emit(0x9d, 0x00, 0x00);
emit(0x9d, 0x00, 0x01);
emit(0x9d, 0x00, 0x02);
emit(0x9d, 0x00, 0x03);
emit(0x9d, 0x00, 0x04);
emit(0x9d, 0x00, 0x05);
emit(0x9d, 0x00, 0x06);
emit(0x9d, 0x00, 0x07);
emit(0xe8);
rel(0xd0, "clr"); // bne
emit(0x2c, 0x02, 0x20);
label("vb2");
emit(0x2c, 0x02, 0x20);
rel(0x10, "vb2");

// Palette
emit(0xa9, 0x3f, 0x8d, 0x06, 0x20); // lda #$3f sta $2006
emit(0xa9, 0x00, 0x8d, 0x06, 0x20); // lda #$00 sta $2006
emit(0xa2, 0x00);
label("pal");
abs(0xbd, "palette"); // lda palette,x
emit(0x8d, 0x07, 0x20); // sta $2007
emit(0xe8, 0xe0, 32);
rel(0xd0, "pal");

// Sprite 0 at roughly center
emit(0xa9, 112, 0x8d, 0x00, 0x02); // y
emit(0xa9, 1, 0x8d, 0x01, 0x02); // tile
emit(0xa9, 0, 0x8d, 0x02, 0x02); // attr
emit(0xa9, 120, 0x8d, 0x03, 0x02); // x

emit(0xa9, 0b10000000, 0x8d, 0x00, 0x20); // NMI on
emit(0xa9, 0b00011110, 0x8d, 0x01, 0x20); // show bg + sprites
label("forever");
emit(0x4c);
fixups.push({ at: pc, name: "forever", type: "abs" });
emit(0, 0);

label("nmi");
emit(0xa9, 0x01, 0x8d, 0x16, 0x40); // strobe
emit(0xa9, 0x00, 0x8d, 0x16, 0x40);
emit(0x85, 0x10); // buttons = 0
emit(0xa2, 8);
label("readpad");
emit(0xad, 0x16, 0x40); // lda $4016
emit(0x4a); // lsr
emit(0x26, 0x10); // rol buttons
emit(0xca);
rel(0xd0, "readpad");

// Right = bit 0
emit(0xa5, 0x10, 0x29, 0x01);
rel(0xf0, "noRight");
emit(0xee, 0x03, 0x02); // inc sprite x
label("noRight");
emit(0xa5, 0x10, 0x29, 0x02);
rel(0xf0, "noLeft");
emit(0xce, 0x03, 0x02); // dec sprite x
label("noLeft");
emit(0xa5, 0x10, 0x29, 0x04);
rel(0xf0, "noDown");
emit(0xee, 0x00, 0x02);
label("noDown");
emit(0xa5, 0x10, 0x29, 0x08);
rel(0xf0, "noUp");
emit(0xce, 0x00, 0x02);
label("noUp");

// Background: red while A (bit 7) is held, else black
emit(0xa9, 0x3f, 0x8d, 0x06, 0x20);
emit(0xa9, 0x00, 0x8d, 0x06, 0x20);
emit(0xa5, 0x10, 0x29, 0x80);
rel(0xf0, "notA");
emit(0xa9, 0x16);
rel(0xd0, "storeBg");
label("notA");
emit(0xa9, 0x0f);
label("storeBg");
emit(0x8d, 0x07, 0x20);

// OAM DMA from $0200
emit(0xa9, 0x00, 0x8d, 0x03, 0x20);
emit(0xa9, 0x02, 0x8d, 0x14, 0x40);
emit(0xa9, 0x00, 0x8d, 0x05, 0x20, 0x8d, 0x05, 0x20); // scroll 0
emit(0x40); // rti

label("palette");
const palette = [
  0x0f, 0x30, 0x30, 0x30, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f,
  0x0f, 0x30, 0x30, 0x30, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f,
];
emit(...palette);

label("irq");
emit(0x40);

for (const fix of fixups) {
  const target = labels.get(fix.name);
  if (target === undefined) throw new Error(`missing label ${fix.name}`);
  const absAddr = 0x8000 + target;
  if (fix.type === "abs") {
    prg[fix.at] = absAddr & 0xff;
    prg[fix.at + 1] = (absAddr >> 8) & 0xff;
  } else {
    const from = fix.at + 1;
    const relOff = target - from;
    if (relOff < -128 || relOff > 127) throw new Error(`branch ${fix.name} out of range ${relOff}`);
    prg[fix.at] = relOff & 0xff;
  }
}

function putVector(name, at) {
  const absAddr = 0x8000 + labels.get(name);
  prg[at] = absAddr & 0xff;
  prg[at + 1] = (absAddr >> 8) & 0xff;
}
putVector("nmi", 16384 - 6);
putVector("reset", 16384 - 4);
putVector("irq", 16384 - 2);

if (pc > 16384 - 6) throw new Error(`PRG overflow ${pc}`);

const header = new Uint8Array(16);
header.set([0x4e, 0x45, 0x53, 0x1a, 0x01, 0x01, 0x01, 0x00]);
const rom = new Uint8Array(16 + 16384 + 8192);
rom.set(header, 0);
rom.set(prg, 16);
rom.set(chr, 16 + 16384);

let samples = [];
const nes = new NES({
  emulateSound: false,
  onFrame(buffer) {
    samples = buffer;
  },
});
nes.loadROM(rom);
for (let i = 0; i < 8; i++) nes.frame();
const before = spriteBox(samples);
nes.buttonDown(1, Controller.BUTTON_RIGHT);
nes.buttonDown(1, Controller.BUTTON_A);
for (let i = 0; i < 6; i++) nes.frame();
const after = spriteBox(samples);
if (!before || !after) {
  console.error("sprite not visible", before, after);
  process.exit(1);
}
if (after.x <= before.x) {
  console.error("sprite did not move", before, after);
  process.exit(1);
}
console.log("demo rom ok", { before, after, bytes: rom.length });

const b64 = Buffer.from(rom).toString("base64");
writeFileSync(
  new URL("../src/lib/demo-rom.ts", import.meta.url),
  `/** Original NROM test ROM. Not a commercial game. Square moves; A tints the background. */\nexport const DEMO_ROM_BASE64 = ${JSON.stringify(b64)};\n\nexport function demoRomBytes(): Uint8Array {\n  const bin = atob(DEMO_ROM_BASE64);\n  const out = new Uint8Array(bin.length);\n  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);\n  return out;\n}\n`,
);

function spriteBox(buffer) {
  let minX = 999;
  let maxX = -1;
  let minY = 999;
  let count = 0;
  for (let y = 0; y < 240; y++) {
    for (let x = 0; x < 256; x++) {
      const c = buffer[y * 256 + x];
      const r = c & 0xff;
      const g = (c >> 8) & 0xff;
      const b = (c >> 16) & 0xff;
      if (r > 200 && g > 200 && b > 200) {
        count++;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
      }
    }
  }
  if (!count) return null;
  return { x: minX, y: minY, count };
}
