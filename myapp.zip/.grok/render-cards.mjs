import { chromium } from "playwright";

const executablePath =
  "/opt/pw-browsers/chromium_headless_shell-1248/chrome-headless-shell-linux64/chrome-headless-shell";

const browser = await chromium.launch({
  executablePath,
  headless: true,
  args: ["--disable-gpu", "--font-render-hinting=none"],
});

async function shoot(htmlName, outPath, width, height) {
  const page = await browser.newPage({
    viewport: { width, height },
    deviceScaleFactor: 1,
  });
  await page.goto(`file:///workspace/.grok/${htmlName}`, { waitUntil: "load" });
  await page.evaluate(async () => {
    await document.fonts.ready;
  });
  await page.screenshot({
    path: outPath,
    type: "png",
    clip: { x: 0, y: 0, width, height },
  });
  await page.close();
}

await shoot("og-card.html", "/workspace/.grok/og-raw.png", 1200, 630);
await shoot("x-banner.html", "/workspace/.grok/x-banner-raw.png", 1200, 264);
await browser.close();
console.log("shot");
